package fr.geeko.iptv.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Petit carillon synthétisé à la volée (aucun fichier audio à embarquer).
 * Deux notes montantes, façon écran d'accueil de console.
 */
object Chime {

    private const val RATE = 44100

    fun play(volume: Float = 0.5f) {
        thread(isDaemon = true) { runCatching { render(volume) } }
    }

    private fun render(volume: Float) {
        val notes = listOf(659.26 to 90, 987.77 to 150) // Mi puis Si
        val samples = ArrayList<Short>(RATE)

        notes.forEachIndexed { index, (freq, ms) ->
            val count = RATE * ms / 1000
            for (i in 0 until count) {
                val t = i.toDouble() / RATE
                // attaque courte puis décroissance exponentielle
                val attack = (i / (RATE * 0.008)).coerceAtMost(1.0)
                val decay = exp(-3.2 * t / (ms / 1000.0))
                val body = sin(2 * PI * freq * t) * 0.75 +
                    sin(2 * PI * freq * 2 * t) * 0.25
                val v = body * attack * decay * volume * Short.MAX_VALUE
                samples.add(v.toInt().coerceIn(-32768, 32767).toShort())
            }
            if (index == 0) repeat(RATE * 25 / 1000) { samples.add(0) }
        }

        val buffer = ShortArray(samples.size) { samples[it] }
        val bytes = buffer.size * 2

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(buffer, 0, buffer.size)
        track.setNotificationMarkerPosition(buffer.size)
        track.setPlaybackPositionUpdateListener(
            object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(t: AudioTrack?) { runCatching { t?.release() } }
                override fun onPeriodicNotification(t: AudioTrack?) {}
            }
        )
        track.play()
    }
}
