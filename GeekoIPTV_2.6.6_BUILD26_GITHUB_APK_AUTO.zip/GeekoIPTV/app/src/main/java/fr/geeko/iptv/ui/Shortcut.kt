package fr.geeko.iptv.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/**
 * Le bouton Netflix de la Shield est intercepté par Button Mapper : il n'arrive
 * jamais jusqu'à l'app sous forme de touche. En revanche, si Button Mapper est
 * réglé sur « lancer GeekoIPTV » et que l'app est déjà au premier plan, Android
 * appelle onNewIntent au lieu de la relancer (launchMode singleTop).
 * On s'en sert comme d'une touche d'action.
 */
object ShortcutBus {
    var pulse by mutableIntStateOf(0)
        private set

    fun fire() { pulse++ }
}
