package fr.geeko.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.data.Pairing
import fr.geeko.iptv.ui.i18n.tr
import fr.geeko.iptv.ui.theme.*
import kotlinx.coroutines.launch

// ------------------------------------------------------------ côté téléviseur

@Composable
fun PairReceiveScreen(vm: AppViewModel) {
    val code = remember { Pairing.newCode() }
    var received by remember { mutableStateOf(false) }

    val context = androidx.compose.ui.platform.LocalContext.current
    var failure by remember { mutableStateOf<String?>(null) }
    val address = remember { Pairing.localIp(context) }

    LaunchedEffect(code) {
        runCatching {
            Pairing.receive(
                context = context,
                code = code,
                deviceName = Pairing.deviceName(),
                onError = { failure = it }
            ) { host, user, pass ->
                received = true
                vm.connect(host, user, pass)
            }
        }.onFailure { failure = it.message }
    }

    Column(
        Modifier
            .fillMaxSize()
            .appBackground()
            .statusBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.back() }, modifier = Modifier.tvFocus(scale = 1.06f)) {
                Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
            }
            Spacer(Modifier.width(4.dp))
            Text(
                tr("Recevoir depuis un téléphone"),
                fontSize = 19.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(Modifier.height(28.dp))

        if (received) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Mint,
                modifier = Modifier.size(56.dp)
            )
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    color = Accent,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(12.dp))
                Text(tr("Identifiants reçus, connexion en cours…"), fontSize = 15.sp)
            }

            vm.error?.let { message ->
                Spacer(Modifier.height(18.dp))
                Text(
                    message,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { vm.back() },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.tvFocus(RoundedCornerShape(20.dp), 1.03f)
                ) { Text(tr("Retour")) }
            }
            return@Column
        }

        Icon(
            Icons.Default.Cast,
            contentDescription = null,
            tint = Accent,
            modifier = Modifier.size(46.dp)
        )

        Spacer(Modifier.height(18.dp))

        Text(
            tr("Sur ton téléphone, ouvre GeekoIPTV puis Réglages, et choisis « Envoyer vers un téléviseur »."),
            color = TextMid,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 520.dp)
        )

        Spacer(Modifier.height(26.dp))

        Text(tr("Code à saisir sur le téléphone"), color = TextLow, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            code.forEach { digit ->
                Box(
                    Modifier
                        .size(width = 58.dp, height = 74.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Surface1)
                        .border(2.dp, Accent.copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(digit.toString(), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(
                color = Accent,
                strokeWidth = 2.dp,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(tr("En attente du téléphone…"), color = TextLow, fontSize = 13.sp)
        }

        Spacer(Modifier.height(18.dp))

        address?.let {
            Text(
                tr("Si le téléphone ne trouve rien, saisis cette adresse :"),
                color = TextLow,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Surface1)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(it, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(14.dp))
        }

        failure?.let {
            Text(
                tr("Erreur réseau") + " : " + it,
                color = MaterialTheme.colorScheme.error,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
        }

        Text(
            tr("Les deux appareils doivent être sur le même réseau Wi-Fi."),
            color = TextLow,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}

// ------------------------------------------------------------- côté téléphone

@Composable
fun PairSendScreen(vm: AppViewModel) {
    val scope = rememberCoroutineScope()
    var devices by remember { mutableStateOf<List<Pairing.Device>>(emptyList()) }
    var scanning by remember { mutableStateOf(true) }
    var chosen by remember { mutableStateOf<Pairing.Device?>(null) }
    var code by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var manualIp by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }

    val context = androidx.compose.ui.platform.LocalContext.current

    fun scan() {
        scanning = true
        devices = emptyList()
        scope.launch {
            devices = Pairing.discover(context)
            scanning = false
        }
    }

    LaunchedEffect(Unit) { scan() }

    Column(
        Modifier
            .fillMaxSize()
            .appBackground()
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.back() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
            }
            Text(
                tr("Envoyer vers un téléviseur"),
                Modifier.weight(1f),
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
            IconButton(onClick = { scan() }) {
                Icon(Icons.Default.Refresh, contentDescription = tr("Rechercher"))
            }
        }

        if (sent) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Mint,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(Modifier.height(14.dp))
                    Text(tr("Envoyé ! Le téléviseur se connecte."), fontSize = 15.sp)
                }
            }
            return@Column
        }

        Spacer(Modifier.height(6.dp))
        Text(
            tr("Sur le téléviseur, ouvre GeekoIPTV et choisis « Recevoir depuis un téléphone »."),
            color = TextMid,
            fontSize = 13.sp,
            lineHeight = 18.sp
        )

        Spacer(Modifier.height(16.dp))

        when {
            scanning -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    color = Accent,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(tr("Recherche sur le réseau…"), color = TextLow, fontSize = 13.sp)
            }

            devices.isEmpty() -> Text(
                tr("Aucun téléviseur trouvé. Saisis son adresse ci-dessous, elle est affichée sur l'écran du téléviseur."),
                color = TextLow,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(devices, key = { it.address }) { device ->
                    val selected = chosen?.address == device.address
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (selected) Accent.copy(alpha = 0.18f) else Surface1)
                            .clickable { chosen = device; status = null }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Tv,
                            contentDescription = null,
                            tint = if (selected) Accent else TextMid,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(device.name, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(device.address, color = TextLow, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Saisie manuelle : disponible immédiatement, sans attendre la recherche.
        run {
            Spacer(Modifier.height(14.dp))
            Text(
                tr("Adresse du téléviseur"),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = manualIp,
                    onValueChange = { manualIp = it },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    placeholder = { Text("192.168.1.42") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(10.dp))
                TextButton(
                    onClick = {
                        chosen = Pairing.Device(manualIp.trim(), manualIp.trim())
                        status = null
                    },
                    enabled = manualIp.count { it == '.' } == 3
                ) { Text(tr("Utiliser")) }
            }
        }

        chosen?.let { device ->
            Spacer(Modifier.height(20.dp))
            Text(
                tr("Code affiché sur le téléviseur"),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = code,
                onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) code = it },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                placeholder = { Text("0000") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword
                ),
                modifier = Modifier.fillMaxWidth()
            )

            status?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    scope.launch {
                        val error = Pairing.send(
                            device, code,
                            vm.store.host, vm.store.username, vm.store.password
                        )
                        if (error == null) sent = true
                        else status = if (error == "code") tr("Code incorrect")
                        else tr("Envoi impossible, réessaie.")
                    }
                },
                enabled = code.length == 4,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) { Text(tr("Envoyer les identifiants")) }
        }

        Spacer(Modifier.height(24.dp))
    }
}
