package fr.geeko.iptv

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import fr.geeko.iptv.data.DownloadCenter
import fr.geeko.iptv.data.DownloadState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * Enregistre un flux TV entre l'heure de début et l'heure de fin indiquées par l'EPG.
 * WorkManager lance ce worker au moment du programme et le garde au premier plan
 * pour éviter qu'Android TV ne coupe un enregistrement long.
 */
class RecordingWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        const val KEY_DOWNLOAD = "download_key"
        private const val CHANNEL = "geeko_recordings"
        private const val NOTIF_ID = 9042
    }

    override suspend fun doWork(): Result {
        val key = inputData.getString(KEY_DOWNLOAD) ?: return Result.failure()
        DownloadCenter.load(applicationContext)
        val item = DownloadCenter.find(key) ?: return Result.success()

        val now = System.currentTimeMillis()
        if (item.scheduledEnd in 1..now) {
            DownloadCenter.update(applicationContext, key) { it.copy(state = DownloadState.FAILED) }
            return Result.failure()
        }

        if (item.scheduledStart > now) {
            delay(item.scheduledStart - now)
        }

        setForeground(createForegroundInfo(item.title))
        DownloadCenter.update(applicationContext, key) { it.copy(state = DownloadState.RUNNING) }

        return withContext(Dispatchers.IO) {
            val file = DownloadCenter.fileFor(applicationContext, item)
            file.parentFile?.mkdirs()
            val http = OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .retryOnConnectionFailure(true)
                .build()
            val request = Request.Builder()
                .url(item.url)
                .header("User-Agent", "GeekoIPTV/1.7 (Android TV Recorder)")
                .build()

            try {
                http.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
                    val body = response.body ?: throw IllegalStateException("Flux vide")
                    body.byteStream().use { input ->
                        FileOutputStream(file).use { output ->
                            val buffer = ByteArray(64 * 1024)
                            var written = 0L
                            var lastPublish = 0L
                            while (!isStopped && System.currentTimeMillis() < item.scheduledEnd) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                                written += n
                                val t = System.currentTimeMillis()
                                if (t - lastPublish > 2500L) {
                                    lastPublish = t
                                    DownloadCenter.update(applicationContext, key) {
                                        it.copy(downloaded = written, total = 0L, state = DownloadState.RUNNING)
                                    }
                                }
                            }
                            output.flush()
                            DownloadCenter.update(applicationContext, key) {
                                it.copy(downloaded = written, total = written, state = DownloadState.DONE)
                            }
                        }
                    }
                }
                Result.success()
            } catch (t: Throwable) {
                DownloadCenter.update(applicationContext, key) { it.copy(state = DownloadState.FAILED) }
                Result.retry()
            }
        }
    }

    private fun createForegroundInfo(title: String): ForegroundInfo {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL,
                "Enregistrements TV",
                NotificationManager.IMPORTANCE_LOW
            ).apply { setShowBadge(false) }
            applicationContext.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }

        val pending = PendingIntent.getActivity(
            applicationContext,
            0,
            Intent(applicationContext, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Enregistrement TV")
            .setContentText(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pending)
            .build()
        return ForegroundInfo(NOTIF_ID, notification)
    }
}
