package fr.geeko.iptv.ui

import android.content.Context
import android.view.ContextThemeWrapper
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.common.images.WebImage

/** La diffusion n'est proposée que si les services Google sont présents. */
fun castAvailable(context: Context): Boolean =
    runCatching { CastContext.getSharedInstance(context.applicationContext) }.isSuccess

private fun contentTypeFor(url: String): String = when {
    url.endsWith(".m3u8", true) -> "application/x-mpegURL"
    url.endsWith(".mkv", true) -> "video/x-matroska"
    url.endsWith(".webm", true) -> "video/webm"
    else -> "video/mp4"
}

/**
 * Envoie le titre en cours vers le récepteur, à la position où on en est.
 * @return true si la commande est partie.
 */
fun castCurrent(
    context: Context,
    url: String,
    title: String,
    subtitle: String?,
    poster: String?,
    positionMs: Long
): Boolean = runCatching {
    val session: CastSession = CastContext.getSharedInstance(context.applicationContext)
        .sessionManager.currentCastSession ?: return false
    val client = session.remoteMediaClient ?: return false

    val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
        putString(MediaMetadata.KEY_TITLE, title)
        subtitle?.let { putString(MediaMetadata.KEY_SUBTITLE, it) }
        poster?.takeIf { it.isNotBlank() }?.let {
            addImage(WebImage(android.net.Uri.parse(it)))
        }
    }

    val media = MediaInfo.Builder(url)
        .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
        .setContentType(contentTypeFor(url))
        .setMetadata(metadata)
        .build()

    client.load(
        MediaLoadRequestData.Builder()
            .setMediaInfo(media)
            .setAutoplay(true)
            .setCurrentTime(positionMs)
            .build()
    )
    true
}.getOrDefault(false)

/**
 * Prévient quand une session de diffusion démarre ou s'arrête, pour envoyer
 * la vidéo au téléviseur et mettre la lecture locale en pause.
 */
@Composable
fun CastSessionWatcher(onStarted: () -> Unit, onEnded: () -> Unit) {
    val context = LocalContext.current

    DisposableEffect(Unit) {
        val manager = runCatching {
            CastContext.getSharedInstance(context.applicationContext).sessionManager
        }.getOrNull()

        val listener = object : SessionManagerListener<CastSession> {
            override fun onSessionStarted(session: CastSession, sessionId: String) = onStarted()
            override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) = onStarted()
            override fun onSessionEnded(session: CastSession, error: Int) = onEnded()
            override fun onSessionStarting(session: CastSession) {}
            override fun onSessionStartFailed(session: CastSession, error: Int) {}
            override fun onSessionEnding(session: CastSession) {}
            override fun onSessionResuming(session: CastSession, sessionId: String) {}
            override fun onSessionResumeFailed(session: CastSession, error: Int) {}
            override fun onSessionSuspended(session: CastSession, reason: Int) {}
        }

        runCatching { manager?.addSessionManagerListener(listener, CastSession::class.java) }
        onDispose {
            runCatching { manager?.removeSessionManagerListener(listener, CastSession::class.java) }
        }
    }
}

/**
 * Bouton officiel de diffusion. Il exige un thème AppCompat, d'où
 * l'habillage du contexte : notre application utilise un thème Material.
 */
@Composable
fun CastButton(modifier: Modifier = Modifier) {
    AndroidView(
        factory = { ctx ->
            val themed = ContextThemeWrapper(
                ctx,
                androidx.appcompat.R.style.Theme_AppCompat_DayNight
            )
            MediaRouteButton(themed).also { button ->
                runCatching { CastButtonFactory.setUpMediaRouteButton(ctx.applicationContext, button) }
            }
        },
        modifier = modifier.size(44.dp)
    )
}
