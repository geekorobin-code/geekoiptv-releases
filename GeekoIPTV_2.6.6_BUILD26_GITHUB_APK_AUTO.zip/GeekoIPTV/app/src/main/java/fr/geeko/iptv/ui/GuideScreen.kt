package fr.geeko.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.data.Category
import fr.geeko.iptv.data.ContentType
import fr.geeko.iptv.data.EpgEntry
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import fr.geeko.iptv.ui.i18n.tr
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

private const val WINDOW_BEFORE_MIN = 30
private const val WINDOW_AFTER_MIN = 300
private val MINUTE_WIDTH = 3.4.dp
private val ROW_HEIGHT = 48.dp
private val CHANNEL_WIDTH = 142.dp

private val clock = SimpleDateFormat("HH:mm", Locale.FRANCE)

/** Rouge franc : il doit trancher sur les blocs quelle que soit la couleur d'accent. */
private val NowLine = Color(0xFFFF2D3F)

@Composable
fun GuideScreen(vm: AppViewModel) {
    val isTv = LocalIsTv.current
    val scroll = rememberScrollState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var previewChannel by remember { mutableStateOf<StreamItem?>(null) }

    LaunchedEffect(Unit) {
        vm.loadCategories(ContentType.LIVE)
        while (true) {
            now = System.currentTimeMillis()
            delay(30_000)
        }
    }

    val windowStart = remember(now / 600_000L) {
        val slot = 30 * 60_000L
        (now / slot) * slot - WINDOW_BEFORE_MIN * 60_000L
    }
    val totalMinutes = WINDOW_BEFORE_MIN + WINDOW_AFTER_MIN
    val totalWidth = MINUTE_WIDTH * totalMinutes
    val cats = vm.visibleCategories(ContentType.LIVE)

    LaunchedEffect(cats) {
        if (vm.guideCategory == null) cats.firstOrNull()?.let { vm.openGuideCategory(it) }
    }

    Row(Modifier.fillMaxSize()) {
        // Groupes TV à gauche, comme un rail IPTV.
        Surface(
            color = Surface1.copy(alpha = 0.88f),
            shape = RoundedCornerShape(topEnd = 20.dp, bottomEnd = 20.dp),
            modifier = Modifier.width(190.dp).fillMaxHeight()
        ) {
            Column(Modifier.padding(vertical = 8.dp)) {
                Text(
                    "Groupes TV",
                    color = TextLow,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                )
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    items(cats, key = { it.id }) { cat ->
                        val selected = vm.guideCategory?.id == cat.id
                        Row(
                            Modifier
                                .padding(horizontal = 7.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selected) Accent.copy(alpha = 0.18f) else Color.Transparent)
                                .tvFocus(RoundedCornerShape(14.dp), 1.02f)
                                .clickable { vm.openGuideCategory(cat) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                cat.name,
                                modifier = Modifier.weight(1f),
                                fontSize = 12.sp,
                                color = if (selected) Color.White else TextMid,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        Column(Modifier.weight(1f).fillMaxHeight()) {
            if (previewChannel != null) {
                TvGuidePreview(
                    vm = vm,
                    item = previewChannel!!,
                    onFullscreen = { vm.playLive(previewChannel!!) },
                    onClose = { previewChannel = null }
                )
            }

            if (vm.guideLoading) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator(color = Accent)
                }
                return@Column
            }

            if (vm.guideChannels.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text(tr("Choisis un groupe de chaînes"), color = TextLow, fontSize = 14.sp)
                }
                return@Column
            }

            Row(Modifier.fillMaxWidth().background(Surface1.copy(alpha = 0.92f))) {
                Spacer(Modifier.width(CHANNEL_WIDTH))
                Box(
                    Modifier
                        .weight(1f)
                        .horizontalScroll(scroll)
                        .height(26.dp)
                ) {
                    Box(Modifier.width(totalWidth).fillMaxHeight()) {
                        Row(Modifier.width(totalWidth).fillMaxHeight()) {
                            val slots = totalMinutes / 30
                            repeat(slots) { i ->
                                val t = windowStart + i * 30L * 60_000L
                                Box(
                                    Modifier
                                        .width(MINUTE_WIDTH * 30)
                                        .fillMaxHeight()
                                        .padding(start = 6.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Text(clock.format(Date(t)), color = TextLow, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }

            Box(Modifier.weight(1f)) {
                LazyColumn {
                    items(vm.guideChannels, key = { it.key }) { channel ->
                        LaunchedEffect(channel.id) { vm.ensureEpg(channel.id) }
                        GuideRow(
                            vm = vm,
                            channel = channel,
                            entries = vm.epg[channel.id],
                            windowStart = windowStart,
                            totalWidth = totalWidth,
                            totalMinutes = totalMinutes,
                            now = now,
                            scroll = scroll,
                            isTv = isTv,
                            onChannelClick = {
                                if (previewChannel?.key == channel.key) vm.playLive(channel)
                                else previewChannel = channel
                            }
                        )
                        HorizontalDivider(color = Surface2.copy(alpha = 0.65f))
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun TvGuidePreview(
    vm: AppViewModel,
    item: StreamItem,
    onFullscreen: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val url = vm.livePreviewUrl(item) ?: return
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.End
    ) {
        Surface(
            color = Color.Black,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .width(260.dp)
                .tvFocus(RoundedCornerShape(16.dp), 1.025f)
                .clickable(onClick = onFullscreen)
        ) {
            Box(Modifier.height(146.dp)) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            this.player = player
                        }
                    },
                    update = { it.player = player },
                    modifier = Modifier.fillMaxSize()
                )
                Row(
                    Modifier.align(Alignment.TopEnd).padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.70f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.tvFocus(RoundedCornerShape(12.dp), 1.06f).clickable(onClick = onClose)
                    ) {
                        Icon(Icons.Default.Close, "Fermer", modifier = Modifier.padding(7.dp).size(15.dp))
                    }
                    Surface(
                        color = Color.Black.copy(alpha = 0.70f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.tvFocus(RoundedCornerShape(12.dp), 1.06f).clickable(onClick = onFullscreen)
                    ) {
                        Icon(Icons.Default.Fullscreen, "Plein écran", modifier = Modifier.padding(7.dp).size(15.dp))
                    }
                }
                Text(
                    item.name,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.BottomStart).background(Color.Black.copy(alpha = 0.55f)).padding(8.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GuideRow(
    vm: AppViewModel,
    channel: StreamItem,
    entries: List<EpgEntry>?,
    windowStart: Long,
    totalWidth: androidx.compose.ui.unit.Dp,
    totalMinutes: Int,
    now: Long,
    scroll: androidx.compose.foundation.ScrollState,
    isTv: Boolean,
    onChannelClick: () -> Unit
 ) {
    val context = LocalContext.current
    Row(Modifier.height(ROW_HEIGHT)) {

        Row(
            Modifier
                .width(CHANNEL_WIDTH)
                .fillMaxHeight()
                .background(Surface1)
                .tvFocus(RoundedCornerShape(0.dp), scale = 1.0f)
                .clickable { onChannelClick() }
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Poster(channel.icon, channel.name, Modifier.width(34.dp), ratio = 1f, corner = 8)
            Spacer(Modifier.width(9.dp))
            Column {
                if (channel.number > 0) {
                    Text("${channel.number}", color = TextLow, fontSize = 10.sp)
                }
                Text(
                    channel.name,
                    fontSize = 12.sp,
                    maxLines = 2,
                    lineHeight = 14.sp,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .horizontalScroll(scroll)
        ) {
            Box(Modifier.width(totalWidth).fillMaxHeight()) {
                when {
                    entries == null -> Text(
                        tr("Chargement…"),
                        color = TextLow, fontSize = 11.sp,
                        modifier = Modifier.padding(start = 8.dp, top = 22.dp)
                    )
                    entries.isEmpty() -> Text(
                        tr("Pas de guide pour cette chaîne"),
                        color = TextLow, fontSize = 11.sp,
                        modifier = Modifier.padding(start = 8.dp, top = 22.dp)
                    )
                    else -> entries.forEach { e ->
                        val startMin = ((e.startMs - windowStart) / 60_000L).toInt()
                        if (startMin > WINDOW_BEFORE_MIN + WINDOW_AFTER_MIN) return@forEach
                        val endMin = ((e.endMs - windowStart) / 60_000L).toInt()
                        if (endMin < 0) return@forEach
                        val clampedStart = startMin.coerceAtLeast(0)
                        val widthMin = (endMin - clampedStart).coerceAtLeast(4)
                        val live = e.isNow(now)
                        // combinedClickable ne remonte pas toujours un appui long du bouton OK
                        // sur certaines télécommandes Android TV (notamment Shield). On capte
                        // aussi explicitement la répétition de KEYCODE_DPAD_CENTER/ENTER.
                        var tvLongPressFired by remember(channel.key, e.startMs, e.endMs) {
                            mutableStateOf(false)
                        }
                        var tvPressStartedAt by remember(channel.key, e.startMs, e.endMs) {
                            mutableLongStateOf(0L)
                        }
                        var showRecordMenu by remember(channel.key, e.startMs, e.endMs) {
                            mutableStateOf(false)
                        }
                        fun scheduleFromGuide() {
                            val ok = vm.scheduleRecording(channel, e)
                            android.widget.Toast.makeText(
                                context,
                                if (ok) "Enregistrement programmé dans Téléchargements"
                                else "Ce programme est déjà terminé ou déjà programmé",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }

                        if (showRecordMenu) {
                            AlertDialog(
                                onDismissRequest = { showRecordMenu = false },
                                title = { Text(e.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                                text = {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(channel.name, color = TextLow, fontSize = 12.sp)
                                        Text(
                                            "${clock.format(Date(e.startMs))} – ${clock.format(Date(e.endMs))}",
                                            color = TextLow,
                                            fontSize = 12.sp
                                        )
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(Icons.Filled.FiberManualRecord, contentDescription = null, tint = Color(0xFFE53935))
                                            Text("Enregistrer dans Téléchargements")
                                        }
                                    }
                                },
                                confirmButton = {
                                    TextButton(onClick = {
                                        showRecordMenu = false
                                        scheduleFromGuide()
                                    }) {
                                        Icon(Icons.Filled.FiberManualRecord, contentDescription = null, tint = Color(0xFFE53935))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Enregistrer")
                                    }
                                },
                                dismissButton = {
                                    TextButton(onClick = { showRecordMenu = false }) {
                                        Text("Annuler")
                                    }
                                }
                            )
                        }

                        Column(
                            Modifier
                                .offset(x = MINUTE_WIDTH * clampedStart)
                                .width(MINUTE_WIDTH * widthMin - 3.dp)
                                .fillMaxHeight()
                                .padding(vertical = 5.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (live) Accent.copy(alpha = 0.26f) else Surface2)
                                .tvFocus(RoundedCornerShape(10.dp), scale = 1.02f)
                                .onPreviewKeyEvent { event ->
                                    val center = event.key == Key.DirectionCenter || event.key == Key.Enter
                                    if (!center) return@onPreviewKeyEvent false
                                    val nowUptime = android.os.SystemClock.uptimeMillis()
                                    when (event.type) {
                                        KeyEventType.KeyDown -> {
                                            if (tvPressStartedAt == 0L) tvPressStartedAt = nowUptime
                                            if (!tvLongPressFired && nowUptime - tvPressStartedAt >= 550L) {
                                                // On arme l'appui long, mais on n'ouvre le menu qu'au relâchement.
                                                // Sinon Android TV interprète le KeyUp comme une fermeture immédiate.
                                                tvLongPressFired = true
                                            }
                                            tvLongPressFired
                                        }
                                        KeyEventType.KeyUp -> {
                                            val heldLongEnough = tvPressStartedAt != 0L && nowUptime - tvPressStartedAt >= 550L
                                            val shouldOpen = tvLongPressFired || heldLongEnough
                                            tvPressStartedAt = 0L
                                            tvLongPressFired = false
                                            if (shouldOpen) showRecordMenu = true
                                            shouldOpen
                                        }
                                        else -> false
                                    }
                                }
                                .combinedClickable(
                                    onClick = { onChannelClick() },
                                    onLongClick = { if (!isTv) showRecordMenu = true }
                                )
                                .padding(horizontal = 9.dp, vertical = 6.dp)
                        ) {
                            Text(
                                e.title,
                                fontSize = 12.sp,
                                fontWeight = if (live) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (live) TextHigh else TextMid,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "${clock.format(Date(e.startMs))} – ${clock.format(Date(e.endMs))}",
                                fontSize = 10.sp,
                                color = TextLow,
                                maxLines = 1
                            )
                            if (live) {
                                Spacer(Modifier.height(4.dp))
                                ProgressStrip(
                                    e.progress(now),
                                    Modifier.fillMaxWidth().height(3.dp)
                                )
                            }
                        }
                    }
                }

                // trait de l'heure actuelle, dessiné en dernier pour rester visible
                val nowMin = ((now - windowStart) / 60_000L).toInt()
                if (nowMin in 0..totalMinutes) {
                    Box(
                        Modifier
                            .offset(x = MINUTE_WIDTH * nowMin - 1.5.dp)
                            .width(3.dp)
                            .fillMaxHeight()
                            .background(NowLine)
                    )
                }
            }
        }
    }
}
