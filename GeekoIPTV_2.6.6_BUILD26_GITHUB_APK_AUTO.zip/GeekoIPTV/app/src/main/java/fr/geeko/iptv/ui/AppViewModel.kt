package fr.geeko.iptv.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.geeko.iptv.BuildConfig
import fr.geeko.iptv.data.*
import fr.geeko.iptv.ui.theme.AppearanceState
import fr.geeko.iptv.ui.i18n.I18n
import fr.geeko.iptv.ui.i18n.Lang
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Login : Screen
    data object Profiles : Screen
    data object Home : Screen
    data class SeriesDetail(val item: StreamItem) : Screen
    data class MovieDetail(val item: StreamItem) : Screen
    data class Player(val request: PlayRequest) : Screen
    data object Settings : Screen
    data object RemoteTest : Screen
    data object Keymap : Screen
    data object Search : Screen
    data object Completed : Screen
    data object Downloads : Screen
    data object Mosaic : Screen
    data object PairReceive : Screen
    data object PairSend : Screen
    data class Collection(val title: String, val items: List<StreamItem>) : Screen
}

data class PlayRequest(
    val url: String,
    val title: String,
    val subtitle: String? = null,
    val startMs: Long = 0L,
    val history: HistoryEntry? = null,
    val isLive: Boolean = false,
    val mysteryMode: Boolean = false
)

sealed interface UpdateState {
    data object Idle : UpdateState
    data object Checking : UpdateState
    data object UpToDate : UpdateState
    data class Available(val info: UpdateInfo) : UpdateState
    data class Downloading(val progress: Float) : UpdateState
    data class Failed(val message: String) : UpdateState
}

enum class SortMode(val label: String) {
    NUMBER("N°"), ADDED("Récents"), ALPHA("A → Z"), RATING("Note")
}

enum class HomeTab(val label: String) {
    ACCUEIL("Accueil"), LIVE("TV"), GUIDE("Guide TV"), VOD("Films"),
    SERIES("Séries"), MOSAIC("Mosaïque"), WATCHLIST("Trophées")
}

/** Dispositions de la mosaïque : nom et nombre d'emplacements. */
enum class MosaicLayout(val label: String, val slots: Int) {
    SIDE("2 côte à côte", 2),
    GRID("4 en grille", 4),
    HERO("1 grande + 3", 4)
}

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val store = Store(app)
    var client: XtreamClient? = null
        private set

    // --- navigation ---------------------------------------------------
    var screen by mutableStateOf<Screen>(Screen.Login)
        private set
    private val backStack = ArrayDeque<Screen>()

    fun go(target: Screen) {
        backStack.addLast(screen)
        screen = target
    }

    fun replace(target: Screen) {
        backStack.clear()
        screen = target
    }

    /** @return false si on est déjà à la racine (l'activité peut se fermer). */
    fun back(): Boolean {
        if (screen is Screen.Home && selectedCategory != null) {
            selectedCategory = null
            return true
        }
        if (screen is Screen.Home && tab != HomeTab.ACCUEIL) {
            manageMode = false
            clearCatSelection()
            tab = HomeTab.ACCUEIL
            return true
        }
        val prev = backStack.removeLastOrNull() ?: return false
        screen = prev
        return true
    }

    // --- état global --------------------------------------------------
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null)
    var account by mutableStateOf<Account?>(null); private set

    var profiles by mutableStateOf<List<Profile>>(emptyList()); private set
    var profile by mutableStateOf<Profile?>(null); private set
    var settings by mutableStateOf(ProfileSettings()); private set

    var tab by mutableStateOf(HomeTab.ACCUEIL)
    var selectedCategory by mutableStateOf<Category?>(null)
    var search by mutableStateOf("")
    private val browsePositions = mutableMapOf<String, Int>()
    fun browsePosition(categoryId: String): Int = browsePositions[categoryId] ?: 0
    fun saveBrowsePosition(categoryId: String, index: Int) { browsePositions[categoryId] = index.coerceAtLeast(0) }

    var categories by mutableStateOf<Map<ContentType, List<Category>>>(emptyMap()); private set
    var streams by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var listLoading by mutableStateOf(false); private set

    var history by mutableStateOf<List<HistoryEntry>>(emptyList()); private set
    var recentMovies by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var recentSeries by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var allMovies by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var allSeries by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var allLive by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var globalQuery by mutableStateOf("")

    /** Vrai quand on entre dans la recherche depuis le micro : la dictée s'ouvre seule. */
    var voiceRequested by mutableStateOf(false)
    var homeLoading by mutableStateOf(false); private set

    var watchlist by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var reminder by mutableStateOf<List<StreamItem>>(emptyList())
    private var reminderCursor = 0

    var seriesInfo by mutableStateOf<SeriesInfo?>(null); private set
    var seriesLoading by mutableStateOf(false); private set
    var movieInfo by mutableStateOf<MovieInfo?>(null); private set
    var movieLoading by mutableStateOf(false); private set

    var sortMode by mutableStateOf(SortMode.ADDED)
    var manageMode by mutableStateOf(false)
    var selectedCats by mutableStateOf<Set<String>>(emptySet())

    private var listJob: Job? = null

    // ------------------------------------------------ recherche globale

    val catalogCounts: Triple<Int, Int, Int>
        get() = Triple(allLive.size, allMovies.size, allSeries.size)

    /** Nom du groupe auquel appartient un élément, si on l'a déjà chargé. */
    fun categoryName(item: StreamItem): String? {
        val id = item.categoryId ?: return null
        return categories[item.type]?.firstOrNull { it.id == id }?.name
    }

    fun searchResults(type: ContentType): List<StreamItem> {
        val q = globalQuery.trim()
        if (q.length < 2) return emptyList()
        val source = when (type) {
            ContentType.VOD -> allMovies
            ContentType.SERIES -> allSeries
            ContentType.LIVE -> allLive
        }
        return source.filter { it.name.contains(q, ignoreCase = true) }.take(60)
    }

    val searchTotal: Int
        get() = ContentType.entries.sumOf { searchResults(it).size }

    fun openItem(item: StreamItem) {
        when (item.type) {
            ContentType.SERIES -> openSeries(item)
            ContentType.LIVE -> playLive(item)
            ContentType.VOD -> openMovie(item)
        }
    }

    /** Historique séparé par type, pour l'accueil. */
    fun historyOf(type: ContentType): List<HistoryEntry> = history.filter { it.type == type }

    // ------------------------------------ touches de la télécommande

    var keymap by mutableStateOf<Map<Int, String>>(emptyMap()); private set

    /** Action assignée à un keycode, ou null si la touche garde son rôle par défaut. */
    fun keyAction(keycode: Int): PlayerAction? =
        keymap[keycode]?.let { PlayerAction.from(it) }

    fun keysFor(action: PlayerAction): List<Int> =
        keymap.filterValues { it == action.id }.keys.sorted()

    fun bindKey(keycode: Int, action: PlayerAction) {
        val pid = profile?.id ?: return
        // une touche = une seule action ; une action peut avoir plusieurs touches
        val next = keymap.toMutableMap()
        next[keycode] = action.id
        store.saveKeymap(pid, next)
        keymap = next
    }

    fun unbindAction(action: PlayerAction) {
        val pid = profile?.id ?: return
        val next = keymap.filterValues { it != action.id }
        store.saveKeymap(pid, next)
        keymap = next
    }

    fun resetKeymap() {
        val pid = profile?.id ?: return
        store.saveKeymap(pid, emptyMap())
        keymap = emptyMap()
    }

    // --- mise à jour in-app -------------------------------------------
    private val updater = Updater(app)
    var updateState by mutableStateOf<UpdateState>(UpdateState.Idle); private set
    var updateBannerVisible by mutableStateOf(false)
    var updateDialogVisible by mutableStateOf(false)

    val currentVersionName: String get() = BuildConfig.VERSION_NAME
    val currentVersionCode: Int get() = BuildConfig.VERSION_CODE

    var language: Lang
        get() = I18n.lang
        set(value) {
            I18n.lang = value
            store.uiLanguage = value.code
        }

    fun saveAppearance() {
        val json = appearanceToJson()
        profile?.let { store.saveAppearanceForProfile(it.id, json) } ?: run { store.appearanceJson = json }
    }

    init {
        AppearanceState.soundEnabled = store.soundEnabled
        DownloadCenter.load(app)
        I18n.lang = Lang.from(store.uiLanguage)
        loadAppearance(store.appearanceJson)
        profiles = store.profiles()
        if (store.hasServer) {
            client = XtreamClient(store.host, store.username, store.password)
            screen = Screen.Profiles
            connect(store.host, store.username, store.password, remember = false)
        }
    }

    // --- connexion ----------------------------------------------------

    fun connect(host: String, user: String, pass: String, remember: Boolean = true) {
        if (host.isBlank() || user.isBlank()) {
            error = "Renseigne au moins l'adresse du serveur et l'identifiant"
            return
        }
        loading = true
        error = null
        viewModelScope.launch {
            val c = XtreamClient(host, user, pass)
            runCatching { c.authenticate() }
                .onSuccess { acc ->
                    client = c
                    account = acc
                    if (remember) {
                        store.host = c.host; store.username = user; store.password = pass
                    }
                    profiles = store.profiles()
                    // S'il n'y a qu'un profil non verrouillé, on entre directement dans l'accueil.
                    val only = profiles.singleOrNull()?.takeIf { !it.locked }
                    if (only != null) {
                        enterProfile(only)
                    } else if (screen is Screen.Login || screen is Screen.PairReceive) {
                        replace(Screen.Profiles)
                    }
                }
                .onFailure { error = it.message ?: "Connexion impossible" }
            loading = false
        }
    }

    /**
     * Revient à l'écran de connexion sans rien effacer : les identifiants
     * restent enregistrés et le formulaire est déjà rempli.
     */
    fun logout() {
        client = null; account = null; profile = null
        categories = emptyMap(); streams = emptyList(); history = emptyList()
        recentMovies = emptyList(); recentSeries = emptyList()
        allMovies = emptyList(); allSeries = emptyList(); allLive = emptyList()
        replace(Screen.Login)
    }

    /** Oublie vraiment l'abonnement : à n'utiliser que sur demande explicite. */
    fun forgetServer() {
        store.clearServer()
        logout()
    }

    // --- profils ------------------------------------------------------

    fun createProfile(name: String, color: Int, pin: String?, avatarPath: String? = null) {
        store.addProfile(name, color, pin, avatarPath)
        profiles = store.profiles()
    }

    fun deleteProfile(id: String) {
        store.deleteProfile(id)
        profiles = store.profiles()
    }

    fun renameProfile(p: Profile, name: String, color: Int, avatarPath: String? = p.avatarPath) {
        store.updateProfile(p.copy(name = name, colorIndex = color, avatarPath = avatarPath))
        profiles = store.profiles()
    }

    var soundEnabled: Boolean
        get() = store.soundEnabled
        set(v) {
            store.soundEnabled = v
            AppearanceState.soundEnabled = v
        }

    fun checkPin(p: Profile, pin: String) = store.checkPin(p, pin)

    fun enterProfile(p: Profile) {
        profile = p
        loadAppearance(store.appearanceJsonForProfile(p.id))
        settings = store.settings(p.id)
        tab = HomeTab.ACCUEIL
        selectedCategory = null
        watchlist = store.watchlist(p.id)
        keymap = store.keymap(p.id)
        completions = store.completions(p.id)
        reminder = emptyList()
        reminderCursor = 0
        replace(Screen.Home)
        refreshHome()
    }

    fun leaveProfile() {
        profile = null
        streams = emptyList(); categories = emptyMap()
        replace(Screen.Profiles)
    }

    fun updateSettings(s: ProfileSettings) {
        settings = s
        profile?.let { store.saveSettings(it.id, s) }
    }

    // --- accueil ------------------------------------------------------

    fun refreshHome() {
        val c = client ?: return
        val pid = profile?.id ?: return
        history = store.history(pid).filterNot { it.finished }
        homeLoading = true
        viewModelScope.launch {
            runCatching {
                val movies = c.streams(ContentType.VOD)
                val series = c.streams(ContentType.SERIES)
                val seriesCategories = runCatching { c.categories(ContentType.SERIES) }.getOrDefault(emptyList())
                val live = runCatching { c.streams(ContentType.LIVE) }.getOrDefault(emptyList())
                listOf(movies, series, live) to seriesCategories
            }.onSuccess { (lists, seriesCategories) ->
                val m = lists[0]
                val rawSeries = lists[1]
                val l = lists[2]

                // Certains fournisseurs Xtream renvoient parfois des VOD dans get_series.
                // On ne conserve que les entrées rattachées à une vraie catégorie SERIES.
                // Les entrées sans category_id sont gardées, car certains serveurs les utilisent
                // pour des séries non classées.
                val validSeriesCategoryIds = seriesCategories.map { it.id }.toHashSet()
                val cleanSeries = if (validSeriesCategoryIds.isEmpty()) {
                    rawSeries
                } else {
                    rawSeries.filter { it.categoryId == null || it.categoryId in validSeriesCategoryIds }
                }

                allMovies = m
                    .filter { it.type == ContentType.VOD }
                    .sortedByDescending { it.added }
                allSeries = cleanSeries
                    .filter { it.type == ContentType.SERIES }
                    .sortedByDescending { it.added }
                allLive = l.filter { it.type == ContentType.LIVE }
                recentMovies = allMovies.take(30)
                recentSeries = allSeries.take(30)
                refreshRecommendations()
                loadMosaic()
                store.lastPlaylistRefresh = System.currentTimeMillis()
            }.onFailure { error = it.message }
            homeLoading = false
        }
    }

    fun refreshHistory() {
        profile?.let { history = store.history(it.id).filterNot { h -> h.finished } }
    }

    fun removeFromHistory(key: String) {
        profile?.let { store.removeFromHistory(it.id, key); refreshHistory() }
    }

    // --- catégories & listes -------------------------------------------

    fun loadCategories(type: ContentType) {
        val c = client ?: return
        if (categories.containsKey(type)) return
        viewModelScope.launch {
            runCatching { c.categories(type) }
                .onSuccess {
                    categories = categories + (type to it)
                    if (selectedCategory == null &&
                        ((type == ContentType.VOD && tab == HomeTab.VOD) ||
                         (type == ContentType.SERIES && tab == HomeTab.SERIES))) {
                        visibleCategories(type).firstOrNull()?.let { first -> openCategory(first) }
                    }
                }
                .onFailure { error = it.message }
        }
    }

    fun visibleCategories(type: ContentType): List<Category> {
        val pid = profile?.id ?: return emptyList()
        val hid = store.hidden(pid, type)
        val base = (categories[type] ?: emptyList()).filterNot { it.id in hid }
        val order = store.categoryOrder(pid, type)
        val ranked = if (order.isEmpty()) base else base.sortedWith(compareBy<Category> {
            val i = order.indexOf(it.id)
            if (i < 0) Int.MAX_VALUE else i
        }.thenBy { it.name.lowercase() })
        val favCount = watchlist.count { it.type == type }
        return if ((type == ContentType.VOD || type == ContentType.SERIES) && favCount > 0) {
            listOf(Category("__favorites__", "Favoris", type)) + ranked
        } else ranked
    }

    fun categoryCount(cat: Category): Int = when {
        cat.id == "__favorites__" -> watchlist.count { it.type == cat.type }
        cat.type == ContentType.VOD -> allMovies.count { it.categoryId == cat.id }
        cat.type == ContentType.SERIES -> allSeries.count { it.categoryId == cat.id }
        else -> allLive.count { it.categoryId == cat.id }
    }

    fun moveCategory(cat: Category, delta: Int) {
        if (cat.id == "__favorites__") return
        val pid = profile?.id ?: return
        val ids = (categories[cat.type] ?: emptyList()).map { it.id }.toMutableList()
        val saved = store.categoryOrder(pid, cat.type)
        if (saved.isNotEmpty()) {
            ids.sortBy { id -> saved.indexOf(id).let { if (it < 0) Int.MAX_VALUE else it } }
        }
        val from = ids.indexOf(cat.id)
        if (from < 0) return
        val to = (from + delta).coerceIn(0, ids.lastIndex)
        if (from == to) return
        ids.removeAt(from)
        ids.add(to, cat.id)
        store.saveCategoryOrder(pid, cat.type, ids)
        categories = categories.toMap()
    }

    fun hiddenCategories(type: ContentType): List<Category> {
        val pid = profile?.id ?: return emptyList()
        val hid = store.hidden(pid, type)
        return (categories[type] ?: emptyList()).filter { it.id in hid }
    }

    fun toggleHidden(cat: Category) {
        val pid = profile?.id ?: return
        store.toggleHidden(pid, cat.type, cat.id)
        // force la recomposition
        categories = categories.toMap()
    }

    fun openCategory(cat: Category) {
        selectedCategory = cat
        sortMode = if (cat.type == ContentType.LIVE) SortMode.NUMBER else SortMode.ADDED
        search = ""
        if (cat.id == "__favorites__") {
            streams = watchlist.filter { it.type == cat.type }
            listLoading = false
            return
        }
        streams = emptyList()
        val c = client ?: return
        listJob?.cancel()
        listLoading = true
        listJob = viewModelScope.launch {
            runCatching { c.streams(cat.type, cat.id) }
                .onSuccess { streams = it }
                .onFailure { error = it.message }
            listLoading = false
        }
    }

    val filteredStreams: List<StreamItem>
        get() {
            val base =
                if (search.isBlank()) streams
                else streams.filter { it.name.contains(search, ignoreCase = true) }
            return when (sortMode) {
                SortMode.NUMBER -> base.sortedWith(
                    compareBy({ if (it.number == 0) Int.MAX_VALUE else it.number },
                        { it.name.lowercase() })
                )
                SortMode.ADDED -> base.sortedByDescending { it.added }
                SortMode.ALPHA -> base.sortedBy { it.name.lowercase() }
                SortMode.RATING -> base.sortedByDescending {
                    it.rating?.toFloatOrNull() ?: -1f
                }
            }
        }

    // ------------------------------------------ synopsis des jaquettes

    // ------------------------------------------------------ film au hasard

    /**
     * Ouvre un titre pris au hasard.
     *
     * On tire dans le groupe affiché s'il y en a un, sinon dans tout le
     * catalogue de l'onglet. Les titres déjà vus et ceux en cours sont
     * écartés tant qu'il reste d'autres candidats : proposer au hasard un
     * film déjà terminé n'aurait aucun intérêt.
     */
    fun openRandom() {
        val pool = when {
            selectedCategory != null -> filteredStreams
            tab == HomeTab.SERIES -> allSeries
            tab == HomeTab.LIVE -> allLive
            else -> allMovies
        }.ifEmpty { allMovies }

        if (pool.isEmpty()) {
            error = "Aucun titre à tirer au sort"
            return
        }

        val seen = history.mapNotNull { h -> h.seriesId?.let { "SERIES:$it" } ?: h.key }.toSet()
        val fresh = pool.filterNot { it.key in seen || isDone(it) }

        val pick = (fresh.ifEmpty { pool }).random()
        // Lecture immédiate : la surprise est le but, la fiche et l'overlay la gâcheraient.
        when (pick.type) {
            ContentType.VOD -> playMovie(pick, pick.containerExt, mysteryMode = true)
            ContentType.LIVE -> playLive(pick)
            ContentType.SERIES -> openSeries(pick)
        }
    }

    // ------------------------------------------------------- mosaïque

    var mosaicSlots by mutableStateOf<List<StreamItem?>>(List(4) { null }); private set
    var mosaicLayout by mutableStateOf(MosaicLayout.GRID); private set
    var mosaicAudio by mutableStateOf(0)

    /** Recharge les emplacements à partir des identifiants enregistrés. */
    fun loadMosaic() {
        val pid = profile?.id ?: return
        mosaicLayout = MosaicLayout.entries.getOrElse(store.mosaicLayout(pid)) { MosaicLayout.GRID }
        val ids = store.mosaic(pid)
        val byId = allLive.associateBy { it.id }
        mosaicSlots = List(4) { index ->
            ids.getOrNull(index)?.takeIf { it.isNotBlank() }?.let { byId[it] }
        }
    }

    private fun persistMosaic() {
        val pid = profile?.id ?: return
        store.saveMosaic(pid, mosaicSlots.map { it?.id ?: "" })
        store.saveMosaicLayout(pid, mosaicLayout.ordinal)
    }

    fun setMosaicSlot(index: Int, channel: StreamItem?) {
        mosaicSlots = mosaicSlots.toMutableList().also { it[index] = channel }
        persistMosaic()
    }

    fun applyMosaicLayout(layout: MosaicLayout) {
        mosaicLayout = layout
        persistMosaic()
    }

    val liveChannels: List<StreamItem> get() = allLive

    // ------------------------------------------------ téléchargements

    private val appContext = app.applicationContext

    val downloads: List<DownloadItem> get() = DownloadCenter.items

    fun isDownloaded(key: String) = DownloadCenter.isDownloaded(key)

    fun downloadOf(key: String): DownloadItem? = DownloadCenter.find(key)

    fun downloadMovie(item: StreamItem, ext: String?) {
        val c = client ?: return
        val extension = ext ?: item.containerExt ?: "mp4"
        DownloadCenter.enqueue(
            appContext,
            DownloadItem(
                key = item.key,
                title = item.name,
                icon = item.icon,
                url = c.movieUrl(item.id, extension),
                ext = extension,
                type = ContentType.VOD
            )
        )
    }

    /**
     * Programme un enregistrement depuis le guide TV. Le fichier apparaîtra
     * immédiatement dans Téléchargements avec l'état « Programmé ».
     */
    fun scheduleRecording(channel: StreamItem, epg: EpgEntry): Boolean {
        val c = client ?: return false
        val now = System.currentTimeMillis()
        if (epg.endMs <= now) return false
        val key = "LIVE_REC:${channel.id}:${epg.startMs}"
        if (DownloadCenter.find(key) != null) return true

        DownloadCenter.scheduleRecording(
            appContext,
            DownloadItem(
                key = key,
                title = epg.title,
                subtitle = channel.name,
                icon = channel.icon,
                url = c.liveUrl(channel.id),
                ext = "ts",
                type = ContentType.LIVE,
                state = DownloadState.SCHEDULED,
                scheduledStart = epg.startMs.coerceAtLeast(now),
                scheduledEnd = epg.endMs
            )
        )
        return true
    }

    fun downloadEpisode(series: StreamItem, ep: Episode) {
        val c = client ?: return
        DownloadCenter.enqueue(
            appContext,
            DownloadItem(
                key = "SERIES:${ep.id}",
                title = series.name,
                subtitle = "S${ep.season} E${ep.number} · ${ep.title}",
                icon = ep.cover ?: series.icon,
                url = c.episodeUrl(ep.id, ep.ext),
                ext = ep.ext,
                type = ContentType.SERIES,
                seriesId = series.id
            )
        )
    }

    /** Lit un fichier déjà présent sur l'appareil, sans réseau. */
    fun playDownload(item: DownloadItem) {
        val uri = DownloadCenter.localUri(appContext, item.key) ?: return
        val entry = HistoryEntry(
            key = item.key,
            type = item.type,
            streamId = item.key.substringAfter(':'),
            title = item.title,
            subtitle = item.subtitle,
            icon = item.icon,
            containerExt = item.ext,
            seriesId = item.seriesId
        )
        go(Screen.Player(PlayRequest(
            url = uri,
            title = item.title,
            subtitle = item.subtitle,
            startMs = profile?.let { store.resumePosition(it.id, item.key) } ?: 0L,
            history = entry
        )))
    }

    fun removeDownload(key: String) = DownloadCenter.remove(appContext, key)

    fun retryDownload(key: String) = DownloadCenter.retry(appContext, key)

    fun clearDownloads() = DownloadCenter.clearAll(appContext)

    // ------------------------------------------ « Ça pourrait vous plaire »

    var recommendations by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var recoReason by mutableStateOf<String?>(null); private set

    /**
     * Recommandation locale, sans serveur ni compte : on construit un profil de goûts
     * à partir des groupes des titres déjà regardés, mis en attente ou terminés,
     * puis on classe le reste du catalogue selon ces affinités et la note.
     */
    fun refreshRecommendations() {
        if (allMovies.isEmpty() && allSeries.isEmpty()) return

        val catalog = allMovies + allSeries
        val byKey = catalog.associateBy { it.key }

        fun keyOf(seriesId: String?, fallback: String) =
            seriesId?.let { "SERIES:$it" } ?: fallback

        // --- poids par groupe : terminé compte plus que simplement mis de côté
        val weights = HashMap<String, Float>()
        val seen = HashSet<String>()
        var seedTitle: String? = null

        fun feed(key: String, weight: Float, remember: Boolean) {
            seen += key
            val item = byKey[key] ?: return
            val cat = item.categoryId ?: return
            weights[cat] = (weights[cat] ?: 0f) + weight
            if (remember && seedTitle == null) seedTitle = item.name
        }

        completions.sortedByDescending { it.at }.forEach {
            feed(keyOf(it.seriesId, it.key), if (it.fullSeries) 3.5f else 1.2f, it.fullSeries)
        }
        history.forEach { feed(keyOf(it.seriesId, it.key), 2f, true) }
        watchlist.forEach { feed(it.key, 1f, false) }

        if (weights.isEmpty()) {
            // Rien à se mettre sous la dent : on propose les mieux notés du moment.
            recommendations = catalog
                .filter { (it.rating?.toFloatOrNull() ?: 0f) >= 7f }
                .sortedByDescending { it.added }
                .take(24)
            recoReason = null
            return
        }

        val maxWeight = weights.values.max()

        val scored = catalog.asSequence()
            .filter { it.key !in seen }
            .filter { it.categoryId != null && weights.containsKey(it.categoryId) }
            .map { item ->
                val affinity = (weights[item.categoryId] ?: 0f) / maxWeight
                val rating = (item.rating?.toFloatOrNull() ?: 0f).coerceIn(0f, 10f) / 10f
                // un peu de fraîcheur pour ne pas ressortir toujours les mêmes
                val freshness = if (item.added > 0) 0.15f else 0f
                item to (affinity * 1.6f + rating * 1.1f + freshness)
            }
            .sortedByDescending { it.second }
            .map { it.first }
            .toList()

        // on alterne films et séries pour que la rangée ne soit pas monotone
        val films = scored.filter { it.type == ContentType.VOD }
        val series = scored.filter { it.type == ContentType.SERIES }
        val mixed = ArrayList<StreamItem>(24)
        var i = 0
        while (mixed.size < 24 && (i < films.size || i < series.size)) {
            films.getOrNull(i)?.let { mixed += it }
            series.getOrNull(i)?.let { if (mixed.size < 24) mixed += it }
            i++
        }

        recommendations = mixed
        recoReason = seedTitle
    }

    // ---------------------------------------------- trophées & historique

    var completions by mutableStateOf<List<Completion>>(emptyList()); private set
    var trophy by mutableStateOf<Completion?>(null)

    fun isWatched(key: String): Boolean = completions.any { it.key == key }

    /** Vu : un film terminé, ou une série dont tous les épisodes sont vus. */
    fun isDone(item: StreamItem): Boolean = when (item.type) {
        ContentType.VOD -> isWatched(item.key)
        ContentType.SERIES -> isSeriesComplete(item.id)
        ContentType.LIVE -> false
    }

    fun isSeriesComplete(seriesId: String): Boolean {
        val pid = profile?.id ?: return false
        val total = store.seriesTotal(pid, seriesId)
        return total > 0 && store.episodesDone(pid, seriesId).size >= total
    }

    fun isEpisodeWatched(seriesId: String, episodeId: String): Boolean {
        val pid = profile?.id ?: return false
        return episodeId in store.episodesDone(pid, seriesId)
    }

    fun seriesProgress(seriesId: String): Pair<Int, Int> {
        val pid = profile?.id ?: return 0 to 0
        return store.episodesDone(pid, seriesId).size to store.seriesTotal(pid, seriesId)
    }

    fun refreshCompletions() {
        profile?.let { completions = store.completions(it.id) }
    }

    fun removeCompletion(key: String) {
        val pid = profile?.id ?: return
        store.removeCompletion(pid, key)
        refreshCompletions()
    }

    fun clearCompletions() {
        val pid = profile?.id ?: return
        store.clearCompletions(pid)
        refreshCompletions()
    }

    fun dismissTrophy() { trophy = null }

    var blurbs by mutableStateOf<Map<String, String>>(emptyMap()); private set
    private val blurbPending = mutableSetOf<String>()

    fun blurbOf(item: StreamItem): String? =
        blurbs[item.key] ?: item.plot?.takeIf { it.isNotBlank() }

    /** Va chercher le résumé d'un titre la première fois qu'on retourne sa jaquette. */
    fun ensureBlurb(item: StreamItem) {
        val c = client ?: return
        if (item.type == ContentType.LIVE) return
        if (blurbs.containsKey(item.key) || item.key in blurbPending) return
        item.plot?.takeIf { it.isNotBlank() }?.let {
            blurbs = blurbs + (item.key to it)
            return
        }
        blurbPending += item.key
        viewModelScope.launch {
            val text = runCatching {
                when (item.type) {
                    ContentType.VOD -> c.vodInfo(item.id).plot
                    ContentType.SERIES -> c.seriesInfo(item.id).plot
                    else -> null
                }
            }.getOrNull()
            blurbs = blurbs + (item.key to (text?.takeIf { it.isNotBlank() }
                ?: "Pas de résumé disponible pour ce titre."))
            blurbPending -= item.key
        }
    }

    // ---------------------------------------------------------------- EPG

    var epg by mutableStateOf<Map<String, List<EpgEntry>>>(emptyMap()); private set
    private val epgPending = mutableSetOf<String>()

    /** Charge le programme d'une chaîne une seule fois, à la demande. */
    fun ensureEpg(streamId: String) {
        val c = client ?: return
        if (epg.containsKey(streamId) || streamId in epgPending) return
        epgPending += streamId
        viewModelScope.launch {
            val list = runCatching { c.shortEpg(streamId) }.getOrDefault(emptyList())
            epg = epg + (streamId to list)
            epgPending -= streamId
        }
    }

    fun clearEpg() {
        epg = emptyMap()
        epgPending.clear()
    }

    /** Chaînes du groupe sélectionné dans le guide, triées par numéro. */
    var guideCategory by mutableStateOf<Category?>(null)
    var guideChannels by mutableStateOf<List<StreamItem>>(emptyList()); private set
    var guideLoading by mutableStateOf(false); private set

    fun openGuideCategory(cat: Category) {
        guideCategory = cat
        guideChannels = emptyList()
        clearEpg()
        val c = client ?: return
        guideLoading = true
        viewModelScope.launch {
            runCatching { c.streams(ContentType.LIVE, cat.id) }
                .onSuccess { list ->
                    guideChannels = list.sortedWith(
                        compareBy({ if (it.number == 0) Int.MAX_VALUE else it.number },
                            { it.name.lowercase() })
                    )
                }
                .onFailure { error = it.message }
            guideLoading = false
        }
    }

    // ------------------------------------------- gestion des groupes

    fun allCategories(type: ContentType): List<Category> {
        val pid = profile?.id ?: return categories[type] ?: emptyList()
        val base = categories[type] ?: emptyList()
        val order = store.categoryOrder(pid, type)
        return if (order.isEmpty()) base else base.sortedWith(compareBy<Category> {
            val i = order.indexOf(it.id)
            if (i < 0) Int.MAX_VALUE else i
        }.thenBy { it.name.lowercase() })
    }

    fun isHidden(type: ContentType, id: String): Boolean {
        val pid = profile?.id ?: return false
        return id in store.hidden(pid, type)
    }


    fun setCategoryHidden(type: ContentType, id: String, hidden: Boolean) {
        val pid = profile?.id ?: return
        val current = store.hidden(pid, type).toMutableSet()
        if (hidden) current += id else current -= id
        store.setHidden(pid, type, current)
        categories = categories.toMap()
        if (hidden && selectedCategory?.id == id) selectedCategory = null
    }

    fun toggleCatSelection(id: String) {
        selectedCats = if (id in selectedCats) selectedCats - id else selectedCats + id
    }

    fun clearCatSelection() { selectedCats = emptySet() }

    fun setHiddenForSelection(type: ContentType, hidden: Boolean) {
        val pid = profile?.id ?: return
        val current = store.hidden(pid, type).toMutableSet()
        if (hidden) current += selectedCats else current -= selectedCats
        store.setHidden(pid, type, current)
        categories = categories.toMap()
        selectedCats = emptySet()
    }

    // --- séries --------------------------------------------------------

    fun openSeries(item: StreamItem) {
        go(Screen.SeriesDetail(item))
        seriesInfo = null
        seriesLoading = true
        val c = client ?: return
        viewModelScope.launch {
            runCatching { c.seriesInfo(item.id) }
                .onSuccess {
                    seriesInfo = it
                    profile?.let { p -> store.setSeriesTotal(p.id, item.id, it.episodes.size) }
                }
                .onFailure { error = it.message }
            seriesLoading = false
        }
    }

    /** Prochain épisode à regarder pour une série (reprise). */
    fun nextEpisodeFor(seriesId: String, info: SeriesInfo): Episode? {
        val pid = profile?.id ?: return info.episodes.firstOrNull()
        val last = store.history(pid).firstOrNull { it.seriesId == seriesId }
            ?: return info.episodes.firstOrNull()
        val idx = info.episodes.indexOfFirst { it.id == last.streamId }
        if (idx < 0) return info.episodes.firstOrNull()
        return if (last.finished) info.episodes.getOrNull(idx + 1) else info.episodes[idx]
    }

    // ------------------------------------------- à regarder plus tard

    fun inWatchlist(key: String): Boolean = watchlist.any { it.key == key }

    /** @return true si ajouté, false si retiré. */
    fun toggleWatchlist(item: StreamItem): Boolean {
        val pid = profile?.id ?: return false
        val added = store.toggleWatchlist(pid, item)
        watchlist = store.watchlist(pid)
        return added
    }

    fun removeFromWatchlist(item: StreamItem) {
        val pid = profile?.id ?: return
        store.saveWatchlist(pid, store.watchlist(pid).filterNot { it.key == item.key })
        watchlist = store.watchlist(pid)
        reminder = reminder.filterNot { it.key == item.key }
    }

    var reminderIntervalHours: Int
        get() = store.reminderIntervalHours
        set(v) { store.reminderIntervalHours = v }

    var playlistRefreshMode: Int
        get() = store.playlistRefreshMode
        set(v) { store.playlistRefreshMode = v }

    val lastPlaylistRefresh: Long
        get() = store.lastPlaylistRefresh

    /**
     * Fait tourner les rappels sur la liste. Un rappel n'apparaît qu'après
     * l'intervalle choisi, avec une petite variation pour ne pas tomber
     * toujours à la même heure.
     */
    fun triggerReminder() {
        val pid = profile?.id ?: return
        val pool = watchlist
        if (pool.isEmpty() || reminder.isNotEmpty()) return
        if (screen is Screen.Player) return

        val hours = store.reminderIntervalHours
        if (hours <= 0) return

        val last = store.lastReminderAt(pid)
        val now = System.currentTimeMillis()
        if (last > 0) {
            val jitter = (0.85 + Math.random() * 0.3)
            val wait = (hours * 3_600_000L * jitter).toLong()
            if (now - last < wait) return
        }

        val take = minOf(3, pool.size)
        reminder = List(take) { pool[(reminderCursor + it) % pool.size] }
        reminderCursor += take
        store.setLastReminderAt(pid, now)
    }

    fun dismissReminder() { reminder = emptyList() }

    fun openReminder(item: StreamItem) {
        reminder = emptyList()
        // on ouvre la fiche, pas la lecture : on veut d'abord voir le résumé
        openItem(item)
    }

    // --- mise à jour ---------------------------------------------------

    /**
     * @param silent vérification automatique au lancement (limitée à une fois
     * toutes les 6 h, et respecte les versions ignorées).
     */
    fun checkForUpdate(silent: Boolean = false) {
        if (updateState is UpdateState.Downloading) return
        if (silent) {
            val since = System.currentTimeMillis() - store.lastUpdateCheck
            if (since < 6 * 60 * 60 * 1000L) return
        }
        updateState = UpdateState.Checking
        viewModelScope.launch {
            runCatching { updater.check(BuildConfig.UPDATE_URL, BuildConfig.VERSION_CODE) }
                .onSuccess { info ->
                    store.lastUpdateCheck = System.currentTimeMillis()
                    when {
                        info == null -> updateState = UpdateState.UpToDate
                        silent && info.versionCode == store.skippedVersion && !info.mandatory ->
                            updateState = UpdateState.UpToDate
                        else -> {
                            updateState = UpdateState.Available(info)
                            if (silent) updateBannerVisible = true else updateDialogVisible = true
                        }
                    }
                }
                .onFailure {
                    updateState = UpdateState.Failed(it.message ?: "Vérification impossible")
                    if (silent) updateState = UpdateState.Idle
                }
        }
    }

    fun openUpdateDialog() {
        updateBannerVisible = false
        updateDialogVisible = true
    }

    fun dismissUpdateBanner() {
        updateBannerVisible = false
    }

    fun dismissUpdateDialog() {
        if (updateState is UpdateState.Downloading) return
        updateDialogVisible = false
    }

    fun skipThisVersion() {
        (updateState as? UpdateState.Available)?.let { store.skippedVersion = it.info.versionCode }
        updateBannerVisible = false
        updateDialogVisible = false
        updateState = UpdateState.Idle
    }

    val canInstallApks: Boolean get() = updater.canInstall()

    fun requestInstallPermission() = updater.requestInstallPermission()

    fun downloadAndInstall() {
        val info = (updateState as? UpdateState.Available)?.info ?: return
        if (!updater.canInstall()) {
            updater.requestInstallPermission()
            return
        }
        updateState = UpdateState.Downloading(0f)
        viewModelScope.launch {
            runCatching {
                updater.download(info) { p -> updateState = UpdateState.Downloading(p) }
            }.onSuccess { file ->
                updateDialogVisible = false
                updateState = UpdateState.Idle
                runCatching { updater.install(file) }
                    .onFailure { updateState = UpdateState.Failed(it.message ?: "Installation impossible") }
            }.onFailure {
                updateState = UpdateState.Failed(it.message ?: "Téléchargement impossible")
            }
        }
    }

    // --- lecture -------------------------------------------------------

    fun livePreviewUrl(item: StreamItem): String? = client?.liveUrl(item.id)

    fun playLive(item: StreamItem) {
        val c = client ?: return
        go(Screen.Player(PlayRequest(
            url = c.liveUrl(item.id),
            title = item.name,
            subtitle = "En direct",
            isLive = true
        )))
    }

    fun openMovie(item: StreamItem) {
        go(Screen.MovieDetail(item))
        movieInfo = null
        movieLoading = true
        val c = client ?: return
        viewModelScope.launch {
            runCatching { c.vodInfo(item.id) }
                .onSuccess { movieInfo = it }
                .onFailure { error = it.message }
            movieLoading = false
        }
    }

    fun resumePositionFor(key: String): Long =
        profile?.let { store.resumePosition(it.id, key) } ?: 0L

    fun playMovie(
        item: StreamItem,
        ext: String? = null,
        fromStart: Boolean = false,
        mysteryMode: Boolean = false
    ) {
        val c = client ?: return
        val pid = profile?.id
        val extension = ext ?: item.containerExt
        val entry = HistoryEntry(
            key = item.key, type = ContentType.VOD, streamId = item.id,
            title = item.name, icon = item.icon, containerExt = extension
        )
        go(Screen.Player(PlayRequest(
            url = DownloadCenter.localUri(appContext, item.key) ?: c.movieUrl(item.id, extension),
            title = item.name,
            startMs = if (fromStart) 0L
            else pid?.let { store.resumePosition(it, item.key) } ?: 0L,
            history = entry,
            mysteryMode = mysteryMode
        )))
    }

    fun playEpisode(series: StreamItem, ep: Episode) {
        val c = client ?: return
        val pid = profile?.id
        val key = "SERIES:${ep.id}"
        val entry = HistoryEntry(
            key = key, type = ContentType.SERIES, streamId = ep.id,
            title = series.name,
            subtitle = "S${ep.season} E${ep.number} · ${ep.title}",
            icon = ep.cover ?: series.icon,
            containerExt = ep.ext,
            seriesId = series.id, season = ep.season, episode = ep.number
        )
        go(Screen.Player(PlayRequest(
            url = DownloadCenter.localUri(appContext, key) ?: c.episodeUrl(ep.id, ep.ext),
            title = series.name,
            subtitle = "S${ep.season} E${ep.number} · ${ep.title}",
            startMs = pid?.let { store.resumePosition(it, key) } ?: 0L,
            history = entry
        )))
    }

    /** Ouvre la fiche du titre plutôt que de relancer la lecture. */
    fun openSheetFromHistory(entry: HistoryEntry) {
        when (entry.type) {
            ContentType.SERIES -> {
                val id = entry.seriesId ?: return
                openSeries(
                    StreamItem(
                        id = id,
                        name = entry.title,
                        icon = entry.icon,
                        type = ContentType.SERIES
                    )
                )
            }

            ContentType.VOD -> openMovie(
                StreamItem(
                    id = entry.streamId,
                    name = entry.title,
                    icon = entry.icon,
                    type = ContentType.VOD,
                    containerExt = entry.containerExt
                )
            )

            ContentType.LIVE -> Unit
        }
    }

    fun resume(entry: HistoryEntry) {
        val c = client ?: return
        go(Screen.Player(PlayRequest(
            url = DownloadCenter.localUri(appContext, entry.key) ?: c.urlFor(entry),
            title = entry.title,
            subtitle = entry.subtitle,
            startMs = entry.positionMs,
            history = entry
        )))
    }

    /** Enregistre l'image capturée à l'arrêt et renvoie son chemin. */
    fun saveThumbnail(key: String, bitmap: android.graphics.Bitmap): String? = runCatching {
        val dir = java.io.File(appContext.filesDir, "thumbs").apply { mkdirs() }
        val file = java.io.File(dir, key.replace(":", "_") + ".jpg")
        val width = 480
        val height = (bitmap.height.toFloat() / bitmap.width * width).toInt().coerceAtLeast(1)
        val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, width, height, true)
        file.outputStream().use {
            scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 82, it)
        }
        scaled.recycle()
        file.absolutePath
    }.getOrNull()

    fun savePlaybackPosition(
        entry: HistoryEntry?,
        positionMs: Long,
        durationMs: Long,
        thumbnail: android.graphics.Bitmap? = null
    ) {
        val pid = profile?.id ?: return
        if (entry == null || positionMs < 10_000) return
        val thumbPath = thumbnail?.let { saveThumbnail(entry.key, it) }
        val updated = entry.copy(
            positionMs = positionMs,
            durationMs = durationMs,
            updatedAt = System.currentTimeMillis(),
            thumb = thumbPath ?: entry.thumb
        )
        store.recordProgress(pid, updated)
        if (updated.finished) recordCompletion(pid, updated)
        refreshHistory()
    }

    /** Marque un titre comme terminé et déclenche le trophée quand une série est bouclée. */
    private fun recordCompletion(pid: String, entry: HistoryEntry) {
        when (entry.type) {
            ContentType.VOD -> {
                val done = Completion(
                    key = entry.key,
                    type = ContentType.VOD,
                    title = entry.title,
                    icon = entry.icon
                )
                if (store.addCompletion(pid, done)) trophy = done
            }

            ContentType.SERIES -> {
                val seriesId = entry.seriesId ?: return
                store.markEpisodeDone(pid, seriesId, entry.streamId)
                store.addCompletion(
                    pid,
                    Completion(
                        key = entry.key,
                        type = ContentType.SERIES,
                        title = entry.title,
                        subtitle = entry.subtitle,
                        icon = entry.icon,
                        seriesId = seriesId
                    )
                )
                val total = store.seriesTotal(pid, seriesId)
                val done = store.episodesDone(pid, seriesId).size
                if (total > 0 && done >= total) {
                    val full = Completion(
                        key = "SERIESFULL:$seriesId",
                        type = ContentType.SERIES,
                        title = entry.title,
                        subtitle = "$total épisodes",
                        icon = entry.icon,
                        seriesId = seriesId,
                        fullSeries = true
                    )
                    if (store.addCompletion(pid, full)) trophy = full
                }
            }

            ContentType.LIVE -> Unit
        }
        completions = store.completions(pid)
        refreshRecommendations()
    }
}
