package fr.geeko.iptv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Client Xtream Codes (player_api.php).
 * Tolérant : les serveurs renvoient parfois des nombres, parfois des chaînes.
 */
class XtreamClient(rawHost: String, val username: String, val password: String) {

    val host: String = normalizeHost(rawHost)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    companion object {
        const val UA = "GeekoIPTV/1.0 (Android)"

        fun normalizeHost(input: String): String {
            var h = input.trim()
            if (h.isEmpty()) return h
            if (!h.startsWith("http://", true) && !h.startsWith("https://", true)) h = "http://$h"
            while (h.endsWith("/")) h = h.dropLast(1)
            return h
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun api(extra: String = ""): String =
        "$host/player_api.php?username=${enc(username)}&password=${enc(password)}$extra"

    private suspend fun fetch(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        http.newCall(req).execute().use { res ->
            if (res.code == 401 || res.code == 403) {
                throw XtreamException(
                    "Identifiants refusés par le serveur. Vérifie l'identifiant et le mot de passe."
                )
            }
            if (!res.isSuccessful) throw XtreamException("Erreur serveur (HTTP ${res.code})")
            res.body?.string()?.takeIf { it.isNotBlank() }
                ?: throw XtreamException("Réponse vide du serveur")
        }
    }

    private fun JSONObject.str(vararg names: String): String? {
        for (n in names) {
            if (has(n) && !isNull(n)) {
                val v = optString(n, "").trim()
                if (v.isNotEmpty() && v != "null") return v
            }
        }
        return null
    }

    private fun JSONObject.num(vararg names: String): Long =
        str(*names)?.filter { it.isDigit() }?.toLongOrNull() ?: 0L

    // ---------------------------------------------------------------- auth

    suspend fun authenticate(): Account {
        val body = fetch(api())
        val root = try { JSONObject(body) } catch (e: Exception) {
            throw XtreamException("Ce serveur ne répond pas en Xtream Codes")
        }
        val info = root.optJSONObject("user_info")
            ?: throw XtreamException("Réponse inattendue du serveur")
        if (info.str("auth") == "0") throw XtreamException("Identifiants refusés")

        val status = info.str("status") ?: "Inconnu"
        if (!status.equals("Active", true)) throw XtreamException("Compte $status")

        val server = root.optJSONObject("server_info")
        val exp = info.num("exp_date")
        val expLabel = if (exp > 0)
            SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(exp * 1000))
        else "Illimité"

        return Account(
            username = info.str("username") ?: username,
            status = status,
            expiry = expLabel,
            activeConnections = info.str("active_cons") ?: "0",
            maxConnections = info.str("max_connections") ?: "?",
            serverName = server?.str("url") ?: host.removePrefix("http://").removePrefix("https://")
        )
    }

    // ------------------------------------------------------------ listings

    suspend fun categories(type: ContentType): List<Category> {
        val arr = JSONArray(fetch(api("&action=${type.catAction}")))
        val out = ArrayList<Category>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.str("category_id") ?: continue
            out += Category(id, o.str("category_name") ?: "Sans nom", type)
        }
        return out
    }

    suspend fun streams(type: ContentType, categoryId: String? = null): List<StreamItem> {
        val extra = buildString {
            append("&action=${type.listAction}")
            if (categoryId != null) append("&category_id=${enc(categoryId)}")
        }
        val arr = JSONArray(fetch(api(extra)))
        val out = ArrayList<StreamItem>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = when (type) {
                ContentType.SERIES -> o.str("series_id")
                else -> o.str("stream_id")
            } ?: continue
            out += StreamItem(
                id = id,
                name = o.str("name", "title") ?: "Sans titre",
                icon = o.str("stream_icon", "cover", "movie_image"),
                type = type,
                containerExt = o.str("container_extension"),
                categoryId = o.str("category_id"),
                added = o.num("added", "last_modified"),
                plot = o.str("plot", "description"),
                rating = o.str("rating"),
                number = o.str("num")?.filter { it.isDigit() }?.toIntOrNull() ?: 0
            )
        }
        return out
    }

    /** backdrop_path est tantôt un tableau d'URL, tantôt une chaîne. */
    private fun backdropOf(o: JSONObject?): String? {
        if (o == null) return null
        o.optJSONArray("backdrop_path")?.let { arr ->
            (0 until arr.length())
                .map { arr.optString(it).trim() }
                .firstOrNull { it.isNotEmpty() && it != "null" }
                ?.let { return it }
        }
        return o.str("backdrop_path", "backdrop", "cover_big")
    }

    suspend fun vodInfo(streamId: String): MovieInfo {
        val root = JSONObject(fetch(api("&action=get_vod_info&vod_id=${enc(streamId)}")))
        val info = root.optJSONObject("info")
        val data = root.optJSONObject("movie_data")
        return MovieInfo(
            cover = info?.str("movie_image", "cover_big"),
            backdrop = backdropOf(info),
            plot = info?.str("plot", "description"),
            genre = info?.str("genre"),
            releaseDate = info?.str("releasedate", "releaseDate", "release_date"),
            rating = info?.str("rating"),
            cast = info?.str("cast", "actors"),
            director = info?.str("director"),
            durationLabel = info?.str("duration"),
            containerExt = data?.str("container_extension")
        )
    }

    suspend fun seriesInfo(seriesId: String): SeriesInfo {
        val root = JSONObject(fetch(api("&action=get_series_info&series_id=${enc(seriesId)}")))
        val info = root.optJSONObject("info")
        val eps = ArrayList<Episode>()
        root.optJSONObject("episodes")?.let { seasons ->
            val keys = seasons.keys()
            while (keys.hasNext()) {
                val seasonKey = keys.next()
                val list = seasons.optJSONArray(seasonKey) ?: continue
                for (i in 0 until list.length()) {
                    val e = list.optJSONObject(i) ?: continue
                    val epInfo = e.optJSONObject("info")
                    eps += Episode(
                        id = e.str("id") ?: continue,
                        title = e.str("title") ?: "Épisode",
                        ext = e.str("container_extension") ?: "mp4",
                        season = e.str("season")?.toIntOrNull()
                            ?: seasonKey.toIntOrNull() ?: 1,
                        number = e.str("episode_num")?.toIntOrNull() ?: (i + 1),
                        cover = epInfo?.str("movie_image", "cover_big"),
                        plot = epInfo?.str("plot", "description"),
                        durationSecs = epInfo?.str("duration_secs")?.toIntOrNull() ?: 0
                    )
                }
            }
        }
        eps.sortWith(compareBy({ it.season }, { it.number }))
        val backdrop = backdropOf(info)

        return SeriesInfo(
            cover = info?.str("cover"),
            plot = info?.str("plot", "description"),
            episodes = eps,
            backdrop = backdrop,
            genre = info?.str("genre"),
            releaseDate = info?.str("releaseDate", "release_date", "releasedate"),
            rating = info?.str("rating"),
            cast = info?.str("cast", "actors"),
            director = info?.str("director")
        )
    }

    // ----------------------------------------------------------------- EPG

    /** Programme d'une chaîne. Les titres arrivent encodés en base64. */
    suspend fun shortEpg(streamId: String, limit: Int = 12): List<EpgEntry> {
        val body = fetch(api("&action=get_short_epg&stream_id=${enc(streamId)}&limit=$limit"))
        val arr = runCatching { JSONObject(body).optJSONArray("epg_listings") }.getOrNull()
            ?: return emptyList()
        val out = ArrayList<EpgEntry>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val start = o.num("start_timestamp") * 1000L
            val end = o.num("stop_timestamp", "end_timestamp") * 1000L
            if (start <= 0L || end <= start) continue
            out += EpgEntry(
                title = decodeB64(o.str("title")) ?: "Programme",
                description = decodeB64(o.str("description")),
                startMs = start,
                endMs = end
            )
        }
        return out.sortedBy { it.startMs }
    }

    private fun decodeB64(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            String(android.util.Base64.decode(raw, android.util.Base64.DEFAULT))
                .trim().takeIf { it.isNotEmpty() }
        }.getOrNull() ?: raw
    }

    // ------------------------------------------------------------ play URLs

    fun liveUrl(streamId: String): String =
        "$host/live/${enc(username)}/${enc(password)}/$streamId.ts"

    fun movieUrl(streamId: String, ext: String?): String =
        "$host/movie/${enc(username)}/${enc(password)}/$streamId.${ext ?: "mp4"}"

    fun episodeUrl(episodeId: String, ext: String?): String =
        "$host/series/${enc(username)}/${enc(password)}/$episodeId.${ext ?: "mp4"}"

    fun urlFor(entry: HistoryEntry): String = when (entry.type) {
        ContentType.LIVE -> liveUrl(entry.streamId)
        ContentType.VOD -> movieUrl(entry.streamId, entry.containerExt)
        ContentType.SERIES -> episodeUrl(entry.streamId, entry.containerExt)
    }
}

class XtreamException(message: String) : Exception(message)
