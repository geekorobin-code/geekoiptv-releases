package fr.geeko.iptv.ui

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.AppearanceState

val LocalIsTv = staticCompositionLocalOf { false }

fun detectTv(context: Context): Boolean {
    val pm = context.packageManager
    if (pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)) return true
    if (pm.hasSystemFeature("android.software.leanback_only")) return true
    val ui = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
    return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
}

/**
 * Rend un élément visible quand il a le focus de la télécommande :
 * léger grossissement en ressort + liseré orange.
 * À placer AVANT le clickable dans la chaîne de modificateurs.
 */
@Composable
fun Modifier.tvFocus(
    shape: Shape = RoundedCornerShape(14.dp),
    scale: Float = 1.07f,
    borderWidth: Int = 3
): Modifier {
    if (!LocalIsTv.current) return this

    var focused by remember { mutableStateOf(false) }
    val animatedScale by animateFloatAsState(
        targetValue = if (focused) scale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow),
        label = "tv-focus-scale"
    )
    val animatedBorder by animateDpAsState(
        targetValue = if (focused) borderWidth.dp else 0.dp,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "tv-focus-border"
    )

    return this
        .onFocusChanged {
            // repère sonore : seulement à la prise de focus, jamais à la perte
            if (it.isFocused && !focused && AppearanceState.soundEnabled) Ticker.play()
            focused = it.isFocused
        }
        .graphicsLayer {
            scaleX = animatedScale
            scaleY = animatedScale
        }
        .border(animatedBorder, if (focused) Accent else Color.Transparent, shape)
}

/** Marges de sécurité pour les écrans de télé (overscan). */
@Composable
fun screenPadding(): PaddingValues =
    if (LocalIsTv.current) PaddingValues(horizontal = 40.dp, vertical = 24.dp)
    else PaddingValues(0.dp)
