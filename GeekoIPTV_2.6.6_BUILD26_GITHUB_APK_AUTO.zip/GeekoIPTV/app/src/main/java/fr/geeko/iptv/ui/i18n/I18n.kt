package fr.geeko.iptv.ui.i18n

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Traduction de l'interface.
 *
 * Le texte français sert de clé : une traduction absente retombe donc
 * naturellement sur le français au lieu d'afficher une clé technique.
 */
enum class Lang(val code: String, val label: String, val rtl: Boolean = false) {
    FR("fr", "Français"),
    EN("en", "English"),
    ES("es", "Español"),
    DE("de", "Deutsch"),
    IT("it", "Italiano"),
    RU("ru", "Русский"),
    AR("ar", "العربية", rtl = true),
    EL("el", "Ελληνικά"),
    ZH("zh", "中文"),
    KO("ko", "한국어"),
    JA("ja", "日本語");

    companion object {
        fun from(code: String?): Lang = entries.firstOrNull { it.code == code } ?: FR
    }
}

object I18n {
    /** État observable : changer la langue recompose toute l'interface. */
    var lang by mutableStateOf(Lang.FR)

    private val table: Map<String, Array<String>> by lazy {
        STRINGS_GENERAL + STRINGS_PLAYER + STRINGS_SETTINGS
    }

    fun translate(french: String): String {
        if (lang == Lang.FR) return french
        val row = table[french] ?: return french
        // index 0 = EN, la table ne contient pas le français
        val index = lang.ordinal - 1
        return row.getOrNull(index)?.takeIf { it.isNotBlank() } ?: french
    }
}

/** Traduit un texte de l'interface. */
fun tr(french: String): String = I18n.translate(french)

/**
 * Traduit puis remplace les repères {0}, {1}… par les valeurs fournies.
 * Permet de traduire des phrases contenant des nombres ou des noms.
 */
fun tr(french: String, vararg args: Any?): String {
    var out = I18n.translate(french)
    args.forEachIndexed { i, value -> out = out.replace("{$i}", value?.toString() ?: "") }
    return out
}

/** Ordre des colonnes : en, es, de, it, ru, ar, el, zh, ko, ja */
internal fun s(
    en: String, es: String, de: String, it: String, ru: String,
    ar: String, el: String, zh: String, ko: String, ja: String
): Array<String> = arrayOf(en, es, de, it, ru, ar, el, zh, ko, ja)
