package fr.geeko.iptv.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed as lazyItemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import fr.geeko.iptv.data.ContentType
import fr.geeko.iptv.data.HistoryEntry
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.ui.theme.*
import fr.geeko.iptv.ui.i18n.tr
import kotlinx.coroutines.launch

/**
 * Pinch à deux doigts pour ajuster continûment la taille des jaquettes.
 * Un doigt reste entièrement disponible pour le scroll normal de la grille.
 */
private fun Modifier.posterPinchZoom(
    enabled: Boolean,
    onZoom: (Float) -> Unit,
    onFinished: () -> Unit
): Modifier = if (!enabled) this else pointerInput(Unit) {
    awaitEachGesture {
        var previousDistance: Float? = null
        var zooming = false
        while (true) {
            val event = awaitPointerEvent()
            val pressed = event.changes.filter { it.pressed }
            if (pressed.size >= 2) {
                val delta = pressed[0].position - pressed[1].position
                val distance = delta.getDistance()
                previousDistance?.takeIf { it > 0f }?.let { old ->
                    val factor = (distance / old).coerceIn(0.85f, 1.15f)
                    if (factor.isFinite()) onZoom(factor)
                }
                previousDistance = distance
                zooming = true
                pressed.take(2).forEach { it.consume() }
            } else {
                previousDistance = null
                if (zooming) {
                    onFinished()
                    zooming = false
                }
                if (pressed.isEmpty()) break
            }
        }
        if (zooming) onFinished()
    }
}

private fun scaledPosterWidth(base: Int, isTv: Boolean): androidx.compose.ui.unit.Dp {
    if (isTv) return base.dp
    val scaled = base * AppearanceState.current.posterScale
    return scaled.coerceIn(64f, 220f).dp
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    val isTv = LocalIsTv.current
    val context = LocalContext.current
    var donationDialog by remember { mutableStateOf(false) }
    val wide = isTv || LocalConfiguration.current.screenWidthDp >= 720
    val cardWidth = if (isTv) 168.dp else if (wide) 146.dp else 118.dp

    var palette by remember { mutableStateOf<PaletteTarget?>(null) }
    val saveAppearance = { vm.saveAppearance() }

    LaunchedEffect(vm.profile?.id, vm.playlistRefreshMode) {
        if (vm.playlistRefreshMode == 1) {
            while (true) {
                kotlinx.coroutines.delay(2 * 60 * 60 * 1000L)
                vm.refreshHome()
            }
        }
    }

    Column(Modifier.fillMaxSize().appBackground().statusBarsPadding()) {

        if (wide) {
            // Barre supérieure : marque à gauche, page au centre,
            // profil et réglages à droite.
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 26.dp, end = 20.dp, top = 8.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .tvFocus(RoundedCornerShape(14.dp), 1.04f)
                            .clickable { donationDialog = true }
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Geeko", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "IPTV",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = Accent
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    RoundAction(Icons.Default.Refresh, "Actualiser les listes") {
                        vm.refreshHome()
                    }
                }

                Text(
                    vm.selectedCategory?.name ?: tr(vm.tab.label),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(2f),
                    textAlign = TextAlign.Center
                )

                Row(
                    Modifier.weight(1f),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SearchEntry(
                        onClick = {
                            if (isTv) vm.voiceRequested = true
                            vm.go(Screen.Search)
                        },
                        onVoice = {
                            vm.voiceRequested = true
                            vm.go(Screen.Search)
                        },
                        compact = true
                    )
                    Spacer(Modifier.width(4.dp))
                    RoundAction(Icons.Default.Person, tr("Changer de profil"), filled = true) {
                        vm.leaveProfile()
                    }
                    Spacer(Modifier.width(6.dp))
                    RoundAction(Icons.Default.Download, "Téléchargements") {
                        vm.go(Screen.Downloads)
                    }
                    Spacer(Modifier.width(8.dp))
                    ImageRoundAction(
                        drawable = fr.geeko.iptv.R.drawable.ic_settings_geeko,
                        label = tr("Réglages")
                    ) {
                        vm.go(Screen.Settings)
                    }
                }
            }

            TopNav(vm)
        } else {
            TopArea(
                vm, wide,
                onPalette = { palette = PaletteTarget.BACKGROUND },
                onSaveAppearance = saveAppearance
            )
        }

        ErrorBar(vm.error) { vm.error = null }

        Box(Modifier.weight(1f)) {
            when {
                vm.tab == HomeTab.ACCUEIL -> AccueilTab(vm, cardWidth)
                vm.tab == HomeTab.WATCHLIST -> TrophyTab(vm)
                vm.tab == HomeTab.MOSAIC -> MosaicTab(vm)
                vm.tab == HomeTab.GUIDE || vm.tab == HomeTab.LIVE -> GuideScreen(vm)
                wide -> MasterDetail(
                    vm = vm,
                    type = vm.tab.toContentType(),
                    isTv = isTv,
                    onPalette = { palette = PaletteTarget.PANEL }
                )
                vm.selectedCategory != null -> StreamGrid(vm, isTv)
                else -> CategoryTab(vm, vm.tab.toContentType(), wide)
            }
        }

        if (!wide) BottomBar(vm)
        if (wide) Spacer(Modifier.navigationBarsPadding())
    }

    if (donationDialog) {
        AlertDialog(
            onDismissRequest = { donationDialog = false },
            shape = RoundedCornerShape(28.dp),
            containerColor = Surface1,
            tonalElevation = 10.dp,
            title = { Text("❤️ Soutenir GeekoIPTV", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Si GeekoIPTV te plaît, tu peux soutenir son développement avec un don. " +
                        "Aucune publicité ni demande automatique.",
                    color = TextMid
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val url = vm.store.donationUrl
                        if (url.isNotBlank()) {
                            runCatching {
                                context.startActivity(
                                    android.content.Intent(
                                        android.content.Intent.ACTION_VIEW,
                                        android.net.Uri.parse(url)
                                    )
                                )
                            }
                        } else {
                            android.widget.Toast.makeText(
                                context,
                                "Ajoute d’abord ton lien de don dans Réglages > Compte.",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        }
                        donationDialog = false
                    }
                ) { Text("Faire un don") }
            },
            dismissButton = {
                TextButton(onClick = { donationDialog = false }) { Text("Plus tard") }
            }
        )
    }

    palette?.let { target ->
        PaletteDialog(
            target = target,
            onSave = saveAppearance,
            onDismiss = { palette = null }
        )
    }

}

/**
 * Barre de navigation en arc : les bords plongent légèrement, comme sur la
 * maquette. Le tracé est calculé à la volée pour s'adapter à la largeur.
 */
private val ArcBarShape = androidx.compose.foundation.shape.GenericShape { size, _ ->
    // Courbe très douce : contrairement à l'ancienne forme, le bord inférieur
    // reste toujours dans les limites du composant et ne peut plus couper les
    // libellés Accueil/Favoris aux extrémités.
    val r = size.height * 0.28f
    val topEdge = size.height * 0.06f
    val bottomEdge = size.height * 0.94f
    val centerLift = size.height * 0.035f

    moveTo(r, topEdge)
    cubicTo(
        size.width * 0.30f, 0f,
        size.width * 0.70f, 0f,
        size.width - r, topEdge
    )
    quadraticBezierTo(size.width, topEdge, size.width, r)
    lineTo(size.width, size.height - r)
    quadraticBezierTo(size.width, bottomEdge, size.width - r, bottomEdge)
    cubicTo(
        size.width * 0.70f, bottomEdge - centerLift,
        size.width * 0.30f, bottomEdge - centerLift,
        r, bottomEdge
    )
    quadraticBezierTo(0f, bottomEdge, 0f, size.height - r)
    lineTo(0f, r)
    quadraticBezierTo(0f, topEdge, r, topEdge)
    close()
}

/** Petit bouton rond de la barre supérieure. */
@Composable
private fun RoundAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    filled: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (filled) Accent else Surface2)
            .tvFocus(CircleShape, scale = 1.12f)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (filled) Color.White else TextMid,
            modifier = Modifier.size(19.dp)
        )
    }
}

/** Bouton rond utilisant un asset couleur, pour les actions TV premium. */
@Composable
private fun ImageRoundAction(
    drawable: Int,
    label: String,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Surface2)
            .tvFocus(CircleShape, scale = 1.13f, borderWidth = 2)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = androidx.compose.ui.res.painterResource(drawable),
            contentDescription = label,
            modifier = Modifier.size(36.dp)
        )
    }
}


private val VisibleHomeTabs = listOf(
    HomeTab.ACCUEIL, HomeTab.LIVE, HomeTab.VOD, HomeTab.SERIES, HomeTab.MOSAIC, HomeTab.WATCHLIST
)

/**
 * Navigation principale sur grand écran : une barre horizontale au lieu du
 * rail vertical, qui rend toute la largeur aux jaquettes.
 */
@Composable
private fun TopNav(vm: AppViewModel) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 34.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            Modifier
                .fillMaxWidth(0.82f)
                .height(68.dp)
                .clip(ArcBarShape)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF071628).copy(alpha = 0.98f),
                            Surface1.copy(alpha = 0.98f),
                            Color(0xFF06101D).copy(alpha = 0.99f)
                        )
                    )
                )
                .border(1.dp, Accent.copy(alpha = 0.50f), ArcBarShape)
                .padding(horizontal = 18.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            VisibleHomeTabs.forEach { t ->
                val selected = vm.tab == t
                val itemShape = RoundedCornerShape(22.dp)
                Column(
                    Modifier
                        .widthIn(min = 78.dp)
                        .height(50.dp)
                        .clip(itemShape)
                        .background(
                            if (selected) {
                                Brush.verticalGradient(
                                    listOf(
                                        Accent.copy(alpha = 0.24f),
                                        Color(0xFF06283A).copy(alpha = 0.82f)
                                    )
                                )
                            } else {
                                Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                            }
                        )
                        .then(
                            if (selected) Modifier.border(1.5.dp, Accent.copy(alpha = 0.85f), itemShape)
                            else Modifier
                        )
                        .tvFocus(itemShape, scale = 1.08f, borderWidth = 2)
                        .clickable { switchTab(vm, t) }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    TabIcon(t, selected, size = if (selected) 22 else 20)
                    Spacer(Modifier.height(1.dp))
                    Text(
                        tr(t.label),
                        color = if (selected) Color.White else TextMid,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                    if (selected) {
                        Spacer(Modifier.height(1.dp))
                        Box(
                            Modifier
                                .width(34.dp)
                                .height(2.dp)
                                .clip(CircleShape)
                                .background(Accent)
                        )
                    }
                }
            }
        }
    }
}

private fun HomeTab.toContentType(): ContentType = when (this) {
    HomeTab.LIVE, HomeTab.GUIDE -> ContentType.LIVE
    HomeTab.VOD, HomeTab.WATCHLIST, HomeTab.MOSAIC -> ContentType.VOD
    else -> ContentType.SERIES
}

/**
 * Icône d'un onglet. Les Films ont un pot de pop-corn dessiné à part :
 * il porte ses propres couleurs, donc pas de teinte appliquée.
 */
@Composable
private fun TabIcon(t: HomeTab, selected: Boolean, size: Int = 34) {
    val drawable = when (t) {
        HomeTab.ACCUEIL -> fr.geeko.iptv.R.drawable.ic_tab_accueil
        HomeTab.LIVE -> fr.geeko.iptv.R.drawable.ic_tab_tv
        HomeTab.GUIDE -> fr.geeko.iptv.R.drawable.ic_tab_guide_tv
        HomeTab.VOD -> fr.geeko.iptv.R.drawable.ic_tab_films
        HomeTab.SERIES -> fr.geeko.iptv.R.drawable.ic_tab_series
        HomeTab.MOSAIC -> fr.geeko.iptv.R.drawable.ic_tab_mosaique
        HomeTab.WATCHLIST -> fr.geeko.iptv.R.drawable.ic_tab_trophy
    }
    Image(
        painter = androidx.compose.ui.res.painterResource(drawable),
        contentDescription = tr(t.label),
        modifier = Modifier
            .size(size.dp)
            .alpha(if (selected) 1f else 0.82f)
    )
}

private fun switchTab(vm: AppViewModel, t: HomeTab) {
    vm.tab = t
    vm.selectedCategory = null
    vm.manageMode = false
    vm.clearCatSelection()
    when (t) {
        HomeTab.LIVE, HomeTab.GUIDE -> vm.loadCategories(ContentType.LIVE)
        HomeTab.VOD -> {
            vm.loadCategories(ContentType.VOD)
            vm.visibleCategories(ContentType.VOD).firstOrNull()?.let { vm.openCategory(it) }
        }
        HomeTab.SERIES -> {
            vm.loadCategories(ContentType.SERIES)
            vm.visibleCategories(ContentType.SERIES).firstOrNull()?.let { vm.openCategory(it) }
        }
        HomeTab.ACCUEIL -> vm.refreshHistory()
        HomeTab.WATCHLIST -> Unit
        HomeTab.MOSAIC -> vm.loadMosaic()
    }
}

// -------------------------------------------------------------- navigation


@Composable
private fun BottomBar(vm: AppViewModel) {
    NavigationBar(containerColor = Surface1) {
        VisibleHomeTabs.forEach { t ->
            NavigationBarItem(
                selected = vm.tab == t,
                onClick = { switchTab(vm, t) },
                icon = { TabIcon(t, vm.tab == t, size = 22) },
                // avec sept onglets, les libellés permanents passent à la ligne
                alwaysShowLabel = false,
                label = {
                    Text(
                        tr(t.label),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Accent,
                    selectedTextColor = Accent,
                    indicatorColor = Accent.copy(alpha = 0.16f),
                    unselectedIconColor = TextLow,
                    unselectedTextColor = TextLow
                )
            )
        }
    }
}

// ----------------------------------------------------------- barre du haut

@Composable
private fun TopArea(
    vm: AppViewModel,
    wide: Boolean,
    onPalette: () -> Unit,
    onSaveAppearance: () -> Unit
) {
    var overflow by remember { mutableStateOf(false) }
    val isTvHere = LocalIsTv.current
    val context = LocalContext.current
    val canCastHere = remember(context) { !isTvHere && castAvailable(context) }
    val canManage = vm.tab != HomeTab.ACCUEIL && vm.tab != HomeTab.GUIDE &&
        vm.tab != HomeTab.MOSAIC
    val canLayout = vm.tab == HomeTab.VOD || vm.tab == HomeTab.SERIES ||
        vm.tab == HomeTab.LIVE || vm.tab == HomeTab.WATCHLIST

    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (vm.selectedCategory != null) {
            IconButton(
                onClick = { vm.selectedCategory = null },
                modifier = Modifier.tvFocus(scale = 1.05f)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
            }
        } else {
            Spacer(Modifier.width(8.dp))
        }

        Text(
            vm.selectedCategory?.name ?: tr(vm.tab.label),
            fontSize = 19.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )

        Spacer(Modifier.weight(1f))

        SearchEntry(
            onClick = {
                // Au D-pad, taper est pénible : on ouvre directement la dictée.
                if (isTvHere) vm.voiceRequested = true
                vm.go(Screen.Search)
            },
            onVoice = {
                vm.voiceRequested = true
                vm.go(Screen.Search)
            },
            compact = !wide,
            modifier = if (wide) Modifier.width(320.dp) else Modifier
        )

        if (canCastHere) {
            CastButton()
            Spacer(Modifier.width(2.dp))
        }

        if (wide) {
            // sur grand écran il y a la place pour tout afficher
            if (canLayout) {
                LayoutButton(onSaveAppearance)
                Spacer(Modifier.width(8.dp))
            }
            PaletteButton(onPalette)
            Spacer(Modifier.width(8.dp))

            if (canManage) {
                TextButton(
                    onClick = {
                        vm.manageMode = !vm.manageMode
                        vm.clearCatSelection()
                    },
                    modifier = Modifier.tvFocus(scale = 1.04f)
                ) {
                    Icon(
                        if (vm.manageMode) Icons.Default.Check else Icons.Default.Tune,
                        contentDescription = null,
                        tint = if (vm.manageMode) Accent else TextMid,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (vm.manageMode) tr("Terminé") else tr("Gérer les groupes"),
                        color = if (vm.manageMode) Accent else TextMid,
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }
            }
        } else {
            // sur téléphone, tout le reste passe dans un menu :
            // aligner ces boutons sur une seule ligne faisait déborder la barre
            Box {
                IconButton(
                    onClick = { overflow = true },
                    modifier = Modifier.tvFocus(scale = 1.05f)
                ) {
                    Icon(Icons.Default.MoreVert, contentDescription = tr("Plus d'options"))
                }

                DropdownMenu(expanded = overflow, onDismissRequest = { overflow = false }) {
                    if (canManage) {
                        DropdownMenuItem(
                            leadingIcon = {
                                Icon(
                                    if (vm.manageMode) Icons.Default.Check else Icons.Default.Tune,
                                    contentDescription = null
                                )
                            },
                            text = {
                                Text(
                                    if (vm.manageMode) tr("Terminé")
                                    else tr("Gérer les groupes")
                                )
                            },
                            onClick = {
                                vm.manageMode = !vm.manageMode
                                vm.clearCatSelection()
                                overflow = false
                            }
                        )
                    }
                    if (canLayout) {
                        LayoutMode.entries.forEachIndexed { index, mode ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        tr(mode.label),
                                        color = if (index == AppearanceState.current.layout)
                                            Accent else TextHigh
                                    )
                                },
                                onClick = {
                                    AppearanceState.current =
                                        AppearanceState.current.copy(layout = index)
                                    onSaveAppearance()
                                    overflow = false
                                }
                            )
                        }
                        HorizontalDivider()
                    }
                    DropdownMenuItem(
                        leadingIcon = {
                            Icon(Icons.Default.Palette, contentDescription = null)
                        },
                        text = { Text(tr("Personnaliser")) },
                        onClick = { overflow = false; onPalette() }
                    )
                    DropdownMenuItem(
                        leadingIcon = {
                            Icon(Icons.Default.Settings, contentDescription = null)
                        },
                        text = { Text(tr("Réglages")) },
                        onClick = { overflow = false; vm.go(Screen.Settings) }
                    )
                    DropdownMenuItem(
                        leadingIcon = {
                            Icon(Icons.Default.SwitchAccount, contentDescription = null)
                        },
                        text = { Text(tr("Changer de profil")) },
                        onClick = { overflow = false; vm.leaveProfile() }
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchEntry(
    onClick: () -> Unit,
    onVoice: () -> Unit,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val voiceReady = remember { voiceSearchAvailable(context) }

    if (compact) {
        Row {
            IconButton(onClick = onClick, modifier = Modifier.tvFocus(scale = 1.05f)) {
                Icon(Icons.Default.Search, contentDescription = tr("Rechercher"))
            }
            if (voiceReady) {
                IconButton(onClick = onVoice, modifier = Modifier.tvFocus(scale = 1.05f)) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = tr("Recherche vocale"),
                        tint = Accent
                    )
                }
            }
        }
        return
    }
    Row(
        modifier
            .height(42.dp)
            .clip(RoundedCornerShape(21.dp))
            .background(Surface2)
            .tvFocus(RoundedCornerShape(21.dp), scale = 1.03f)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Default.Search, contentDescription = null,
            tint = TextLow, modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            tr("Rechercher une chaîne, un film…"),
            color = TextLow, fontSize = 13.sp, maxLines = 1,
            modifier = Modifier.weight(1f)
        )
        if (voiceReady) {
            Box(
                Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .tvFocus(RoundedCornerShape(15.dp), scale = 1.1f)
                    .clickable(onClick = onVoice),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Mic,
                    contentDescription = tr("Recherche vocale"),
                    tint = Accent,
                    modifier = Modifier.size(17.dp)
                )
            }
        }
    }
}

// ------------------------------------------------------------------ accueil

@Composable
private fun AccueilTab(vm: AppViewModel, cardWidth: androidx.compose.ui.unit.Dp) {
    var resumeMenu by remember { mutableStateOf<HistoryEntry?>(null) }
    val isTvHome = LocalIsTv.current
    val discoveryCardWidth = if (isTvHome) 84.dp else cardWidth
    val context = LocalContext.current
    val profileId = vm.profile?.id.orEmpty()
    val onboardingPrefs = remember(context) { context.getSharedPreferences("geeko_theme_onboarding", android.content.Context.MODE_PRIVATE) }
    // v2 : l'ancienne invitation marquait le profil comme "vu" avant même que
    // l'utilisateur ait réellement pu choisir un thème. On utilise une nouvelle
    // clé pour reproposer une fois le sélecteur corrigé.
    val onboardingKey = "theme_picker_v2_$profileId"
    var showThemeInvite by remember(profileId) {
        mutableStateOf(profileId.isNotBlank() && !onboardingPrefs.getBoolean(onboardingKey, false))
    }
    if (showThemeInvite) {
        val featuredThemes = remember {
            ThemePresets.filter { it.texture in 8..12 }
        }
        AlertDialog(
            // Un clic à côté / BACK équivaut à "Plus tard", mais un clic sur
            // "Choisir" ne ferme plus une première fenêtre pour en ouvrir une autre :
            // le choix se fait directement ici.
            onDismissRequest = {
                onboardingPrefs.edit().putBoolean(onboardingKey, true).apply()
                showThemeInvite = false
            },
            title = { Text("Choisis ton thème") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Tu peux donner tout de suite une ambiance différente à ce profil.",
                        color = TextLow,
                        fontSize = 13.sp
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        items(featuredThemes.size) { i ->
                            val preset = featuredThemes[i]
                            Column(
                                Modifier
                                    .width(118.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(
                                        1.dp,
                                        TextLow.copy(alpha = 0.35f),
                                        RoundedCornerShape(16.dp)
                                    )
                                    .tvFocus(RoundedCornerShape(16.dp), 1.06f)
                                    .clickable {
                                        applyPreset(preset)
                                        vm.saveAppearance()
                                        onboardingPrefs.edit().putBoolean(onboardingKey, true).apply()
                                        showThemeInvite = false
                                    }
                                    .padding(7.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                ThemePreview(
                                    background = Color(preset.background),
                                    rail = Color(preset.rail),
                                    panel = Color(preset.panel),
                                    accent = Color(preset.accent),
                                    texture = preset.texture,
                                    modifier = Modifier.fillMaxWidth().height(64.dp)
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    preset.name,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                    Text(
                        "Tu pourras le modifier plus tard dans Réglages > Apparence.",
                        color = TextLow,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = {
                    onboardingPrefs.edit().putBoolean(onboardingKey, true).apply()
                    showThemeInvite = false
                }) { Text("Plus tard") }
            }
        )
    }

    // Salutation, compteurs et état de l'abonnement retirés d'ici : ils
    // occupaient le haut de l'écran sans rien apporter au quotidien.
    // Tout cela reste consultable dans Réglages > Compte.
    LazyColumn(contentPadding = PaddingValues(top = 4.dp, bottom = 28.dp)) {

        item {
            Row(
                Modifier
                    .padding(start = 20.dp, top = 4.dp, bottom = 10.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Accent.copy(alpha = 0.18f))
                    .tvFocus(RoundedCornerShape(22.dp), scale = 1.05f)
                    .clickable { vm.openRandom() }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Casino,
                    contentDescription = null,
                    tint = Accent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(9.dp))
                Text(tr("Au hasard"), color = Accent, fontSize = 14.sp)
            }
        }

        if (vm.homeLoading) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Chargement et mise à jour des listes de lecture…",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text("Veuillez patienter quelques instants.", color = TextLow, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        color = Accent,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        val resumeSeries = vm.historyOf(ContentType.SERIES)
        val resumeMovies = vm.historyOf(ContentType.VOD)

        if (resumeSeries.isNotEmpty()) {
            item { SectionHeader(tr("Séries en cours"), count = resumeSeries.size) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(resumeSeries, key = { it.key }) { h ->
                        ResumeCard(
                            h,
                            onClick = { if (isTvHome) resumeMenu = h else vm.resume(h) },
                            onRemove = { resumeMenu = h }
                        )
                    }
                }
            }
        }

        if (resumeMovies.isNotEmpty()) {
            item { SectionHeader(tr("Films en cours"), count = resumeMovies.size) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(resumeMovies, key = { it.key }) { h ->
                        ResumeCard(
                            h,
                            onClick = { if (isTvHome) resumeMenu = h else vm.resume(h) },
                            onRemove = { resumeMenu = h }
                        )
                    }
                }
            }
        }

        if (vm.recommendations.isNotEmpty()) {
            item {
                Column {
                    SectionHeader(
                        tr("Ça pourrait vous plaire"),
                        onSeeAll = {
                            vm.go(Screen.Collection(
                                tr("Ça pourrait vous plaire"),
                                vm.recommendations
                            ))
                        }
                    )
                    vm.recoReason?.let {
                        Text(
                            tr("D'après ce que tu as regardé, comme « {0} »", it),
                            color = TextLow,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(start = 20.dp, bottom = 8.dp)
                        )
                    }
                }
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(vm.recommendations, key = { it.key }) { r ->
                        MediaCard(
                            item = r,
                            subtitle = vm.categoryName(r),
                            marked = vm.inWatchlist(r.key),
                            blurb = vm.blurbOf(r),
                            onRequestBlurb = { vm.ensureBlurb(r) },
                            completed = vm.isDone(r),
                            fullSeries = r.type == ContentType.SERIES && vm.isSeriesComplete(r.id),
                            onClick = { vm.openItem(r) },
                            onLongClick = { vm.toggleWatchlist(r) },
                            modifier = Modifier.width(discoveryCardWidth)
                        )
                    }
                }
            }
        }

        if (vm.completions.isNotEmpty()) {
            item {
                SectionHeader(
                    tr("Terminés"),
                    count = vm.completions.count { it.fullSeries || it.type == ContentType.VOD },
                    onSeeAll = { vm.go(Screen.Completed) }
                )
            }
        }

        if (vm.recentSeries.isNotEmpty()) {
            item {
                SectionHeader(tr("Séries récemment ajoutées"), onSeeAll = {
                    vm.go(Screen.Collection(tr("Séries récemment ajoutées"), vm.allSeries.filter { it.type == ContentType.SERIES }.take(200)))
                })
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(vm.recentSeries, key = { it.key }) { s ->
                        MediaCard(
                            item = s,
                            subtitle = vm.categoryName(s),
                            marked = vm.inWatchlist(s.key),
                            blurb = vm.blurbOf(s),
                            onRequestBlurb = { vm.ensureBlurb(s) },
                            completed = vm.isDone(s),
                            fullSeries = s.type == ContentType.SERIES && vm.isSeriesComplete(s.id),
                            onClick = { vm.openSeries(s) },
                            onLongClick = { vm.toggleWatchlist(s) },
                            modifier = Modifier.width(discoveryCardWidth)
                        )
                    }
                }
            }
        }

        if (vm.recentMovies.isNotEmpty()) {
            item {
                SectionHeader(tr("Films récemment ajoutés"), onSeeAll = {
                    vm.go(Screen.Collection(tr("Films récemment ajoutés"), vm.allMovies.take(200)))
                })
            }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(vm.recentMovies, key = { it.key }) { m ->
                        MediaCard(
                            item = m,
                            subtitle = vm.categoryName(m),
                            marked = vm.inWatchlist(m.key),
                            blurb = vm.blurbOf(m),
                            onRequestBlurb = { vm.ensureBlurb(m) },
                            completed = vm.isDone(m),
                            fullSeries = m.type == ContentType.SERIES && vm.isSeriesComplete(m.id),
                            onClick = { vm.openMovie(m) },
                            onLongClick = { vm.toggleWatchlist(m) },
                            modifier = Modifier.width(discoveryCardWidth)
                        )
                    }
                }
            }
        }

        if (!vm.homeLoading && vm.history.isEmpty() &&
            vm.recentMovies.isEmpty() && vm.recentSeries.isEmpty()
        ) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(tr("Rien à afficher pour l'instant"), color = TextLow)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { vm.refreshHome() }) { Text(tr("Recharger")) }
                }
            }
        }
    }

    resumeMenu?.let { entry ->
        AlertDialog(
            onDismissRequest = { resumeMenu = null },
            title = { Text(entry.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    entry.subtitle?.let {
                        Text(it, color = TextLow, fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                    }
                    ActionRow(
                        icon = Icons.Default.Info,
                        label = if (entry.type == ContentType.SERIES)
                            tr("Voir la fiche et les épisodes") else tr("Voir la fiche")
                    ) {
                        resumeMenu = null
                        vm.openSheetFromHistory(entry)
                    }
                    ActionRow(
                        icon = Icons.Default.PlayArrow,
                        label = tr("Reprendre la lecture")
                    ) {
                        resumeMenu = null
                        vm.resume(entry)
                    }
                    ActionRow(
                        icon = Icons.Default.Delete,
                        label = tr("Retirer de la liste"),
                        danger = true
                    ) {
                        resumeMenu = null
                        vm.removeFromHistory(entry.key)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { resumeMenu = null }) { Text(tr("Annuler")) }
            }
        )
    }
}

@Composable
private fun ActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    danger: Boolean = false,
    onClick: () -> Unit
) {
    val tint = if (danger) MaterialTheme.colorScheme.error else TextHigh
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .tvFocus(RoundedCornerShape(14.dp), scale = 1.02f)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, fontSize = 14.sp, color = tint)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaRow(
    item: StreamItem,
    subtitle: String? = null,
    marked: Boolean = false,
    completed: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Surface1)
            .tvFocus(RoundedCornerShape(14.dp), scale = 1.02f)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Poster(
            item.icon,
            item.name,
            Modifier.size(width = 64.dp, height = if (item.type == ContentType.LIVE) 64.dp else 92.dp),
            ratio = if (item.type == ContentType.LIVE) 1f else 2f / 3f,
            corner = 10,
            scale = androidx.compose.ui.layout.ContentScale.Crop
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(3.dp))
                Text(
                    subtitle,
                    color = TextLow,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (completed) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Accent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(8.dp))
        }
        if (marked) {
            Icon(
                Icons.Default.Star,
                contentDescription = null,
                tint = Color(0xFFFFD54F),
                modifier = Modifier.size(21.dp)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ResumeCard(entry: HistoryEntry, onClick: () -> Unit, onRemove: () -> Unit) {
    val frame = entry.thumb?.let { java.io.File(it) }?.takeIf { it.exists() }
    val isTv = LocalIsTv.current

    Column(
        Modifier
            .width(if (isTv) { if (frame != null) 128.dp else 96.dp } else { if (frame != null) 226.dp else 148.dp })
            .tvFocus(RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onLongClick = onRemove)
    ) {
        Box {
            if (frame != null) {
                // image du moment exact où la lecture s'est arrêtée
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Surface2)
                        .border(1.5.dp, Accent.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                ) {
                    coil.compose.AsyncImage(
                        model = frame,
                        contentDescription = entry.title,
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else {
                Poster(entry.icon, entry.title, Modifier.fillMaxWidth())
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 10.dp)
            ) {
                ProgressStrip(entry.progress, Modifier.fillMaxWidth())
            }
            Box(
                Modifier
                    .align(Alignment.Center)
                    .size(42.dp)
                    .clip(RoundedCornerShape(21.dp))
                    .background(Color.Black.copy(alpha = 0.55f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.PlayArrow, contentDescription = null,
                    tint = Color.White, modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            entry.title, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        entry.subtitle?.let {
            Text(it, fontSize = 12.sp, color = TextLow, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ------------------------------------------------------------ « Ma liste »

@Composable
private fun WatchlistTab(vm: AppViewModel, isTv: Boolean) {
    val list = vm.watchlist

    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.BookmarkBorder,
                    contentDescription = null,
                    tint = TextLow,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text(tr("Ta liste est vide"), color = TextLow, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    tr("Appui long sur une jaquette pour l'ajouter."),
                    color = TextLow, fontSize = 12.sp
                )
            }
        }
        return
    }

    val layout = currentLayout()
    when (layout) {
        LayoutMode.CAROUSEL -> CoverCarousel(
            entries = list,
            subtitleOf = { vm.categoryName(it) },
            markedOf = { true },
            onClick = { vm.openItem(it) },
            onLongClick = { vm.removeFromWatchlist(it) },
            cardWidth = layout.cardWidth,
            blurbOf = { vm.blurbOf(it) },
            onRequestBlurb = { vm.ensureBlurb(it) },
            doneOf = { vm.isDone(it) }
        )

        LayoutMode.LIST -> LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.key }) { w ->
                MediaRow(
                    item = w,
                    subtitle = vm.categoryName(w),
                    marked = true,
                    completed = vm.isDone(w),
                    onClick = { vm.openItem(w) },
                    onLongClick = { vm.removeFromWatchlist(w) }
                )
            }
        }

        else -> LazyVerticalGrid(
            columns = GridCells.Adaptive(scaledPosterWidth(layout.cardWidth, isTv)),
            modifier = Modifier.posterPinchZoom(
                enabled = !isTv,
                onZoom = { factor ->
                    AppearanceState.current = AppearanceState.current.copy(
                        posterScale = (AppearanceState.current.posterScale * factor).coerceIn(0.55f, 1.75f)
                    )
                },
                onFinished = { vm.saveAppearance() }
            ),
            contentPadding = PaddingValues(20.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(list, key = { it.key }) { w ->
                MediaCard(
                    item = w,
                    subtitle = vm.categoryName(w),
                    marked = true,
                    blurb = vm.blurbOf(w),
                    onRequestBlurb = { vm.ensureBlurb(w) },
                    completed = vm.isDone(w),
                    fullSeries = w.type == ContentType.SERIES && vm.isSeriesComplete(w.id),
                    onClick = { vm.openItem(w) },
                    onLongClick = { vm.removeFromWatchlist(w) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// --------------------------------------------------------------- catégories

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CategoryTab(vm: AppViewModel, type: ContentType, wide: Boolean) {
    LaunchedEffect(type) { vm.loadCategories(type) }
    val cats = if (vm.manageMode) vm.allCategories(type) else vm.visibleCategories(type)

    Column(Modifier.fillMaxSize()) {
        if (cats.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                if (vm.categories[type] == null) CircularProgressIndicator(color = Accent)
                else Text(tr("Tous les groupes sont masqués"), color = TextLow)
            }
            return@Column
        }

        LazyVerticalGrid(
            columns = GridCells.Adaptive(if (wide) 240.dp else 168.dp),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(cats, key = { it.id }) { cat ->
                val hidden = vm.isHidden(type, cat.id)
                val checked = cat.id in vm.selectedCats
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (checked) Accent.copy(alpha = 0.18f) else Surface1)
                        .tvFocus(RoundedCornerShape(16.dp), scale = 1.03f)
                        .combinedClickable(
                            onClick = {
                                if (vm.manageMode) vm.toggleCatSelection(cat.id)
                                else vm.openCategory(cat)
                            },
                            onLongClick = { vm.manageMode = true; vm.toggleCatSelection(cat.id) }
                        )
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (vm.manageMode) {
                        Checkbox(
                            checked = checked,
                            onCheckedChange = { vm.toggleCatSelection(cat.id) },
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                    } else {
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Accent.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                when (type) {
                                    ContentType.LIVE -> Icons.Default.LiveTv
                                    ContentType.VOD -> Icons.Default.Movie
                                    ContentType.SERIES -> Icons.Default.Tv
                                },
                                contentDescription = null,
                                tint = Accent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                    }
                    Text(
                        cat.name, Modifier.weight(1f), fontSize = 14.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 17.sp,
                        color = if (hidden) TextLow else TextHigh
                    )
                    if (hidden) {
                        Icon(
                            Icons.Default.VisibilityOff, contentDescription = tr("Masqué"),
                            tint = TextLow, modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}


// ------------------------------------------------- colonne + contenu (large)

@Composable
private fun MasterDetail(
    vm: AppViewModel,
    type: ContentType,
    isTv: Boolean,
    onPalette: () -> Unit
) {
    LaunchedEffect(type) { vm.loadCategories(type) }

    Row(Modifier.fillMaxSize()) {
        CategoryColumn(
            vm, type,
            Modifier
                .width(158.dp)
                .padding(start = 6.dp, end = 4.dp, top = 2.dp, bottom = 10.dp),
            onPalette = onPalette
        )

        Box(Modifier.weight(1f).fillMaxHeight()) {
            when {
                vm.selectedCategory == null -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text(
                        tr("Choisis un groupe à gauche"),
                        color = TextLow, fontSize = 14.sp
                    )
                }
                else -> StreamGrid(vm, isTv)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CategoryColumn(
    vm: AppViewModel,
    type: ContentType,
    modifier: Modifier = Modifier,
    onPalette: () -> Unit = {}
) {
    var reorderTick by remember(type) { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE")
    val forceRecomposeForOrder = reorderTick
    val cats = if (vm.manageMode) vm.allCategories(type) else vm.visibleCategories(type)
    val isTvGroups = LocalIsTv.current
    var hideCandidate by remember { mutableStateOf<fr.geeko.iptv.data.Category?>(null) }
    var hideDialogOpenedAt by remember { mutableLongStateOf(0L) }

    Column(
        modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Surface2.copy(alpha = 0.94f),
                        Color(0xFF08111F).copy(alpha = 0.90f),
                        Surface1.copy(alpha = 0.96f)
                    )
                )
            )
            .border(1.dp, Accent.copy(alpha = 0.18f), RoundedCornerShape(24.dp))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 18.dp, end = 12.dp, top = 12.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("${cats.size} groupe(s)", Modifier.weight(1f), color = TextLow, fontSize = 11.sp)
            PaletteButton(onPalette)
        }
        if (cats.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                if (vm.categories[type] == null) CircularProgressIndicator(color = Accent)
                else Text(tr("Tous les groupes sont masqués"), color = TextLow, fontSize = 13.sp)
            }
            return@Column
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(cats, key = { it.id }) { cat ->
                val selected = vm.selectedCategory?.id == cat.id
                val hidden = vm.isHidden(type, cat.id)
                val checked = cat.id in vm.selectedCats
                var groupPressStartedAt by remember(cat.id) { mutableLongStateOf(0L) }
                var groupLongPressFired by remember(cat.id) { mutableStateOf(false) }
                var groupLongJob by remember(cat.id) { mutableStateOf<kotlinx.coroutines.Job?>(null) }
                val groupScope = rememberCoroutineScope()

                Row(
                    Modifier
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            when {
                                selected && !vm.manageMode -> Brush.horizontalGradient(
                                    listOf(Accent.copy(alpha = 0.28f), Accent.copy(alpha = 0.07f))
                                )
                                hidden -> Brush.horizontalGradient(
                                    listOf(Color.White.copy(alpha = 0.035f), Color.Transparent)
                                )
                                else -> Brush.horizontalGradient(
                                    listOf(Color.White.copy(alpha = 0.025f), Color.Transparent)
                                )
                            }
                        )
                        .then(
                            if (selected && !vm.manageMode)
                                Modifier.border(1.dp, Accent.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
                            else Modifier
                        )
                        .tvFocus(RoundedCornerShape(18.dp), scale = 1.02f)
                        .onPreviewKeyEvent { event ->
                            if (!isTvGroups || vm.manageMode) return@onPreviewKeyEvent false
                            val center = event.key == androidx.compose.ui.input.key.Key.DirectionCenter ||
                                event.key == androidx.compose.ui.input.key.Key.Enter
                            if (!center) return@onPreviewKeyEvent false
                            val nowUptime = android.os.SystemClock.uptimeMillis()
                            when (event.type) {
                                androidx.compose.ui.input.key.KeyEventType.KeyDown -> {
                                    if (groupPressStartedAt == 0L) {
                                        groupPressStartedAt = nowUptime
                                        groupLongJob?.cancel()
                                        groupLongJob = groupScope.launch {
                                            kotlinx.coroutines.delay(450L)
                                            if (groupPressStartedAt != 0L && !groupLongPressFired && cat.id != "__favorites__") {
                                                groupLongPressFired = true
                                                hideDialogOpenedAt = android.os.SystemClock.uptimeMillis()
                                                hideCandidate = cat
                                            }
                                        }
                                    }
                                    groupLongPressFired
                                }
                                androidx.compose.ui.input.key.KeyEventType.KeyUp -> {
                                    val consumed = groupLongPressFired
                                    groupLongJob?.cancel()
                                    groupLongJob = null
                                    groupPressStartedAt = 0L
                                    groupLongPressFired = false
                                    consumed
                                }
                                else -> false
                            }
                        }
                        .combinedClickable(
                            onClick = {
                                if (vm.manageMode) vm.toggleCatSelection(cat.id)
                                else vm.openCategory(cat)
                            },
                            onLongClick = {
                                if (vm.manageMode) vm.toggleCatSelection(cat.id)
                                else if (!isTvGroups && cat.id != "__favorites__") { hideDialogOpenedAt = android.os.SystemClock.uptimeMillis(); hideCandidate = cat }
                            }
                        )
                        .padding(horizontal = 10.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (vm.manageMode) {
                        Checkbox(
                            checked = checked,
                            onCheckedChange = { vm.toggleCatSelection(cat.id) },
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                    }
                    Row(
                        Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            cat.name,
                            Modifier.weight(1f),
                            fontSize = 12.5.sp,
                            maxLines = 2,
                            lineHeight = 16.sp,
                            overflow = TextOverflow.Ellipsis,
                            color = when {
                                hidden -> TextLow
                                selected && !vm.manageMode -> TextHigh
                                else -> TextMid
                            },
                            fontWeight = if (selected && !vm.manageMode) FontWeight.SemiBold else FontWeight.Normal
                        )
                        if (cat.type == ContentType.VOD || cat.type == ContentType.SERIES) {
                            Spacer(Modifier.width(5.dp))
                            Text(
                                "(${vm.categoryCount(cat)})",
                                color = if (selected && !vm.manageMode) Accent else Accent.copy(alpha = 0.72f),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }
                    if (hidden) {
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            Icons.Default.VisibilityOff,
                            contentDescription = tr("Masqué"),
                            tint = TextLow,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }

        if (vm.manageMode) {
            ManageBar(vm, type)
        }
    }

    hideCandidate?.let { cat ->
        androidx.compose.ui.window.Dialog(
            onDismissRequest = {
                if (android.os.SystemClock.uptimeMillis() - hideDialogOpenedAt > 650L) {
                    hideCandidate = null
                }
            }
        ) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = Surface1.copy(alpha = 0.98f),
                tonalElevation = 10.dp,
                shadowElevation = 18.dp,
                modifier = Modifier
                    .widthIn(min = 520.dp, max = 680.dp)
                    .border(1.dp, Accent.copy(alpha = 0.30f), RoundedCornerShape(28.dp))
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text("Gérer ce groupe", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text(cat.name, color = TextMid, fontSize = 14.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = {
                                vm.moveCategory(cat, -1)
                                reorderTick++
                            },
                            modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(18.dp), 1.04f),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(Icons.Default.KeyboardArrowUp, null)
                            Spacer(Modifier.width(5.dp))
                            Text("Monter")
                        }
                        OutlinedButton(
                            onClick = {
                                vm.moveCategory(cat, 1)
                                reorderTick++
                            },
                            modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(18.dp), 1.04f),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(Icons.Default.KeyboardArrowDown, null)
                            Spacer(Modifier.width(5.dp))
                            Text("Descendre")
                        }
                        OutlinedButton(
                            onClick = {
                                vm.setCategoryHidden(type, cat.id, true)
                                hideCandidate = null
                            },
                            modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(18.dp), 1.04f),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.VisibilityOff, null)
                            Spacer(Modifier.width(5.dp))
                            Text("Masquer")
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Tu peux appuyer plusieurs fois sur Monter ou Descendre : le déplacement est visible immédiatement.",
                        color = TextLow,
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    TextButton(
                        onClick = { hideCandidate = null },
                        modifier = Modifier.align(Alignment.End).tvFocus(RoundedCornerShape(16.dp), 1.04f)
                    ) { Text("Fermer") }
                }
            }
        }
    }

}

@Composable
private fun ManageBar(vm: AppViewModel, type: ContentType) {
    val n = vm.selectedCats.size
    Surface(
        color = Surface1.copy(alpha = 0.97f),
        shape = RoundedCornerShape(18.dp),
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 7.dp)
            .border(1.dp, Accent.copy(alpha = 0.22f), RoundedCornerShape(18.dp))
    ) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 8.dp)) {
            Text(
                if (n == 0) "Sélectionne les groupes" else "$n sélectionné(s)",
                color = if (n == 0) TextLow else Accent,
                fontSize = 10.5.sp,
                maxLines = 1
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { vm.setHiddenForSelection(type, true) },
                    enabled = n > 0,
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 9.dp, vertical = 5.dp),
                    modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(14.dp), 1.04f)
                ) { Text(tr("Masquer"), fontSize = 10.5.sp, maxLines = 1) }

                OutlinedButton(
                    onClick = { vm.setHiddenForSelection(type, false) },
                    enabled = n > 0,
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 5.dp),
                    modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(14.dp), 1.04f)
                ) { Text(tr("Réafficher"), fontSize = 10.5.sp, maxLines = 1) }
            }
        }
    }
}

// ------------------------------------------------------- contenu d'un groupe

@Composable
private fun StreamGrid(vm: AppViewModel, isTv: Boolean) {
    val cat = vm.selectedCategory ?: return
    var filterOpen by remember(cat.id) { mutableStateOf(false) }
    val context = LocalContext.current
    fun toggleFavorite(item: StreamItem) {
        val added = vm.toggleWatchlist(item)
        android.widget.Toast.makeText(
            context,
            if (added) "Ajouté aux favoris" else "Retiré des favoris",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }

    var livePreview by remember(cat.id) { mutableStateOf<StreamItem?>(null) }
    fun openOrPreview(item: StreamItem, index: Int) {
        vm.saveBrowsePosition(cat.id, index.coerceAtLeast(0))
        if (isTv && cat.type == ContentType.LIVE) {
            if (livePreview?.key == item.key) vm.playLive(item)
            else livePreview = item
        } else {
            vm.openItem(item)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(tr("Trier"), color = TextLow, fontSize = 12.sp)
            Spacer(Modifier.width(2.dp))
            val modes =
                if (cat.type == ContentType.LIVE)
                    listOf(SortMode.NUMBER, SortMode.ALPHA, SortMode.ADDED)
                else listOf(SortMode.ADDED, SortMode.ALPHA, SortMode.RATING)
            modes.forEach { mode ->
                FilterChip(
                    selected = vm.sortMode == mode,
                    onClick = { vm.sortMode = mode },
                    shape = RoundedCornerShape(18.dp),
                    label = { Text(tr(mode.label), fontSize = 12.sp) },
                    modifier = Modifier.tvFocus(RoundedCornerShape(18.dp), 1.05f)
                )
            }

            Spacer(Modifier.weight(1f))

            // Le sélecteur d'affichage vivait dans l'ancienne barre du haut,
            // remplacée sur grand écran : il revient ici, près du tri.
            var layoutOpen by remember { mutableStateOf(false) }
            Box {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(Surface2)
                        .tvFocus(RoundedCornerShape(18.dp), scale = 1.06f)
                        .clickable { layoutOpen = true }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.GridView,
                        contentDescription = tr("Disposition"),
                        tint = TextMid,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(tr(currentLayout().label), color = TextMid, fontSize = 12.sp)
                }

                DropdownMenu(expanded = layoutOpen, onDismissRequest = { layoutOpen = false }) {
                    LayoutMode.entries.forEachIndexed { index, mode ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    tr(mode.label),
                                    color = if (index == AppearanceState.current.layout)
                                        Accent else TextHigh
                                )
                            },
                            onClick = {
                                AppearanceState.current =
                                    AppearanceState.current.copy(layout = index)
                                vm.saveAppearance()
                                layoutOpen = false
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.width(8.dp))

            if (cat.type != ContentType.LIVE) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(Accent.copy(alpha = 0.18f))
                        .tvFocus(RoundedCornerShape(18.dp), scale = 1.06f)
                        .clickable { vm.openRandom() }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Casino,
                        contentDescription = null,
                        tint = Accent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(tr("Au hasard"), color = Accent, fontSize = 12.sp)
                }
                Spacer(Modifier.width(8.dp))
            }

            // Le filtre finit la rangée, à droite : un champ de saisie posé sur
            // le trajet du focus ouvrait le clavier à chaque passage.
            if (!filterOpen) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (vm.search.isBlank()) Surface2 else Accent.copy(alpha = 0.22f))
                        .tvFocus(RoundedCornerShape(18.dp), scale = 1.06f)
                        .clickable { filterOpen = true }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = tr("Filtrer"),
                        tint = if (vm.search.isBlank()) TextLow else Accent,
                        modifier = Modifier.size(16.dp)
                    )
                    if (vm.search.isNotBlank()) {
                        Spacer(Modifier.width(6.dp))
                        Text(
                            vm.search,
                            color = TextHigh,
                            fontSize = 12.sp,
                            maxLines = 1,
                            modifier = Modifier.widthIn(max = 110.dp)
                        )
                    }
                }

                if (vm.search.isNotBlank()) {
                    Spacer(Modifier.width(4.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .tvFocus(RoundedCornerShape(16.dp), scale = 1.1f)
                            .clickable { vm.search = "" }
                            .padding(6.dp)
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = tr("Effacer"),
                            tint = TextLow,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        if (filterOpen) {
            val filterFocus = remember { FocusRequester() }
            LaunchedEffect(Unit) { runCatching { filterFocus.requestFocus() } }

            OutlinedTextField(
                value = vm.search,
                onValueChange = { vm.search = it },
                placeholder = { Text(tr("Filtrer dans ce groupe")) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    IconButton(onClick = { filterOpen = false }) {
                        Icon(Icons.Default.Check, contentDescription = tr("Terminé"))
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { filterOpen = false }),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = Surface2,
                    focusedContainerColor = Surface2,
                    unfocusedBorderColor = Color.Transparent
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .focusRequester(filterFocus)
            )
        }

        if (isTv && cat.type == ContentType.LIVE && livePreview != null) {
            LiveChannelPreview(
                vm = vm,
                item = livePreview!!,
                onFullscreen = { vm.playLive(livePreview!!) },
                onClose = { livePreview = null }
            )
        }

        if (vm.listLoading) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
            return@Column
        }

        val items = vm.filteredStreams
        val layout = currentLayout()

        when (layout) {
            LayoutMode.CAROUSEL -> CoverCarousel(
                entries = items,
                subtitleOf = { vm.categoryName(it) },
                markedOf = { vm.inWatchlist(it.key) },
                onClick = {
                    openOrPreview(it, items.indexOfFirst { x -> x.key == it.key })
                },
                onLongClick = { toggleFavorite(it) },
                cardWidth = layout.cardWidth,
                blurbOf = { vm.blurbOf(it) },
                onRequestBlurb = { vm.ensureBlurb(it) },
                doneOf = { vm.isDone(it) },
                initialIndex = vm.browsePosition(cat.id)
            )

            LayoutMode.LIST -> LazyColumn(
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                lazyItemsIndexed(items, key = { _, it -> it.key }) { index, s ->
                    MediaRow(
                        item = s,
                        subtitle = vm.categoryName(s),
                        marked = vm.inWatchlist(s.key),
                        completed = vm.isDone(s),
                        onClick = { openOrPreview(s, index) },
                        onLongClick = { toggleFavorite(s) }
                    )
                }
            }

            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(scaledPosterWidth(layout.cardWidth, isTv)),
                modifier = Modifier.posterPinchZoom(
                    enabled = !isTv,
                    onZoom = { factor ->
                        AppearanceState.current = AppearanceState.current.copy(
                            posterScale = (AppearanceState.current.posterScale * factor).coerceIn(0.55f, 1.75f)
                        )
                    },
                    onFinished = { vm.saveAppearance() }
                ),
                contentPadding = PaddingValues(
                    start = 20.dp, end = 20.dp, top = 4.dp, bottom = 28.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                gridItemsIndexed(items, key = { _, it -> it.key }) { index, s ->
                    MediaCard(
                        item = s,
                        marked = vm.inWatchlist(s.key),
                        blurb = vm.blurbOf(s),
                        onRequestBlurb = { vm.ensureBlurb(s) },
                        completed = vm.isDone(s),
                        fullSeries = s.type == ContentType.SERIES && vm.isSeriesComplete(s.id),
                        onClick = { openOrPreview(s, index) },
                        onLongClick = { toggleFavorite(s) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun LiveChannelPreview(
    vm: AppViewModel,
    item: StreamItem,
    onFullscreen: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val url = vm.livePreviewUrl(item) ?: return
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.End
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.Black,
            tonalElevation = 4.dp,
            modifier = Modifier
                .width(230.dp)
                .tvFocus(RoundedCornerShape(18.dp), scale = 1.025f)
                .clickable(onClick = onFullscreen)
        ) {
            Column {
                Box(Modifier.fillMaxWidth().height(121.dp)) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                useController = false
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                                this.player = player
                            }
                        },
                        update = { it.player = player },
                        modifier = Modifier.fillMaxSize()
                    )
                    Row(
                        Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.Black.copy(alpha = 0.72f),
                            modifier = Modifier
                                .size(34.dp)
                                .tvFocus(CircleShape, 1.08f)
                                .clickable(onClick = onClose)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Close, contentDescription = "Fermer l'aperçu", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("OK : plein écran", color = TextLow, fontSize = 9.sp)
                    }
                    Icon(Icons.Default.Fullscreen, contentDescription = "Plein écran", tint = Accent, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun TrophyTab(vm: AppViewModel) {
    val goldCups = vm.completions.count { it.type == ContentType.VOD || it.fullSeries }
    val points = goldCups * 1000
    Column(
        Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFFFC928), modifier = Modifier.size(92.dp))
        Spacer(Modifier.height(10.dp))
        Text("Trophées", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("1 coupe d'or = 1000 points", color = TextLow, fontSize = 14.sp)
        Spacer(Modifier.height(26.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Surface(color = Surface2, shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(horizontal = 34.dp, vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🏆", fontSize = 34.sp)
                    Text("$goldCups", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("coupes d'or", color = TextLow)
                }
            }
            Surface(color = Surface2, shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(horizontal = 34.dp, vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$points", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFC928))
                    Text("points", color = TextLow)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Chaque film terminé ou série entièrement terminée ajoute une coupe d'or.", color = TextMid)
    }
}

// ---------------------------------------------------------- « Tout voir »

@Composable
fun CollectionScreen(vm: AppViewModel, title: String, items: List<StreamItem>) {
    val isTv = LocalIsTv.current
    Column(Modifier.fillMaxSize().appBackground().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 6.dp, end = 20.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.back() }, modifier = Modifier.tvFocus(scale = 1.05f)) {
                Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
            }
            Spacer(Modifier.width(4.dp))
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }
        val layout = currentLayout()
        when (layout) {
            LayoutMode.CAROUSEL -> CoverCarousel(
                entries = items,
                subtitleOf = { vm.categoryName(it) },
                markedOf = { vm.inWatchlist(it.key) },
                onClick = { vm.openItem(it) },
                onLongClick = { vm.toggleWatchlist(it) },
                cardWidth = layout.cardWidth,
                blurbOf = { vm.blurbOf(it) },
                onRequestBlurb = { vm.ensureBlurb(it) },
                doneOf = { vm.isDone(it) }
            )
            LayoutMode.LIST -> LazyColumn(
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items, key = { it.key }) { s ->
                    MediaRow(
                        item = s,
                        subtitle = vm.categoryName(s),
                        marked = vm.inWatchlist(s.key),
                        completed = vm.isDone(s),
                        onClick = { vm.openItem(s) },
                        onLongClick = { vm.toggleWatchlist(s) }
                    )
                }
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(scaledPosterWidth(layout.cardWidth, isTv)),
                modifier = Modifier.posterPinchZoom(
                    enabled = !isTv,
                    onZoom = { factor ->
                        AppearanceState.current = AppearanceState.current.copy(
                            posterScale = (AppearanceState.current.posterScale * factor).coerceIn(0.55f, 1.75f)
                        )
                    },
                    onFinished = { vm.saveAppearance() }
                ),
                contentPadding = PaddingValues(20.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(items, key = { it.key }) { s ->
                    MediaCard(
                        item = s,
                        subtitle = vm.categoryName(s),
                        marked = vm.inWatchlist(s.key),
                        blurb = vm.blurbOf(s),
                        onRequestBlurb = { vm.ensureBlurb(s) },
                        completed = vm.isDone(s),
                        fullSeries = s.type == ContentType.SERIES && vm.isSeriesComplete(s.id),
                        onClick = { vm.openItem(s) },
                        onLongClick = { vm.toggleWatchlist(s) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
