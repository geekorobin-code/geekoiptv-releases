package fr.geeko.iptv.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Bref repère sonore au déplacement dans les menus.
 *
 * Le son est synthétisé à la volée : pas de fichier à embarquer, et un volume
 * très bas pour rester discret même en enchaînant les déplacements.
 */
object Ticker {

    private const val SAMPLE_RATE = 22050
    private var lastPlayed = 0L
    private var cached: ByteArray? = null

    private fun buffer(): ByteArray = cached ?: build().also { cached = it }

    private fun build(): ByteArray {
        val durationMs = 26
        val count = SAMPLE_RATE * durationMs / 1000
        val out = ByteArray(count * 2)

        for (i in 0 until count) {
            val t = i.toDouble() / SAMPLE_RATE
            // deux harmoniques courtes, étouffées très vite : un « tic » mat
            val tone = sin(2 * PI * 1180 * t) * 0.7 + sin(2 * PI * 2360 * t) * 0.3
            val envelope = exp(-t * 190)
            val value = (tone * envelope * Short.MAX_VALUE * 0.16).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            out[i * 2] = (value and 0xff).toByte()
            out[i * 2 + 1] = (value shr 8 and 0xff).toByte()
        }
        return out
    }

    fun play() {
        // Un déplacement maintenu enverrait des dizaines de tics par seconde.
        val now = System.currentTimeMillis()
        if (now - lastPlayed < 55) return
        lastPlayed = now

        runCatching {
            val data = buffer()
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(data.size)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(data, 0, data.size)
            track.setVolume(0.35f)
            track.setNotificationMarkerPosition(data.size / 2)
            track.setPlaybackPositionUpdateListener(
                object : AudioTrack.OnPlaybackPositionUpdateListener {
                    override fun onMarkerReached(t: AudioTrack?) {
                        runCatching { t?.release() }
                    }

                    override fun onPeriodicNotification(t: AudioTrack?) {}
                }
            )
            track.play()
        }
    }
}
