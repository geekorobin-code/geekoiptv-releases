package fr.geeko.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.Gold
import fr.geeko.iptv.ui.theme.Mint
import fr.geeko.iptv.ui.theme.Surface2
import fr.geeko.iptv.ui.theme.Surface3
import fr.geeko.iptv.ui.theme.TextLow
import fr.geeko.iptv.ui.theme.TextMid
import fr.geeko.iptv.ui.i18n.tr

@Composable
fun Poster(
    url: String?,
    label: String,
    modifier: Modifier = Modifier,
    ratio: Float = 2f / 3f,
    corner: Int = 16,
    scale: ContentScale = ContentScale.Crop,
    bordered: Boolean = true
) {
    val shape = RoundedCornerShape(corner.dp)
    Box(
        modifier
            .aspectRatio(ratio)
            .clip(shape)
            .background(Surface2)
            .then(
                if (bordered) Modifier.border(
                    width = 1.5.dp,
                    color = Accent.copy(alpha = 0.35f),
                    shape = shape
                ) else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        if (!url.isNullOrBlank()) {
            AsyncImage(
                model = url,
                contentDescription = label,
                contentScale = scale,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                label.take(28),
                color = TextLow,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 15.sp,
                modifier = Modifier.padding(10.dp)
            )
        }
    }
}

/** Pastille de note en haut à droite d'une jaquette. */
@Composable
fun RatingBadge(rating: String, modifier: Modifier = Modifier) {
    Surface(
        color = Color.Black.copy(alpha = 0.66f),
        shape = RoundedCornerShape(9.dp),
        modifier = modifier.padding(7.dp)
    ) {
        Row(
            Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Star,
                contentDescription = null,
                tint = Gold,
                modifier = Modifier.size(11.dp)
            )
            Spacer(Modifier.width(3.dp))
            Text(rating, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Coupe dorée + coche verte : l'œuvre est terminée. */
@Composable
fun CompletedBadge(fullSeries: Boolean, modifier: Modifier = Modifier) {
    Row(
        modifier.padding(7.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (fullSeries) {
            Box(
                Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Gold),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.EmojiEvents,
                    contentDescription = tr("Série terminée"),
                    tint = Color(0xFF3A2A00),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
        Box(
            Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Mint),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Check,
                contentDescription = tr("Vu"),
                tint = Color(0xFF04231A),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun BookmarkBadge(modifier: Modifier = Modifier) {
    Box(
        modifier
            .padding(7.dp)
            .size(24.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Accent),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Default.Bookmark,
            contentDescription = tr("Dans ta liste"),
            tint = Color.White,
            modifier = Modifier.size(13.dp)
        )
    }
}

/** Titre de section, avec compteur facultatif et lien « Tout voir ». */
@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    count: Int? = null,
    onSeeAll: (() -> Unit)? = null
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 12.dp, top = 18.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        if (count != null) {
            Spacer(Modifier.width(9.dp))
            Surface(color = Surface3, shape = RoundedCornerShape(9.dp)) {
                Text(
                    count.toString(),
                    color = TextMid,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(Modifier.weight(1f))
        if (onSeeAll != null) {
            TextButton(onClick = onSeeAll, modifier = Modifier.tvFocus(scale = 1.04f)) {
                Text(tr("Tout voir"), color = Accent, fontSize = 14.sp)
                Spacer(Modifier.width(4.dp))
                Icon(
                    Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = Accent,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
fun ErrorBar(message: String?, onDismiss: () -> Unit) {
    if (message == null) return
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(message, Modifier.weight(1f), fontSize = 13.sp)
            TextButton(onClick = onDismiss) { Text("OK") }
        }
    }
}

@Composable
fun ProgressStrip(progress: Float, modifier: Modifier = Modifier) {
    Box(
        Modifier
            .height(4.dp)
            .then(modifier)
            .clip(RoundedCornerShape(3.dp))
            .background(Color.White.copy(alpha = 0.22f))
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress.coerceIn(0.02f, 1f))
                .background(Brush.horizontalGradient(listOf(Accent, Accent)))
        )
    }
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, color: Color = Surface3) {
    Surface(color = color, shape = RoundedCornerShape(20.dp), modifier = modifier) {
        Text(
            text,
            color = TextMid,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun greeting(): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when {
        h < 6 -> tr("Bonne nuit")
        h < 12 -> tr("Bonjour")
        h < 18 -> tr("Bon après-midi")
        else -> tr("Bonsoir")
    }
}
