package fr.geeko.iptv.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SystemUpdateAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.Mint
import fr.geeko.iptv.ui.theme.Surface1
import fr.geeko.iptv.ui.theme.Surface2
import fr.geeko.iptv.ui.theme.TextLow
import kotlin.math.roundToInt
import fr.geeko.iptv.ui.i18n.tr

/** Bandeau discret qui descend du haut quand une nouvelle version est dispo. */
@Composable
fun UpdateBanner(
    visible: Boolean,
    versionName: String,
    mandatory: Boolean,
    onOpen: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isTv = LocalIsTv.current
    var dragOffset by remember(visible) { mutableFloatStateOf(0f) }

    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(
            visible = visible,
            enter = slideInVertically(
                initialOffsetY = { -it - 40 },
                animationSpec = spring(
                    dampingRatio = 0.62f,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) + fadeIn(tween(220)) + scaleIn(
                initialScale = 0.9f,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow)
            ),
            exit = slideOutVertically(
                targetOffsetY = { -it - 40 },
                animationSpec = spring(dampingRatio = 1f, stiffness = Spring.StiffnessMedium)
            ) + fadeOut(tween(150)) + scaleOut(targetScale = 0.94f)
        ) {
            Row(
                Modifier
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .offset { IntOffset(0, dragOffset.roundToInt()) }
                    .pointerInput(mandatory) {
                        if (mandatory) return@pointerInput
                        detectVerticalDragGestures(
                            onDragEnd = { if (dragOffset < -48f) onDismiss() else dragOffset = 0f },
                            onVerticalDrag = { _, delta ->
                                dragOffset = (dragOffset + delta).coerceIn(-260f, 24f)
                            }
                        )
                    }
                    .shadow(14.dp, RoundedCornerShape(30.dp), clip = false)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Brush.horizontalGradient(listOf(Surface1, Surface2)))
                    .border(1.dp, Mint.copy(alpha = 0.4f), RoundedCornerShape(30.dp))
                    .clickable(enabled = !isTv) { onOpen() }
                    .padding(start = 16.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(21.dp))
                        .background(Mint.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.SystemUpdateAlt,
                        contentDescription = null,
                        tint = Mint,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(Modifier.width(14.dp))

                Column(Modifier.weight(1f)) {
                    Text(
                        if (mandatory) tr("MISE À JOUR REQUISE") else tr("NOUVELLE VERSION"),
                        color = Mint,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        "GeekoIPTV $versionName est disponible",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                    Text(tr("Appuie pour voir les nouveautés"), color = TextLow, fontSize = 12.sp)
                }

                if (!mandatory && !isTv) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = tr("Plus tard"),
                            tint = TextLow,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

/** Détail de la version, notes, téléchargement avec progression. */
@Composable
fun UpdateDialog(vm: AppViewModel) {
    if (!vm.updateDialogVisible) return

    val state = vm.updateState
    val info = (state as? UpdateState.Available)?.info
    val downloading = state as? UpdateState.Downloading

    // pendant le téléchargement l'info n'est plus dans l'état : on la garde
    var kept by remember { mutableStateOf(info) }
    LaunchedEffect(info) { if (info != null) kept = info }
    val shown = kept ?: return

    AlertDialog(
        onDismissRequest = { vm.dismissUpdateDialog() },
        icon = {
            Icon(Icons.Default.SystemUpdateAlt, contentDescription = null, tint = Mint)
        },
        title = { Text("GeekoIPTV ${shown.versionName}") },
        text = {
            Column(Modifier.heightIn(max = 340.dp)) {
                Text(
                    "Installée : ${vm.currentVersionName} (build ${vm.currentVersionCode})",
                    color = TextLow, fontSize = 12.sp
                )
                Spacer(Modifier.height(12.dp))

                if (shown.notes.isNotBlank()) {
                    Text(
                        shown.notes,
                        fontSize = 14.sp,
                        modifier = Modifier.verticalScroll(rememberScrollState()).weight(1f, false)
                    )
                }

                if (!vm.canInstallApks) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Android va d'abord te demander d'autoriser GeekoIPTV à installer des applications.",
                        color = Accent, fontSize = 12.sp
                    )
                }

                downloading?.let { d ->
                    Spacer(Modifier.height(16.dp))
                    LinearProgressIndicator(
                        progress = { d.progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Téléchargement… ${(d.progress * 100).roundToInt()} %",
                        color = TextLow, fontSize = 12.sp
                    )
                }

                (state as? UpdateState.Failed)?.let {
                    Spacer(Modifier.height(12.dp))
                    Text(it.message, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { vm.downloadAndInstall() },
                enabled = downloading == null
            ) {
                Text(if (downloading == null) tr("Installer") else tr("En cours…"))
            }
        },
        dismissButton = {
            if (downloading == null) {
                Row {
                    if (!shown.mandatory) {
                        TextButton(onClick = { vm.skipThisVersion() }) { Text(tr("Ignorer")) }
                    }
                    TextButton(onClick = { vm.dismissUpdateDialog() }) { Text(tr("Plus tard")) }
                }
            }
        }
    )
}
