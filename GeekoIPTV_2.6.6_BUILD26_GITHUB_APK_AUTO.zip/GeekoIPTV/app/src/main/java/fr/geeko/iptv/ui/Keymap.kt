package fr.geeko.iptv.ui

import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.Surface1
import fr.geeko.iptv.ui.theme.TextLow
import fr.geeko.iptv.ui.i18n.tr

/** Actions assignables à une touche de la télécommande, dans le lecteur. */
enum class PlayerAction(
    val id: String,
    val label: String,
    val defaultKey: String,
    val isHold: Boolean = false
) {
    PLAY_PAUSE("play_pause", "Lecture / pause", "OK, Play-Pause"),
    SEEK_FORWARD("seek_fwd", "Avancer de 10 s", "Droite (appui bref)"),
    SEEK_BACK("seek_back", "Reculer de 10 s", "Gauche (appui bref)"),
    BOOST_HOLD("boost_hold", "Accélérer tant que maintenu", "Droite (maintenue)", isHold = true),
    BOOST_LOCK("boost_lock", tr("Vitesse rapide verrouillée"), "—"),
    AUDIO_TOGGLE("audio", "Changer de langue", "Haut"),
    SUBS_TOGGLE("subs", "Sous-titres on / off", "Bas"),
    SPEED_UP("speed_up", tr("Vitesse +0,25"), "—"),
    SPEED_DOWN("speed_down", tr("Vitesse −0,25"), "—"),
    OPTIONS("options", "Ouvrir le panneau d'options", "Menu, Info"),
    ASPECT("aspect", tr("Changer le format d'image"), "—"),
    EXIT("exit", "Quitter la lecture", "Retour");

    companion object {
        fun from(id: String): PlayerAction? = entries.firstOrNull { it.id == id }
    }
}

/** Touches qu'on refuse de réaffecter, sous peine de bloquer l'appareil. */
private val LOCKED_KEYS = setOf(
    android.view.KeyEvent.KEYCODE_BACK,
    android.view.KeyEvent.KEYCODE_HOME,
    android.view.KeyEvent.KEYCODE_POWER,
    android.view.KeyEvent.KEYCODE_VOLUME_UP,
    android.view.KeyEvent.KEYCODE_VOLUME_DOWN,
    android.view.KeyEvent.KEYCODE_VOLUME_MUTE
)

fun keyName(code: Int): String =
    android.view.KeyEvent.keyCodeToString(code)
        .removePrefix("KEYCODE_")
        .replace('_', ' ')
        .lowercase()
        .replaceFirstChar { it.uppercase() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KeymapScreen(vm: AppViewModel) {
    val focus = remember { FocusRequester() }
    var capturing by remember { mutableStateOf<PlayerAction?>(null) }
    var rejected by remember { mutableStateOf<String?>(null) }
    var focusedAction by remember { mutableStateOf<PlayerAction?>(null) }

    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("Touches de la télécommande")) },
                navigationIcon = {
                    IconButton(onClick = { vm.back() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
                    }
                },
                actions = {
                    TextButton(onClick = { vm.resetKeymap() }) { Text(tr("Tout effacer")) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface1)
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .focusRequester(focus)
                .focusable()
                .onPreviewKeyEvent { event ->
                    val target = capturing ?: return@onPreviewKeyEvent false
                    if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent true
                    val code = event.nativeKeyEvent.keyCode
                    if (code == android.view.KeyEvent.KEYCODE_BACK) {
                        capturing = null
                        return@onPreviewKeyEvent true
                    }
                    if (code in LOCKED_KEYS) {
                        rejected = keyName(code)
                        return@onPreviewKeyEvent true
                    }
                    vm.bindKey(code, target)
                    capturing = null
                    rejected = null
                    true
                }
        ) {
            Text(
                "Choisis une action, appuie sur « Attribuer », puis presse la touche voulue " +
                    "sur ta télécommande. Les touches non attribuées gardent leur comportement " +
                    "par défaut.",
                color = TextLow,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            )

            capturing?.let { action ->
                Surface(
                    color = Accent,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            tr("Appuie maintenant sur une touche"),
                            color = androidx.compose.ui.graphics.Color.Black,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                        Text(
                            "pour « ${tr(action.label)} » · Retour pour annuler",
                            color = androidx.compose.ui.graphics.Color.Black,
                            fontSize = 12.sp
                        )
                        rejected?.let {
                            Text(
                                "$it est réservée au système, choisis-en une autre",
                                color = androidx.compose.ui.graphics.Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                items(PlayerAction.entries.toList(), key = { it.id }) { action ->
                    val bound = vm.keysFor(action)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(
                                if (focusedAction == action) Accent.copy(alpha = 0.14f)
                                else Color.Transparent
                            )
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(tr(action.label), fontSize = 15.sp)
                            Text(
                                if (bound.isEmpty()) "Par défaut : ${tr(action.defaultKey)}"
                                else bound.joinToString(", ") { keyName(it) },
                                color = if (bound.isEmpty()) TextLow else Accent,
                                fontSize = 12.sp,
                                fontFamily = if (bound.isEmpty()) FontFamily.Default
                                else FontFamily.Monospace
                            )
                            if (action.isHold) {
                                Text(
                                    tr("L'effet dure tant que la touche reste enfoncée"),
                                    color = TextLow, fontSize = 11.sp
                                )
                            }
                        }

                        if (bound.isNotEmpty()) {
                            TextButton(onClick = { vm.unbindAction(action) }) { Text(tr("Effacer")) }
                        }
                        Button(
                            onClick = { rejected = null; capturing = action },
                            modifier = Modifier
                                .onFocusChanged { focusedAction = if (it.isFocused) action else null }
                                .tvFocus(RoundedCornerShape(20.dp), scale = 1.12f)
                        ) { Text(tr("Attribuer")) }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
