package fr.geeko.iptv.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.ui.i18n.tr
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.Surface1
import fr.geeko.iptv.ui.theme.TextLow
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private const val VISIBLE_MS = 9500L

/**
 * Rappel « à regarder plus tard » : un large panneau descend du haut de l'écran,
 * bord inférieur très arrondi, avec deux ou trois jaquettes côte à côte.
 */
@Composable
fun ReminderBanner(
    items: List<StreamItem>,
    onOpen: (StreamItem) -> Unit,
    onRemove: (StreamItem) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isTv = LocalIsTv.current
    val key = items.joinToString { it.key }
    var dragOffset by remember(key) { mutableFloatStateOf(0f) }

    LaunchedEffect(key) {
        if (items.isEmpty()) return@LaunchedEffect
        delay(VISIBLE_MS)
        onDismiss()
    }

    val shape = RoundedCornerShape(
        topStart = 0.dp,
        topEnd = 0.dp,
        bottomStart = 34.dp,
        bottomEnd = 34.dp
    )

    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(
            visible = items.isNotEmpty(),
            enter = slideInVertically(
                initialOffsetY = { -it },
                animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow)
            ) + fadeIn(tween(220)),
            exit = slideOutVertically(
                targetOffsetY = { -it },
                animationSpec = spring(dampingRatio = 1f, stiffness = Spring.StiffnessMedium)
            ) + fadeOut(tween(160))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .widthIn(min = 360.dp, max = 470.dp)
                    .padding(horizontal = 10.dp)
                    .offset { IntOffset(0, dragOffset.roundToInt()) }
                    .pointerInput(key) {
                        detectVerticalDragGestures(
                            onDragEnd = { if (dragOffset < -60f) onDismiss() else dragOffset = 0f },
                            onVerticalDrag = { _, delta ->
                                dragOffset = (dragOffset + delta).coerceIn(-400f, 20f)
                            }
                        )
                    }
                    .shadow(30.dp, shape, clip = false)
                    .clip(shape)
                    .background(Surface1.copy(alpha = 0.96f))
                    // halo coloré, plus dense sur les bords
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Accent.copy(alpha = 0.34f),
                                Color.Transparent,
                                Color(0xFF7C4DFF).copy(alpha = 0.20f),
                                Accent.copy(alpha = 0.30f)
                            )
                        )
                    )
                    .border(
                        width = 1.5.dp,
                        brush = Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = 0.14f), Accent.copy(alpha = 0.75f))
                        ),
                        shape = shape
                    )
                    .statusBarsPadding()
                    .padding(bottom = 18.dp)
            ) {
                Spacer(Modifier.height(8.dp))

                // poignée
                Box(
                    Modifier
                        .width(38.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color.White.copy(alpha = 0.22f))
                )

                Spacer(Modifier.height(14.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        tr("À regarder plus tard"),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.width(12.dp))
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(15.dp)
                    )
                }

                Spacer(Modifier.height(5.dp))
                Text(
                    "${items.size} titre${if (items.size > 1) "s" else ""} vous attend${if (items.size > 1) "ent" else ""}",
                    color = TextLow,
                    fontSize = 10.sp
                )

                Spacer(Modifier.height(13.dp))

                Row(
                    Modifier.padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items.forEach { item ->
                        Box(
                            Modifier
                                .width(82.dp)
                                .tvFocus(RoundedCornerShape(12.dp))
                                .clickable { onOpen(item) }
                        ) {
                            Poster(item.icon, item.name, Modifier.fillMaxWidth(), corner = 12)
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text(
                    if (isTv) "OK sur une jaquette pour ouvrir" else tr("glisse vers le haut pour fermer"),
                    color = TextLow,
                    fontSize = 10.sp
                )
            }
        }
    }
}
