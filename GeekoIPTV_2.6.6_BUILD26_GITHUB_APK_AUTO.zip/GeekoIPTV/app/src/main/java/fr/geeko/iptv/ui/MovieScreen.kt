package fr.geeko.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusProperties
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.ui.theme.*
import fr.geeko.iptv.ui.i18n.tr

@Composable
fun MovieScreen(vm: AppViewModel, movie: StreamItem) {
    val info = vm.movieInfo
    val isTv = LocalIsTv.current
    var actionHint by remember { mutableStateOf<String?>(null) }
    val playFocus = remember { FocusRequester() }
    // Un téléviseur fait environ 540 dp de haut : à 300 dp, le bandeau et
            // les boutons remplissaient tout l'écran et les épisodes tombaient
            // hors champ, sans rien pour indiquer qu'il fallait descendre.
            val heroHeight = if (isTv) 190.dp else 220.dp
    val resume = vm.resumePositionFor(movie.key)

    Box(Modifier.fillMaxSize().appBackground()) {
        LaunchedEffect(isTv, movie.key) {
            if (isTv) {
                kotlinx.coroutines.delay(120)
                runCatching { playFocus.requestFocus() }
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .focusGroup()
                .verticalScroll(rememberScrollState())
        ) {

            Box(Modifier.fillMaxWidth().height(heroHeight)) {
                val hero = info?.backdrop ?: info?.cover ?: movie.icon
                if (!hero.isNullOrBlank()) {
                    AsyncImage(
                        model = hero,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Surface2))
                }
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            0f to Ink.copy(alpha = 0.55f),
                            0.45f to Ink.copy(alpha = 0.25f),
                            1f to Ink
                        )
                    )
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Poster(
                    info?.cover ?: movie.icon,
                    movie.name,
                    Modifier.width(if (isTv) 132.dp else 108.dp)
                )
                Spacer(Modifier.width(16.dp))
                Column(Modifier.padding(top = 64.dp)) {
                    Text(
                        movie.name,
                        fontSize = if (isTv) 24.sp else 20.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 27.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        listOfNotNull(
                            info?.releaseDate?.take(4),
                            info?.genre,
                            info?.durationLabel,
                            info?.rating?.takeIf { it.isNotBlank() && it != "0" }?.let { "★ $it" }
                        ).joinToString(" · ").ifBlank { tr("Film") },
                        color = TextMid,
                        fontSize = 13.sp,
                        maxLines = 2
                    )

                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.height(18.dp), contentAlignment = Alignment.CenterStart) {
                        actionHint?.let {
                            Text(it, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    Spacer(Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { vm.playMovie(movie, info?.containerExt) },
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .focusRequester(playFocus)
                                .onFocusChanged { if (it.isFocused) actionHint = "Lire" }
                                .tvFocus(RoundedCornerShape(24.dp), 1.04f)
                        ) {
                            Icon(
                                if (resume > 0) Icons.Default.PlayArrow else Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(19.dp)
                            )
                            Spacer(Modifier.width(7.dp))
                            Text(
                                if (resume > 0) "Reprendre à ${formatTime(resume)}" else tr("Lire"),
                                fontSize = 14.sp
                            )
                        }

                        if (resume > 0) {
                            Spacer(Modifier.width(10.dp))
                            OutlinedButton(
                                onClick = {
                                    vm.playMovie(movie, info?.containerExt, fromStart = true)
                                },
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier
                                    .onFocusChanged { if (it.isFocused) actionHint = "Lire depuis le début" }
                                    .tvFocus(RoundedCornerShape(24.dp), 1.04f)
                            ) {
                                Icon(
                                    Icons.Default.Replay, contentDescription = tr("Depuis le début"),
                                    tint = TextMid, modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        run {
                            Spacer(Modifier.width(10.dp))
                            DownloadButton(
                                vm,
                                movie.key,
                                size = 44,
                                modifier = Modifier.onFocusChanged { if (it.isFocused) actionHint = "Téléchargement" }
                            ) {
                                vm.downloadMovie(movie, info?.containerExt)
                            }
                        }

                        Spacer(Modifier.width(10.dp))
                        val marked = vm.inWatchlist(movie.key)
                        OutlinedButton(
                            onClick = { vm.toggleWatchlist(movie) },
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .onFocusChanged { if (it.isFocused) actionHint = "À regarder plus tard" }
                                .tvFocus(RoundedCornerShape(24.dp), 1.04f)
                        ) {
                            Icon(
                                if (marked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = tr("À regarder plus tard"),
                                tint = if (marked) Accent else TextMid,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            if (vm.movieLoading) {
                LinearProgressIndicator(
                    color = Accent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }

            info?.plot?.takeIf { it.isNotBlank() }?.let {
                Text(
                    it,
                    color = TextMid,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    maxLines = 5,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
            }

            listOfNotNull(
                info?.cast?.takeIf { it.isNotBlank() }?.let { "Avec $it" },
                info?.director?.takeIf { it.isNotBlank() }?.let { "Réalisé par $it" }
            ).forEach { line ->
                Text(
                    line,
                    color = TextLow,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .padding(horizontal = 20.dp, vertical = 3.dp)
                )
            }

            Spacer(Modifier.height(40.dp))
        }

        Box(
            Modifier
                .statusBarsPadding()
                .padding(10.dp)
                .size(42.dp)
                .clip(RoundedCornerShape(21.dp))
                .background(Color.Black.copy(alpha = 0.45f))
                // Sur téléviseur, le focus montait dessus et ne redescendait
                // plus : on l'écarte du parcours, la touche Retour suffit.
                .then(if (isTv) Modifier.focusProperties { canFocus = false } else Modifier)
                .tvFocus(RoundedCornerShape(21.dp), scale = 1.06f)
                .clickable { vm.back() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"), tint = Color.White)
        }
    }
}
