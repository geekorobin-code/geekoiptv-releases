package fr.geeko.iptv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class Profile(
    val id: String,
    val name: String,
    val colorIndex: Int,
    val pinHash: String? = null,
    val avatarPath: String? = null
) {
    val locked: Boolean get() = pinHash != null
}

data class ProfileSettings(
    val primaryLang: String = "fre",
    val secondaryLang: String = "eng",
    val boostSpeed: Float = 2f,
    val subtitlesOn: Boolean = false,
    val subtitleLang: String = "fre",
    /** Action déclenchée par le bouton dédié de la télécommande. */
    val shortcutAction: String = "audio"
)

/** Stockage local : serveur, profils, historique, groupes masqués, réglages. */
class Store(context: Context) {

    private val sp = context.getSharedPreferences("geekoiptv", Context.MODE_PRIVATE)

    // ------------------------------------------------------------- serveur

    var host: String
        get() = sp.getString("host", "") ?: ""
        set(v) = sp.edit().putString("host", v).apply()

    var username: String
        get() = sp.getString("user", "") ?: ""
        set(v) = sp.edit().putString("user", v).apply()

    var password: String
        get() = sp.getString("pass", "") ?: ""
        set(v) = sp.edit().putString("pass", v).apply()

    val hasServer: Boolean get() = host.isNotBlank() && username.isNotBlank()

    /** Apparence (couleurs par module + disposition), au format JSON. */
    var appearanceJson: String
        get() = sp.getString("appearance", "") ?: ""
        set(v) = sp.edit().putString("appearance", v).apply()

    fun appearanceJsonForProfile(pid: String): String =
        sp.getString("p_${pid}_appearance", appearanceJson) ?: appearanceJson

    fun saveAppearanceForProfile(pid: String, json: String) {
        sp.edit().putString("p_${pid}_appearance", json).apply()
    }

    /**
     * Espacement des rappels « à regarder plus tard », en heures.
     * 0 désactive complètement.
     */
    var reminderIntervalHours: Int
        get() = sp.getInt("reminder_hours", 60)
        set(v) = sp.edit().putInt("reminder_hours", v).apply()

    fun lastReminderAt(pid: String): Long = sp.getLong("p_${pid}_last_reminder", 0L)

    fun setLastReminderAt(pid: String, at: Long) {
        sp.edit().putLong("p_${pid}_last_reminder", at).apply()
    }

    /** Dernière version pour laquelle une notification a été envoyée. */
    var notifiedUpdateVersion: Int
        get() = sp.getInt("notified_update", 0)
        set(v) = sp.edit().putInt("notified_update", v).apply()

    /** Langue de l'interface (code ISO : fr, en, es…). */
    var uiLanguage: String
        get() = sp.getString("ui_lang", "fr") ?: "fr"
        set(v) = sp.edit().putString("ui_lang", v).apply()

    /** Petit son au démarrage, sur l'écran des profils. */
    var soundEnabled: Boolean
        get() = sp.getBoolean("sound_enabled", true)
        set(v) = sp.edit().putBoolean("sound_enabled", v).apply()

    /** 0 = à chaque ouverture, 1 = toutes les 2 h, 2 = manuel uniquement. */
    var playlistRefreshMode: Int
        get() = sp.getInt("playlist_refresh_mode", 0)
        set(v) = sp.edit().putInt("playlist_refresh_mode", v.coerceIn(0, 2)).apply()

    var lastPlaylistRefresh: Long
        get() = sp.getLong("last_playlist_refresh", 0L)
        set(v) = sp.edit().putLong("last_playlist_refresh", v).apply()

    var donationUrl: String
        get() = sp.getString("donation_url", "") ?: ""
        set(v) = sp.edit().putString("donation_url", v.trim()).apply()

    // ------------------------------------------------------ mises à jour

    var lastUpdateCheck: Long
        get() = sp.getLong("last_update_check", 0L)
        set(v) = sp.edit().putLong("last_update_check", v).apply()

    /** Version que l'utilisateur a choisi d'ignorer. */
    var skippedVersion: Int
        get() = sp.getInt("skipped_version", 0)
        set(v) = sp.edit().putInt("skipped_version", v).apply()

    fun clearServer() {
        sp.edit().remove("host").remove("user").remove("pass").apply()
    }

    // ------------------------------------------------------------- profils

    fun profiles(): List<Profile> {
        val raw = sp.getString("profiles", null) ?: return emptyList()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Profile(
                id = o.optString("id"),
                name = o.optString("name"),
                colorIndex = o.optInt("color", 0),
                pinHash = o.optString("pin").takeIf { it.isNotBlank() },
                avatarPath = o.optString("avatar").takeIf { it.isNotBlank() }
            )
        }
    }

    fun saveProfiles(list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("color", p.colorIndex)
                put("pin", p.pinHash ?: "")
                put("avatar", p.avatarPath ?: "")
            })
        }
        sp.edit().putString("profiles", arr.toString()).apply()
    }

    fun addProfile(name: String, colorIndex: Int, pin: String?, avatarPath: String? = null): Profile {
        val p = Profile(
            id = System.currentTimeMillis().toString(36),
            name = name.trim().ifBlank { "Membre" },
            colorIndex = colorIndex,
            pinHash = pin?.takeIf { it.isNotBlank() }?.let { hash(it) },
            avatarPath = avatarPath
        )
        saveProfiles(profiles() + p)
        return p
    }

    fun updateProfile(updated: Profile) {
        saveProfiles(profiles().map { if (it.id == updated.id) updated else it })
    }

    fun deleteProfile(id: String) {
        saveProfiles(profiles().filterNot { it.id == id })
        sp.all.keys.filter { it.startsWith("p_${id}_") }
            .forEach { sp.edit().remove(it).apply() }
    }

    fun checkPin(profile: Profile, pin: String): Boolean =
        profile.pinHash == null || profile.pinHash == hash(pin)

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(("geeko:$pin").toByteArray())
            .joinToString("") { "%02x".format(it) }

    // ------------------------------------------------------------ réglages

    fun settings(pid: String): ProfileSettings {
        val raw = sp.getString("p_${pid}_settings", null) ?: return ProfileSettings()
        val o = runCatching { JSONObject(raw) }.getOrNull() ?: return ProfileSettings()
        return ProfileSettings(
            primaryLang = o.optString("primary", "fre"),
            secondaryLang = o.optString("secondary", "eng"),
            boostSpeed = o.optDouble("boost", 2.0).toFloat(),
            subtitlesOn = o.optBoolean("subs", false),
            subtitleLang = o.optString("subLang", "fre"),
            shortcutAction = o.optString("shortcut", "audio")
        )
    }

    fun saveSettings(pid: String, s: ProfileSettings) {
        val o = JSONObject().apply {
            put("primary", s.primaryLang)
            put("secondary", s.secondaryLang)
            put("boost", s.boostSpeed.toDouble())
            put("subs", s.subtitlesOn)
            put("subLang", s.subtitleLang)
            put("shortcut", s.shortcutAction)
        }
        sp.edit().putString("p_${pid}_settings", o.toString()).apply()
    }

    // ------------------------------------------------------ groupes masqués

    fun hidden(pid: String, type: ContentType): Set<String> =
        sp.getStringSet("p_${pid}_hidden_${type.name}", emptySet()) ?: emptySet()

    fun setHidden(pid: String, type: ContentType, ids: Set<String>) {
        sp.edit().putStringSet("p_${pid}_hidden_${type.name}", ids).apply()
    }

    fun toggleHidden(pid: String, type: ContentType, categoryId: String) {
        val cur = hidden(pid, type).toMutableSet()
        if (!cur.add(categoryId)) cur.remove(categoryId)
        setHidden(pid, type, cur)
    }

    fun categoryOrder(pid: String, type: ContentType): List<String> =
        (sp.getString("p_${pid}_order_${type.name}", "") ?: "")
            .split("|").filter { it.isNotBlank() }

    fun saveCategoryOrder(pid: String, type: ContentType, ids: List<String>) {
        sp.edit().putString("p_${pid}_order_${type.name}", ids.joinToString("|")).apply()
    }

    // ---------------------------------------------------------- historique

    fun history(pid: String): List<HistoryEntry> {
        val raw = sp.getString("p_${pid}_history", null) ?: return emptyList()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val type = runCatching { ContentType.valueOf(o.optString("type")) }.getOrNull()
                ?: return@mapNotNull null
            HistoryEntry(
                key = o.optString("key"),
                type = type,
                streamId = o.optString("sid"),
                title = o.optString("title"),
                subtitle = o.optString("sub").takeIf { it.isNotBlank() },
                icon = o.optString("icon").takeIf { it.isNotBlank() },
                containerExt = o.optString("ext").takeIf { it.isNotBlank() },
                positionMs = o.optLong("pos"),
                durationMs = o.optLong("dur"),
                updatedAt = o.optLong("at"),
                seriesId = o.optString("series").takeIf { it.isNotBlank() },
                season = o.optInt("s"),
                episode = o.optInt("e"),
                thumb = o.optString("thumb").takeIf { it.isNotBlank() }
            )
        }.sortedByDescending { it.updatedAt }
    }

    fun saveHistory(pid: String, list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.sortedByDescending { it.updatedAt }.take(40).forEach { h ->
            arr.put(JSONObject().apply {
                put("key", h.key)
                put("type", h.type.name)
                put("sid", h.streamId)
                put("title", h.title)
                put("sub", h.subtitle ?: "")
                put("icon", h.icon ?: "")
                put("ext", h.containerExt ?: "")
                put("pos", h.positionMs)
                put("dur", h.durationMs)
                put("at", h.updatedAt)
                put("series", h.seriesId ?: "")
                put("s", h.season)
                put("e", h.episode)
                put("thumb", h.thumb ?: "")
            })
        }
        sp.edit().putString("p_${pid}_history", arr.toString()).apply()
    }

    /** Une seule entrée "en cours" par série : on remplace l'épisode précédent. */
    fun recordProgress(pid: String, entry: HistoryEntry) {
        if (entry.type == ContentType.LIVE) return
        val current = history(pid).toMutableList()
        val keptThumb = entry.thumb ?: current.firstOrNull { it.key == entry.key }?.thumb
        current.removeAll {
            it.key == entry.key || (entry.seriesId != null && it.seriesId == entry.seriesId)
        }
        current.add(0, entry.copy(thumb = keptThumb))
        saveHistory(pid, current)
    }

    fun removeFromHistory(pid: String, key: String) {
        saveHistory(pid, history(pid).filterNot { it.key == key })
    }

    fun resumePosition(pid: String, key: String): Long =
        history(pid).firstOrNull { it.key == key }?.takeIf { !it.finished }?.positionMs ?: 0L

    // ------------------------------------------------- à regarder plus tard

    fun watchlist(pid: String): List<StreamItem> {
        val raw = sp.getString("p_${pid}_watchlist", null) ?: return emptyList()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val type = runCatching { ContentType.valueOf(o.optString("type")) }.getOrNull()
                ?: return@mapNotNull null
            StreamItem(
                id = o.optString("id"),
                name = o.optString("name"),
                icon = o.optString("icon").takeIf { it.isNotBlank() },
                type = type,
                containerExt = o.optString("ext").takeIf { it.isNotBlank() },
                added = o.optLong("at")
            )
        }
    }

    fun saveWatchlist(pid: String, list: List<StreamItem>) {
        val arr = JSONArray()
        list.take(100).forEach { it ->
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("name", it.name)
                put("icon", it.icon ?: "")
                put("type", it.type.name)
                put("ext", it.containerExt ?: "")
                put("at", it.added)
            })
        }
        sp.edit().putString("p_${pid}_watchlist", arr.toString()).apply()
    }

    /** @return true si l'élément vient d'être ajouté, false s'il a été retiré. */
    fun toggleWatchlist(pid: String, item: StreamItem): Boolean {
        val current = watchlist(pid).toMutableList()
        val existing = current.firstOrNull { it.key == item.key }
        return if (existing != null) {
            current.remove(existing)
            saveWatchlist(pid, current)
            false
        } else {
            current.add(0, item.copy(added = System.currentTimeMillis()))
            saveWatchlist(pid, current)
            true
        }
    }

    // -------------------------------------------- touches de la télécommande

    /** keycode -> identifiant d'action */
    fun keymap(pid: String): Map<Int, String> {
        val raw = sp.getString("p_${pid}_keymap", null) ?: return emptyMap()
        val o = runCatching { JSONObject(raw) }.getOrNull() ?: return emptyMap()
        val out = HashMap<Int, String>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val code = k.toIntOrNull() ?: continue
            val action = o.optString(k).takeIf { it.isNotBlank() } ?: continue
            out[code] = action
        }
        return out
    }

    fun saveKeymap(pid: String, map: Map<Int, String>) {
        val o = JSONObject()
        map.forEach { (code, action) -> o.put(code.toString(), action) }
        sp.edit().putString("p_${pid}_keymap", o.toString()).apply()
    }

    // ------------------------------------------- titres terminés & trophées

    fun completions(pid: String): List<Completion> {
        val raw = sp.getString("p_${pid}_done", null) ?: return emptyList()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val type = runCatching { ContentType.valueOf(o.optString("type")) }.getOrNull()
                ?: return@mapNotNull null
            Completion(
                key = o.optString("key"),
                type = type,
                title = o.optString("title"),
                subtitle = o.optString("sub").takeIf { it.isNotBlank() },
                icon = o.optString("icon").takeIf { it.isNotBlank() },
                seriesId = o.optString("series").takeIf { it.isNotBlank() },
                at = o.optLong("at"),
                fullSeries = o.optBoolean("full", false)
            )
        }.sortedByDescending { it.at }
    }

    private fun saveCompletions(pid: String, list: List<Completion>) {
        val arr = JSONArray()
        list.sortedByDescending { it.at }.take(500).forEach { c ->
            arr.put(JSONObject().apply {
                put("key", c.key)
                put("type", c.type.name)
                put("title", c.title)
                put("sub", c.subtitle ?: "")
                put("icon", c.icon ?: "")
                put("series", c.seriesId ?: "")
                put("at", c.at)
                put("full", c.fullSeries)
            })
        }
        sp.edit().putString("p_${pid}_done", arr.toString()).apply()
    }

    /** @return true si l'entrée vient d'être ajoutée. */
    fun addCompletion(pid: String, c: Completion): Boolean {
        val list = completions(pid)
        if (list.any { it.key == c.key }) return false
        saveCompletions(pid, list + c)
        return true
    }

    fun removeCompletion(pid: String, key: String) {
        saveCompletions(pid, completions(pid).filterNot { it.key == key })
    }

    fun clearCompletions(pid: String) {
        sp.edit().remove("p_${pid}_done").apply()
        sp.all.keys.filter { it.startsWith("p_${pid}_ep_") || it.startsWith("p_${pid}_eptotal_") }
            .forEach { sp.edit().remove(it).apply() }
    }

    // --- suivi épisode par épisode

    fun episodesDone(pid: String, seriesId: String): Set<String> =
        sp.getStringSet("p_${pid}_ep_$seriesId", emptySet()) ?: emptySet()

    fun markEpisodeDone(pid: String, seriesId: String, episodeId: String) {
        val next = episodesDone(pid, seriesId) + episodeId
        sp.edit().putStringSet("p_${pid}_ep_$seriesId", next).apply()
    }

    fun seriesTotal(pid: String, seriesId: String): Int =
        sp.getInt("p_${pid}_eptotal_$seriesId", 0)

    fun setSeriesTotal(pid: String, seriesId: String, total: Int) {
        if (total > 0) sp.edit().putInt("p_${pid}_eptotal_$seriesId", total).apply()
    }

    // ------------------------------------------------------ mosaïque

    /** Identifiants des chaînes placées dans la mosaïque, "" pour un emplacement vide. */
    fun mosaic(pid: String): List<String> =
        (sp.getString("p_${pid}_mosaic", "") ?: "").split("|")

    fun saveMosaic(pid: String, ids: List<String>) {
        sp.edit().putString("p_${pid}_mosaic", ids.joinToString("|")).apply()
    }

    fun mosaicLayout(pid: String): Int = sp.getInt("p_${pid}_mosaic_layout", 1)

    fun saveMosaicLayout(pid: String, layout: Int) {
        sp.edit().putInt("p_${pid}_mosaic_layout", layout).apply()
    }
}
