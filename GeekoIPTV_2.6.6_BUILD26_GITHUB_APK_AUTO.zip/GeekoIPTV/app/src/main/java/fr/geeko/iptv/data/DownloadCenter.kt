package fr.geeko.iptv.data

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import fr.geeko.iptv.DownloadService
import fr.geeko.iptv.RecordingWorker
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class DownloadState { SCHEDULED, QUEUED, RUNNING, DONE, FAILED }

data class DownloadItem(
    val key: String,
    val title: String,
    val subtitle: String? = null,
    val icon: String? = null,
    val url: String,
    val ext: String,
    val type: ContentType,
    val seriesId: String? = null,
    val downloaded: Long = 0L,
    val total: Long = 0L,
    val state: DownloadState = DownloadState.QUEUED,
    val at: Long = System.currentTimeMillis(),
    val scheduledStart: Long = 0L,
    val scheduledEnd: Long = 0L
) {
    val fileName: String get() = key.replace(":", "_") + "." + ext
    val progress: Float
        get() = if (total > 0) (downloaded.toFloat() / total).coerceIn(0f, 1f) else 0f
}

/**
 * Point unique pour les téléchargements : l'état est observable par l'interface,
 * la liste est persistée, et le transfert lui-même est confié au service.
 */
object DownloadCenter {

    var items by mutableStateOf<List<DownloadItem>>(emptyList())
        private set

    private const val PREFS = "geeko_downloads"
    private const val KEY = "items"

    /**
     * getExternalFilesDir peut renvoyer null si le stockage externe n'est pas monté :
     * dans ce cas on retombe sur le stockage interne plutôt que d'échouer.
     */
    fun folder(context: Context): File {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        return File(base, "downloads").apply { mkdirs() }
    }

    fun fileFor(context: Context, item: DownloadItem): File =
        File(folder(context), item.fileName)

    fun load(context: Context) {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return
        items = (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val type = runCatching { ContentType.valueOf(o.optString("type")) }.getOrNull()
                ?: return@mapNotNull null
            val state = runCatching { DownloadState.valueOf(o.optString("state")) }.getOrNull()
                ?: DownloadState.QUEUED
            DownloadItem(
                key = o.optString("key"),
                title = o.optString("title"),
                subtitle = o.optString("sub").takeIf { it.isNotBlank() },
                icon = o.optString("icon").takeIf { it.isNotBlank() },
                url = o.optString("url"),
                ext = o.optString("ext", "mp4"),
                type = type,
                seriesId = o.optString("series").takeIf { it.isNotBlank() },
                downloaded = o.optLong("done"),
                total = o.optLong("total"),
                // un téléchargement classique interrompu repart en file ; un
                // enregistrement programmé reste géré par WorkManager.
                state = if (state == DownloadState.RUNNING && o.optLong("scheduledEnd") <= 0L)
                    DownloadState.QUEUED else state,
                at = o.optLong("at"),
                scheduledStart = o.optLong("scheduledStart"),
                scheduledEnd = o.optLong("scheduledEnd")
            )
        }
    }

    private fun persist(context: Context) {
        val arr = JSONArray()
        items.forEach { d ->
            arr.put(JSONObject().apply {
                put("key", d.key)
                put("title", d.title)
                put("sub", d.subtitle ?: "")
                put("icon", d.icon ?: "")
                put("url", d.url)
                put("ext", d.ext)
                put("type", d.type.name)
                put("series", d.seriesId ?: "")
                put("done", d.downloaded)
                put("total", d.total)
                put("state", d.state.name)
                put("at", d.at)
                put("scheduledStart", d.scheduledStart)
                put("scheduledEnd", d.scheduledEnd)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun find(key: String): DownloadItem? = items.firstOrNull { it.key == key }

    fun isDownloaded(key: String): Boolean = find(key)?.state == DownloadState.DONE

    /** Chemin local d'un titre déjà téléchargé, sinon null. */
    fun localUri(context: Context, key: String): String? {
        val item = find(key) ?: return null
        if (item.state != DownloadState.DONE) return null
        val file = fileFor(context, item)
        return if (file.exists() && file.length() > 0) file.toURI().toString() else null
    }

    fun enqueue(context: Context, item: DownloadItem) {
        if (find(item.key) != null) return
        items = items + item
        persist(context)
        DownloadService.start(context)
    }

    private fun recordingWorkName(key: String) = "geeko_record_" + key.hashCode()

    /** Programme l'enregistrement d'un programme TV issu de l'EPG. */
    fun scheduleRecording(context: Context, item: DownloadItem) {
        if (find(item.key) != null) return

        val scheduled = item.copy(state = DownloadState.SCHEDULED)
        items = items + scheduled
        persist(context)

        val delayMs = (scheduled.scheduledStart - System.currentTimeMillis()).coerceAtLeast(0L)
        val data = Data.Builder().putString(RecordingWorker.KEY_DOWNLOAD, scheduled.key).build()
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = OneTimeWorkRequestBuilder<RecordingWorker>()
            .setInputData(data)
            .setConstraints(constraints)
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .addTag(recordingWorkName(scheduled.key))
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            recordingWorkName(scheduled.key),
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    private val main = Handler(Looper.getMainLooper())

    /** Appelé depuis le service, sur un fil de fond : on publie côté interface. */
    fun update(context: Context, key: String, transform: (DownloadItem) -> DownloadItem) {
        val next = items.map { if (it.key == key) transform(it) else it }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            items = next
        } else {
            main.post { items = next }
        }
        persist(context)
    }

    fun remove(context: Context, key: String) {
        WorkManager.getInstance(context).cancelUniqueWork(recordingWorkName(key))
        find(key)?.let { runCatching { fileFor(context, it).delete() } }
        items = items.filterNot { it.key == key }
        persist(context)
    }

    fun clearAll(context: Context) {
        items.forEach {
            WorkManager.getInstance(context).cancelUniqueWork(recordingWorkName(it.key))
            runCatching { fileFor(context, it).delete() }
        }
        items = emptyList()
        persist(context)
    }

    /** Relance un téléchargement en échec. */
    fun retry(context: Context, key: String) {
        update(context, key) { it.copy(state = DownloadState.QUEUED, downloaded = 0L) }
        find(key)?.let { runCatching { fileFor(context, it).delete() } }
        DownloadService.start(context)
    }

    fun nextPending(): DownloadItem? =
        items.firstOrNull { it.state == DownloadState.QUEUED }

    fun totalBytes(): Long = items.filter { it.state == DownloadState.DONE }.sumOf { it.total }

    fun stopService(context: Context) {
        context.stopService(Intent(context, DownloadService::class.java))
    }
}
