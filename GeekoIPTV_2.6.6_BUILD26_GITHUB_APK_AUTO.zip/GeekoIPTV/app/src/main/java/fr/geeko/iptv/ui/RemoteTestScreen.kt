package fr.geeko.iptv.ui

import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.Surface1
import fr.geeko.iptv.ui.theme.TextLow
import fr.geeko.iptv.ui.i18n.tr

private data class KeyLog(val code: Int, val name: String, val at: Long)

/** Affiche le keycode de chaque touche pressée, pour identifier les boutons exotiques. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemoteTestScreen(vm: AppViewModel) {
    val focus = remember { FocusRequester() }
    var log by remember { mutableStateOf(listOf<KeyLog>()) }
    var pulses by remember { mutableIntStateOf(0) }
    val startPulse = remember { ShortcutBus.pulse }

    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    LaunchedEffect(ShortcutBus.pulse) {
        if (ShortcutBus.pulse != startPulse) pulses = ShortcutBus.pulse - startPulse
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tr("Test de la télécommande")) },
                navigationIcon = {
                    IconButton(onClick = { vm.back() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface1)
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(24.dp)
                .focusRequester(focus)
                .focusable()
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown) {
                        val code = event.nativeKeyEvent.keyCode
                        val name = android.view.KeyEvent.keyCodeToString(code)
                        log = (listOf(KeyLog(code, name, System.currentTimeMillis())) + log).take(20)
                    }
                    // On laisse passer le retour pour pouvoir sortir de l'écran.
                    event.nativeKeyEvent.keyCode != android.view.KeyEvent.KEYCODE_BACK
                }
        ) {
            Text(
                "Appuie sur n'importe quelle touche : son code s'affiche ci-dessous. " +
                    "Si rien ne s'affiche, c'est que le système intercepte la touche avant l'app.",
                color = TextLow, fontSize = 14.sp
            )

            Spacer(Modifier.height(20.dp))

            Surface(color = Surface1, shape = MaterialTheme.shapes.medium) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Raccourci « relance de l'app »", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (pulses == 0)
                            "Aucune détection. Règle Button Mapper sur « lancer GeekoIPTV » " +
                                "puis appuie sur ton bouton Netflix."
                        else "Détecté $pulses fois — ton bouton fonctionne comme touche d'action.",
                        color = if (pulses == 0) TextLow else Accent,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            if (log.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(top = 40.dp), Alignment.Center) {
                    Text(tr("En attente d'un appui…"), color = TextLow)
                }
            } else {
                LazyColumn {
                    items(log) { entry ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                entry.code.toString(),
                                color = Accent,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.width(64.dp)
                            )
                            Text(entry.name, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
