package fr.geeko.iptv

import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import fr.geeko.iptv.ui.i18n.I18n
import androidx.lifecycle.viewmodel.compose.viewModel
import fr.geeko.iptv.ui.*
import fr.geeko.iptv.ui.theme.GeekoTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val pipReceiver = PipReceiver()

    /**
     * Déclenché quand l'app est relancée alors qu'elle est déjà au premier plan
     * (bouton de télécommande remappé sur « lancer GeekoIPTV » via Button Mapper).
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        ShortcutBus.fire()
    }

    /** L'utilisateur quitte l'app alors qu'un film joue : on bascule en fenêtre flottante. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S &&
            PipState.playerOpen && PipState.playing && supportsPip(this)
        ) {
            enterPip(this)
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        PipState.inPip = isInPictureInPictureMode
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(pipReceiver) }
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val fromNotification =
            intent?.getBooleanExtra(UpdateWorker.EXTRA_FROM_NOTIFICATION, false) == true

        // vérification des mises à jour en arrière-plan, toutes les 12 h
        UpdateWorker.schedule(this)

        // boutons lecture / recul / avance de la fenêtre flottante
        val filter = IntentFilter(PIP_ACTION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(pipReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(pipReceiver, filter)
        }

        setContent {
            val context = LocalContext.current
            val isTv = remember { detectTv(context) }
            val direction =
                if (I18n.lang.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
            CompositionLocalProvider(
                LocalIsTv provides isTv,
                LocalLayoutDirection provides direction
            ) {
                GeekoTheme {
                    Surface(Modifier.fillMaxSize()) {
                        App(onExit = { finish() })
                    }
                }
            }
        }
    }
}

@Composable
private fun App(onExit: () -> Unit) {
    val vm: AppViewModel = viewModel()
    var confirmExit by remember { mutableStateOf(false) }

    BackHandler(enabled = true) {
        if (vm.trophy != null) vm.dismissTrophy()
        else if (vm.updateBannerVisible) vm.dismissUpdateBanner()
        else if (vm.reminder.isNotEmpty()) vm.dismissReminder()
        else if (!vm.back()) confirmExit = true
    }

    // Vérification silencieuse d'une nouvelle version au lancement
    LaunchedEffect(Unit) {
        delay(3_000)
        vm.checkForUpdate(silent = true)
    }

    // Rappels « à regarder plus tard ». C'est le ViewModel qui décide s'il est
    // temps d'en afficher un : ici on se contente de lui demander de loin en loin.
    LaunchedEffect(vm.profile?.id) {
        if (vm.profile == null) return@LaunchedEffect
        delay(90_000)
        while (true) {
            vm.triggerReminder()
            delay(20 * 60_000L)
        }
    }

    // Sur TV le bandeau n'est pas cliquable : on ouvre directement le dialogue,
    // navigable à la télécommande.
    val isTv = LocalIsTv.current
    LaunchedEffect(vm.updateBannerVisible) {
        if (isTv && vm.updateBannerVisible) vm.openUpdateDialog()
    }

    Box(Modifier.fillMaxSize()) {
        when (val s = vm.screen) {
            is Screen.Login -> LoginScreen(vm)
            is Screen.Profiles -> ProfilesScreen(vm)
            is Screen.Home -> HomeScreen(vm)
            is Screen.SeriesDetail -> SeriesScreen(vm, s.item)
            is Screen.MovieDetail -> MovieScreen(vm, s.item)
            is Screen.Player -> PlayerScreen(vm, s.request)
            is Screen.Settings -> SettingsScreen(vm)
            is Screen.RemoteTest -> RemoteTestScreen(vm)
            is Screen.Keymap -> KeymapScreen(vm)
            is Screen.Search -> SearchScreen(vm)
            is Screen.Completed -> CompletedScreen(vm)
            is Screen.Downloads -> DownloadsScreen(vm)
            is Screen.Mosaic -> MosaicScreen(vm)
            is Screen.PairReceive -> PairReceiveScreen(vm)
            is Screen.PairSend -> PairSendScreen(vm)
            is Screen.Collection -> CollectionScreen(vm, s.title, s.items)
        }

        if (!PipState.inPip) UpdateDialog(vm)

        if (vm.screen !is Screen.Player && !PipState.inPip) {
            TrophyOverlay(
                completion = vm.trophy,
                soundEnabled = vm.soundEnabled,
                onDismiss = { vm.dismissTrophy() }
            )
        }

        if (vm.screen !is Screen.Player && !PipState.inPip) {
            UpdateBanner(
                visible = vm.updateBannerVisible,
                versionName = (vm.updateState as? UpdateState.Available)?.info?.versionName ?: "",
                mandatory = (vm.updateState as? UpdateState.Available)?.info?.mandatory ?: false,
                onOpen = { vm.openUpdateDialog() },
                onDismiss = { vm.dismissUpdateBanner() },
                modifier = Modifier.align(Alignment.TopCenter)
            )
        }

        val onWatchlistTab = vm.screen is Screen.Home && vm.tab == HomeTab.WATCHLIST
        if (vm.screen !is Screen.Player && vm.screen !is Screen.Mosaic &&
            !vm.updateBannerVisible && !PipState.inPip && !onWatchlistTab
        ) {
            ReminderBanner(
                items = vm.reminder,
                onOpen = { vm.openReminder(it) },
                onRemove = { vm.removeFromWatchlist(it) },
                onDismiss = { vm.dismissReminder() },
                modifier = Modifier.align(Alignment.TopCenter)
            )
        }

        if (confirmExit) {
            AlertDialog(
                onDismissRequest = { confirmExit = false },
                title = { Text("Quitter GeekoIPTV ?") },
                text = { Text("Voulez-vous quitter l'application ?") },
                confirmButton = {
                    TextButton(onClick = { confirmExit = false; onExit() }) { Text("Oui") }
                },
                dismissButton = {
                    TextButton(onClick = { confirmExit = false }) { Text("Non") }
                }
            )
        }

    }
}
