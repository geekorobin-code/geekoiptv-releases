package fr.geeko.iptv.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.data.ContentType
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.Surface2
import fr.geeko.iptv.ui.theme.TextLow
import fr.geeko.iptv.ui.i18n.tr

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(vm: AppViewModel) {
    val focus = remember { FocusRequester() }
    val isTv = LocalIsTv.current
    val context = LocalContext.current
    // sur téléviseur la dictée est intégrée : elle est toujours disponible
    val voiceReady = remember { isTv || voiceSearchAvailable(context) }
    val startSystemVoice = rememberVoiceSearch { vm.globalQuery = it }
    var voiceOpen by remember { mutableStateOf(false) }
    val startVoice = { if (isTv) voiceOpen = true else startSystemVoice() }

    // Sur téléviseur, la dictée démarre d'elle-même à l'ouverture de la
    // recherche : taper au pavé directionnel est bien trop pénible.
    LaunchedEffect(Unit) {
        val fromMic = vm.voiceRequested
        vm.voiceRequested = false
        if (fromMic || (isTv && vm.globalQuery.isBlank())) startVoice()
    }
    LaunchedEffect(Unit) { if (!isTv) runCatching { focus.requestFocus() } }

    if (voiceOpen) {
        VoiceDialog(
            onDismiss = { voiceOpen = false },
            onResult = { vm.globalQuery = it }
        )
    }

    Column(Modifier.fillMaxSize().appBackground().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 6.dp, end = 16.dp, top = 10.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.back() }, modifier = Modifier.tvFocus(scale = 1.05f)) {
                Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
            }
            OutlinedTextField(
                value = vm.globalQuery,
                onValueChange = { vm.globalQuery = it },
                placeholder = { Text(tr("Chercher un film, une série, une chaîne")) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    Row {
                        if (vm.globalQuery.isNotEmpty()) {
                            IconButton(onClick = { vm.globalQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = tr("Effacer"))
                            }
                        }
                        // sur téléviseur le micro est placé hors du champ, plus bas
                        if (voiceReady && !isTv) {
                            IconButton(onClick = { startVoice() }) {
                                Icon(
                                    Icons.Default.Mic,
                                    contentDescription = tr("Recherche vocale"),
                                    tint = Accent
                                )
                            }
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(26.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = Surface2,
                    focusedContainerColor = Surface2,
                    unfocusedBorderColor = androidx.compose.ui.graphics.Color.Transparent
                ),
                modifier = Modifier.weight(1f).focusRequester(focus)
            )
        }

        if (voiceReady && isTv) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .tvFocus(RoundedCornerShape(24.dp), 1.05f)
                    .clickable { startVoice() }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Mic,
                    contentDescription = null,
                    tint = Accent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(tr("Recherche vocale"), fontSize = 14.sp)
            }
        }

        if (vm.globalQuery.trim().length < 2) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text(tr("Tape au moins deux lettres"), color = TextLow, fontSize = 14.sp)
            }
            return@Column
        }

        if (vm.searchTotal == 0) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text(tr("Aucun résultat"), color = TextLow, fontSize = 14.sp)
            }
            return@Column
        }

        if (isTv) {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf(ContentType.VOD, ContentType.SERIES, ContentType.LIVE).forEach { type ->
                    val results = vm.searchResults(type)
                    if (results.isEmpty()) return@forEach
                    item {
                        SectionHeader(
                            when (type) {
                                ContentType.VOD -> tr("Films")
                                ContentType.SERIES -> tr("Séries")
                                ContentType.LIVE -> tr("Chaînes")
                            },
                            modifier = Modifier.padding(start = 0.dp),
                            count = results.size
                        )
                    }
                    item {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 4.dp)
                        ) {
                            lazyItems(results, key = { it.key }) { item ->
                                MediaCard(
                                    item = item,
                                    subtitle = vm.categoryName(item),
                                    marked = vm.inWatchlist(item.key),
                                    blurb = null,
                                    onRequestBlurb = {},
                                    completed = vm.isDone(item),
                                    fullSeries = item.type == ContentType.SERIES && vm.isSeriesComplete(item.id),
                                    onClick = { vm.openItem(item) },
                                    onLongClick = { vm.toggleWatchlist(item) },
                                    modifier = Modifier.width(if (type == ContentType.LIVE) 110.dp else 96.dp)
                                )
                            }
                        }
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(108.dp),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                listOf(ContentType.VOD, ContentType.SERIES, ContentType.LIVE).forEach { type ->
                    val results = vm.searchResults(type)
                    if (results.isEmpty()) return@forEach
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        SectionHeader(
                            when (type) {
                                ContentType.VOD -> tr("Films")
                                ContentType.SERIES -> tr("Séries")
                                ContentType.LIVE -> tr("Chaînes")
                            },
                            modifier = Modifier.padding(start = 0.dp),
                            count = results.size
                        )
                    }
                    items(results, key = { it.key }) { item ->
                        MediaCard(
                            item = item,
                            subtitle = vm.categoryName(item),
                            marked = vm.inWatchlist(item.key),
                            blurb = vm.blurbOf(item),
                            onRequestBlurb = { vm.ensureBlurb(item) },
                            completed = vm.isDone(item),
                            fullSeries = item.type == ContentType.SERIES && vm.isSeriesComplete(item.id),
                            onClick = { vm.openItem(item) },
                            onLongClick = { vm.toggleWatchlist(item) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
