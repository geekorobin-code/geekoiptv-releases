package fr.geeko.iptv.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.data.Completion
import fr.geeko.iptv.data.ContentType
import fr.geeko.iptv.ui.theme.Gold
import fr.geeko.iptv.ui.theme.Surface1
import fr.geeko.iptv.ui.theme.TextMid
import kotlinx.coroutines.delay
import fr.geeko.iptv.ui.i18n.tr

/** Petite récompense affichée quand un film ou une série est bouclé. */
@Composable
fun TrophyOverlay(
    completion: Completion?,
    soundEnabled: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(completion) {
        if (completion == null) return@LaunchedEffect
        if (soundEnabled) Chime.play(0.55f)
        delay(4200)
        onDismiss()
    }

    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AnimatedVisibility(
            visible = completion != null,
            enter = scaleIn(
                initialScale = 0.5f,
                animationSpec = spring(dampingRatio = 0.42f, stiffness = Spring.StiffnessLow)
            ) + fadeIn(),
            exit = scaleOut(targetScale = 0.85f) + fadeOut()
        ) {
            val c = completion ?: return@AnimatedVisibility

            Box(contentAlignment = Alignment.Center) {
                SparkleBurst(
                    visible = true,
                    modifier = Modifier.size(300.dp),
                    color = Gold,
                    branches = 10
                )

                Column(
                    Modifier
                        .widthIn(max = 260.dp)
                        .shadow(20.dp, RoundedCornerShape(28.dp), clip = false)
                        .clip(RoundedCornerShape(28.dp))
                        .background(Surface1)
                        .border(1.dp, Gold.copy(alpha = 0.5f), RoundedCornerShape(28.dp))
                        .clickable(onClick = onDismiss)
                        .padding(horizontal = 22.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .background(Gold),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = Color(0xFF3A2A00),
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    Text(
                        if (c.fullSeries) tr("Série terminée !")
                        else if (c.type == ContentType.VOD) tr("Film terminé !")
                        else tr("Épisode terminé"),
                        color = Gold,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(Modifier.height(6.dp))

                    Text(
                        c.title,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 18.sp
                    )

                    c.subtitle?.let {
                        Text(it, color = TextMid, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
