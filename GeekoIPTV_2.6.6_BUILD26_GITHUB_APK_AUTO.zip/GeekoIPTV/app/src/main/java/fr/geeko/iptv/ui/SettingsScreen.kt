package fr.geeko.iptv.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.ui.theme.*
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.data.ContentType
import fr.geeko.iptv.ui.i18n.Lang
import fr.geeko.iptv.ui.i18n.tr

/** Langues proposées pour les pistes audio et les sous-titres. */
val LANGS = listOf(
    "fre" to "Français",
    "eng" to "Anglais",
    "spa" to "Espagnol",
    "ger" to "Allemand",
    "ita" to "Italien",
    "por" to "Portugais",
    "rus" to "Russe",
    "ara" to "Arabe",
    "gre" to "Grec",
    "chi" to "Chinois",
    "kor" to "Coréen",
    "jpn" to "Japonais",
    "dut" to "Néerlandais",
    "tur" to "Turc"
)

private val BOOSTS = listOf(1.5f, 2f, 2.5f, 3f, 4f)

/** Espacement minimal entre deux rappels, en heures. */
private val REMINDER_RATES = listOf(
    0 to "Jamais",
    24 to "Une fois par jour",
    60 to "Tous les 2-3 jours",
    168 to "Une fois par semaine"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    val context = LocalContext.current
    var confirmForget by remember { mutableStateOf(false) }
    var cropUri by remember { mutableStateOf<Uri?>(null) }
    var appLanguageDialog by remember { mutableStateOf(false) }
    var subtitleLanguageDialog by remember { mutableStateOf(false) }
    var playlistRefreshDialog by remember { mutableStateOf(false) }
    var showPlaylistPassword by remember { mutableStateOf(false) }
    var showReminderPreview by remember { mutableStateOf(false) }
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) cropUri = uri
    }

    if (appLanguageDialog) {
        SelectionDialog(
            title = tr("Langue de l'application"),
            options = Lang.entries.map { it.code to it.label },
            selected = vm.language.code,
            onPick = { code ->
                vm.language = Lang.from(code)
                appLanguageDialog = false
            },
            onDismiss = { appLanguageDialog = false }
        )
    }
    if (subtitleLanguageDialog) {
        SelectionDialog(
            title = tr("Sous-titres"),
            options = LANGS,
            selected = s.subtitleLang,
            onPick = { code ->
                vm.updateSettings(s.copy(subtitleLang = code))
                subtitleLanguageDialog = false
            },
            onDismiss = { subtitleLanguageDialog = false }
        )
    }
    if (playlistRefreshDialog) {
        SelectionDialog(
            title = "Actualisation des listes",
            options = listOf(
                "0" to "À chaque ouverture de l'app",
                "1" to "Toutes les 2 heures",
                "2" to "Manuel uniquement"
            ),
            selected = vm.playlistRefreshMode.toString(),
            onPick = { code ->
                vm.playlistRefreshMode = code.toIntOrNull() ?: 0
                playlistRefreshDialog = false
            },
            onDismiss = { playlistRefreshDialog = false }
        )
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(tr("Réglages"), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text(vm.profile?.name ?: "", fontSize = 12.sp, color = TextLow)
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { vm.back() },
                        modifier = Modifier.tvFocus(scale = 1.05f)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Surface1)
            )
        }
    ) { pad ->
        Column(
            Modifier
                .appBackground()
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {

            // ------------------------------------------------------- langues
            Section(tr("Langues")) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("Langue de l'application"), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        ChoiceRow(
                            label = vm.language.label,
                            onClick = { appLanguageDialog = true }
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text(tr("Sous-titres"), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        ChoiceRow(
                            label = LANGS.firstOrNull { it.first == s.subtitleLang }?.second ?: s.subtitleLang,
                            onClick = { subtitleLanguageDialog = true }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Field(tr("Sous-titres par défaut")) {
                    ToggleRow(
                        tr("Activer par défaut"),
                        checked = s.subtitlesOn
                    ) { vm.updateSettings(s.copy(subtitlesOn = it)) }
                }
                Text(
                    tr("Les pistes audio se choisissent directement dans le lecteur."),
                    color = TextLow, fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            // ------------------------------------------------------- lecture
            Section(tr("Lecture")) {
                Field(
                    tr("Vitesse du bouton maintenu"),
                    "Maintiens le bouton rond ou la flèche droite : la vidéo passe à cette " +
                        "vitesse et revient à la normale au relâchement."
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BOOSTS.forEach { b ->
                            FilterChip(
                                selected = s.boostSpeed == b,
                                onClick = { vm.updateSettings(s.copy(boostSpeed = b)) },
                                shape = RoundedCornerShape(18.dp),
                                label = {
                                    Text(
                                        if (b == b.toInt().toFloat()) "${b.toInt()}×" else "$b×",
                                        fontSize = 13.sp
                                    )
                                },
                                modifier = Modifier.tvFocus(RoundedCornerShape(18.dp), 1.05f)
                            )
                        }
                    }
                }
            }

            // -------------------------------------------------- télécommande
            Section(tr("Télécommande")) {
                Field(
                    tr("Bouton dédié"),
                    "Règle Button Mapper sur « lancer GeekoIPTV ». Quand l'app est déjà à " +
                        "l'écran, ce bouton déclenche l'action choisie."
                ) {
                    Column {
                        (listOf(null) + PlayerAction.entries.filter {
                            it != PlayerAction.BOOST_HOLD && it != PlayerAction.EXIT
                        }).forEach { a ->
                            val id = a?.id ?: "none"
                            RadioRow(
                                label = a?.label?.let { tr(it) } ?: tr("Rien"),
                                selected = s.shortcutAction == id
                            ) { vm.updateSettings(s.copy(shortcutAction = id)) }
                        }
                    }
                }
                NavRow(tr("Remapper les touches")) { vm.go(Screen.Keymap) }
                NavRow(tr("Tester les touches")) { vm.go(Screen.RemoteTest) }
            }

            // ----------------------------------------------------- apparence
            Section(tr("Apparence")) {
                Field("Aperçu notification", "Teste la vraie notification « À regarder plus tard » en direct") {
                    Button(
                        onClick = { showReminderPreview = true },
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .widthIn(min = 220.dp, max = 320.dp)
                            .tvFocus(RoundedCornerShape(18.dp), 1.04f)
                    ) {
                        Text("Tester la notification")
                    }
                }
                Field("Image de fond personnalisée", "Choisis ta propre image et recadre-la en 16:9") {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { bgPicker.launch("image/*") },
                            modifier = Modifier.tvFocus(RoundedCornerShape(18.dp), 1.05f)
                        ) { Text("Choisir une image") }
                        if (!AppearanceState.current.customBackground.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = {
                                    AppearanceState.current = AppearanceState.current.copy(customBackground = null)
                                    vm.saveAppearance()
                                },
                                modifier = Modifier.tvFocus(RoundedCornerShape(18.dp), 1.05f)
                            ) { Text("Retirer") }
                        }
                    }
                }
                Field(tr("Thèmes"), tr("Un point de départ, tout reste modifiable ensuite")) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(ThemePresets.size) { i ->
                            val preset = ThemePresets[i]
                            val selected = AppearanceState.current.background ==
                                preset.background.toInt()
                            Column(
                                Modifier
                                    .width(96.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(
                                        width = if (selected) 2.5.dp else 1.dp,
                                        color = if (selected) Accent
                                        else TextLow.copy(alpha = 0.35f),
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .tvFocus(RoundedCornerShape(16.dp), 1.06f)
                                    .clickable {
                                        applyPreset(preset)
                                        vm.saveAppearance()
                                    }
                                    .padding(6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                ThemePreview(
                                    background = Color(preset.background),
                                    rail = Color(preset.rail),
                                    panel = Color(preset.panel),
                                    accent = Color(preset.accent),
                                    texture = preset.texture,
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(preset.name, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }

                Field(tr("Texture du fond"), tr("Des ambiances plus visuelles pour le salon")) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        items(TextureNames.size) { index ->
                            val name = TextureNames[index]
                            val selected = AppearanceState.current.texture == index
                            Column(
                                Modifier
                                    .width(92.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(
                                        width = if (selected) 2.5.dp else 1.dp,
                                        color = if (selected) Accent
                                        else TextLow.copy(alpha = 0.35f),
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .tvFocus(RoundedCornerShape(14.dp), 1.05f)
                                    .clickable {
                                        AppearanceState.current =
                                            AppearanceState.current.copy(texture = index)
                                        vm.saveAppearance()
                                    }
                                    .padding(5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                ThemeTexturePreview(
                                    texture = index,
                                    modifier = Modifier.fillMaxWidth().height(42.dp)
                                )
                                Spacer(Modifier.height(5.dp))
                                Text(tr(name), fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }

                Text(
                    "Les couleurs de chaque module se règlent depuis l'icône palette " +
                        "posée dessus, et la disposition depuis l'icône grille.",
                    color = TextLow, fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                ToggleRow(tr("Petit son à l'ouverture des profils"), checked = vm.soundEnabled) {
                    vm.soundEnabled = it
                }

                Spacer(Modifier.height(14.dp))

                Field(
                    tr("Rappels « à regarder plus tard »"),
                    tr("À quelle fréquence au maximum le bandeau peut apparaître")
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        REMINDER_RATES.forEach { (hours, label) ->
                            FilterChip(
                                selected = vm.reminderIntervalHours == hours,
                                onClick = { vm.reminderIntervalHours = hours },
                                shape = RoundedCornerShape(18.dp),
                                label = { Text(tr(label), fontSize = 13.sp) },
                                modifier = Modifier.tvFocus(RoundedCornerShape(18.dp), 1.05f)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                TextButton(
                    onClick = {
                        AppearanceState.current = Appearance()
                        vm.saveAppearance()
                    },
                    modifier = Modifier.tvFocus(scale = 1.03f)
                ) { Text(tr("Remettre l'apparence d'origine"), fontSize = 13.sp) }
            }

            // --------------------------------------------------- application
            Section(tr("Application")) {
                Text(
                    "Version ${vm.currentVersionName} (build ${vm.currentVersionCode})",
                    fontSize = 13.sp
                )
                when (val st = vm.updateState) {
                    is UpdateState.Checking ->
                        Text(tr("Vérification en cours…"), color = TextLow, fontSize = 11.sp)
                    is UpdateState.UpToDate ->
                        Text(tr("Tu es à jour."), color = TextLow, fontSize = 11.sp)
                    is UpdateState.Available ->
                        Text("Version ${st.info.versionName} disponible", color = MaterialTheme.colorScheme.secondary, fontSize = 11.sp)
                    is UpdateState.Failed ->
                        Text(st.message, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    else -> Unit
                }
                Spacer(Modifier.height(10.dp))
                Text("Actualisation des listes", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                ChoiceRow(
                    label = when (vm.playlistRefreshMode) {
                        1 -> "Toutes les 2 heures"
                        2 -> "Manuel uniquement"
                        else -> "À chaque ouverture de l'app"
                    },
                    onClick = { playlistRefreshDialog = true }
                )
                Spacer(Modifier.height(12.dp))
                TwoColumnOptions(
                    listOf(
                        "🏆  Titres terminés" to { vm.go(Screen.Completed) },
                        "⬇  Téléchargements" to { vm.go(Screen.Downloads) },
                        "↻  Mise à jour app" to { vm.checkForUpdate(silent = false) },
                        "⟳  Actualiser les listes" to { vm.refreshHome() }
                    )
                )
                Spacer(Modifier.height(14.dp))
                Text("Gérer les groupes", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(7.dp))
                TwoColumnOptions(
                    listOf(
                        "TV" to {
                            vm.back(); vm.tab = HomeTab.LIVE
                            vm.loadCategories(fr.geeko.iptv.data.ContentType.LIVE)
                            vm.manageMode = true
                        },
                        "Films" to {
                            vm.back(); vm.tab = HomeTab.VOD
                            vm.loadCategories(fr.geeko.iptv.data.ContentType.VOD)
                            vm.manageMode = true
                        },
                        "Séries" to {
                            vm.back(); vm.tab = HomeTab.SERIES
                            vm.loadCategories(fr.geeko.iptv.data.ContentType.SERIES)
                            vm.manageMode = true
                        }
                    )
                )
            }

            // --------------------------------------------------------- compte
            Section(tr("Compte")) {
                Text("Soutenir GeekoIPTV", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(7.dp))
                OutlinedTextField(
                    value = vm.store.donationUrl,
                    onValueChange = { vm.store.donationUrl = it },
                    label = { Text("Lien de don (PayPal, Ko-fi…)") },
                    placeholder = { Text("https://...") },
                    singleLine = true,
                    modifier = Modifier.widthIn(min = 300.dp, max = 520.dp)
                )
                Text(
                    "Le logo GeekoIPTV ouvrira une invitation au don. Aucun message imposé au démarrage.",
                    color = TextLow, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )

                Text("Liste de lecture", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = Surface2,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        CredentialLine("URL", vm.store.host)
                        CredentialLine("Identifiant", vm.store.username)
                        CredentialLine(
                            "Mot de passe",
                            if (showPlaylistPassword) vm.store.password else "•".repeat(vm.store.password.length.coerceIn(6, 12)),
                            trailing = {
                                TextButton(
                                    onClick = { showPlaylistPassword = !showPlaylistPassword },
                                    modifier = Modifier.tvFocus(RoundedCornerShape(12.dp), 1.04f),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) { Text(if (showPlaylistPassword) "Masquer" else "Afficher", fontSize = 10.sp) }
                            }
                        )
                        HorizontalDivider(color = TextLow.copy(alpha = 0.18f))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { vm.refreshHome() },
                                shape = RoundedCornerShape(15.dp),
                                modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(15.dp), 1.04f)
                            ) { Text("Actualiser", fontSize = 11.sp) }
                            OutlinedButton(
                                onClick = { vm.replace(Screen.Login) },
                                shape = RoundedCornerShape(15.dp),
                                modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(15.dp), 1.04f)
                            ) { Text("Modifier", fontSize = 11.sp) }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                vm.account?.let {
                    Text("Serveur : ${it.serverName}", color = TextLow, fontSize = 13.sp)
                    Text("Abonnement jusqu'au ${it.expiry}", color = TextLow, fontSize = 13.sp)
                    val (live, movies, series) = vm.catalogCounts
                    if (movies > 0 || series > 0) {
                        Text(
                            "$live chaînes · $movies films · $series séries",
                            color = TextLow, fontSize = 13.sp
                        )
                    }
                    Text(
                        "Connexions : ${it.activeConnections}/${it.maxConnections}",
                        color = TextLow, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(12.dp))
                }
                TwoColumnOptions(
                    listOf(
                        "👤  Gérer les profils" to { vm.go(Screen.Profiles) },
                        "📺  Envoyer vers un téléviseur" to { vm.go(Screen.PairSend) }
                    )
                )
                Spacer(Modifier.height(10.dp))

                OutlinedButton(
                    onClick = { confirmForget = true },
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth().tvFocus(RoundedCornerShape(20.dp), 1.02f),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) { Text(tr("Oublier cet abonnement")) }
            }

            Spacer(Modifier.height(40.dp))
        }
    }

    if (confirmForget) {
        AlertDialog(
            onDismissRequest = { confirmForget = false },
            title = { Text(tr("Oublier cet abonnement ?")) },
            text = {
                Text(
                    tr("L'adresse du serveur, l'identifiant et le mot de passe seront effacés de l'appareil. Il faudra les saisir à nouveau.")
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmForget = false; vm.forgetServer() }) {
                    Text(tr("Oublier"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmForget = false }) { Text(tr("Annuler")) }
            }
        )
    }

    if (showReminderPreview) {
        val demoItems = remember {
            listOf(
                StreamItem("demo1", "Film à regarder", null, ContentType.VOD),
                StreamItem("demo2", "Série à continuer", null, ContentType.SERIES),
                StreamItem("demo3", "Autre suggestion", null, ContentType.VOD)
            )
        }
        ReminderBanner(
            items = demoItems,
            onOpen = { showReminderPreview = false },
            onRemove = { },
            onDismiss = { showReminderPreview = false },
            modifier = Modifier.fillMaxSize()
        )
    }

    cropUri?.let { uri ->
        BackgroundCropDialog(
            uri = uri,
            onDismiss = { cropUri = null },
            onConfirm = { zoom, x, y ->
                val path = saveCroppedBackground(context, uri, zoom, x, y)
                if (path != null) {
                    AppearanceState.current = AppearanceState.current.copy(
                        customBackground = path,
                        texture = 0
                    )
                    vm.saveAppearance()
                }
                cropUri = null
            }
        )
    }
}

@Composable
private fun BackgroundCropDialog(
    uri: Uri,
    onDismiss: () -> Unit,
    onConfirm: (Float, Float, Float) -> Unit
) {
    var zoom by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Recadrer le fond") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                coil.compose.AsyncImage(
                    model = uri,
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp))
                )
                Text("Zoom", fontSize = 12.sp)
                Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 1f..2.5f)
                Text("Décalage horizontal", fontSize = 12.sp)
                Slider(value = offsetX, onValueChange = { offsetX = it }, valueRange = -1f..1f)
                Text("Décalage vertical", fontSize = 12.sp)
                Slider(value = offsetY, onValueChange = { offsetY = it }, valueRange = -1f..1f)
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(zoom, offsetX, offsetY) }) { Text("Valider") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

private fun saveCroppedBackground(
    context: android.content.Context,
    uri: Uri,
    zoom: Float,
    offsetX: Float,
    offsetY: Float
): String? = runCatching {
    val bmp = context.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
        ?: return@runCatching null
    val ratio = 16f / 9f
    var cropW = bmp.width.toFloat()
    var cropH = cropW / ratio
    if (cropH > bmp.height) {
        cropH = bmp.height.toFloat()
        cropW = cropH * ratio
    }
    cropW = (cropW / zoom).coerceAtLeast(1f)
    cropH = (cropH / zoom).coerceAtLeast(1f)
    val maxX = (bmp.width - cropW).coerceAtLeast(0f)
    val maxY = (bmp.height - cropH).coerceAtLeast(0f)
    val left = (((offsetX + 1f) / 2f) * maxX).toInt().coerceIn(0, (bmp.width - cropW.toInt()).coerceAtLeast(0))
    val top = (((offsetY + 1f) / 2f) * maxY).toInt().coerceIn(0, (bmp.height - cropH.toInt()).coerceAtLeast(0))
    val cropped = android.graphics.Bitmap.createBitmap(
        bmp, left, top, cropW.toInt().coerceAtLeast(1), cropH.toInt().coerceAtLeast(1)
    )
    val outFile = File(context.filesDir, "custom_background.jpg")
    FileOutputStream(outFile).use { out ->
        cropped.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)
    }
    if (cropped !== bmp) cropped.recycle()
    bmp.recycle()
    outFile.absolutePath
}.getOrNull()

// --------------------------------------------------------------- briques

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        title.uppercase(),
        color = Accent,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 6.dp, top = 18.dp, bottom = 8.dp)
    )
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Surface1)
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun Field(title: String, subtitle: String? = null, content: @Composable () -> Unit) {
    Column(Modifier.padding(bottom = 16.dp)) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        if (subtitle != null) {
            Text(subtitle, color = TextLow, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .widthIn(min = 220.dp, max = 320.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Surface2)
            .tvFocus(RoundedCornerShape(16.dp), scale = 1.03f)
            .clickable { onChange(!checked) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .tvFocus(RoundedCornerShape(14.dp), scale = 1.02f)
            .clickable(onClick = onSelect)
            .padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 14.sp)
    }
}

@Composable
private fun NavRow(label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .widthIn(min = 180.dp, max = 340.dp)
            .clip(RoundedCornerShape(16.dp))
            .tvFocus(RoundedCornerShape(16.dp), scale = 1.02f)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Icon(
            Icons.Default.ChevronRight,
            contentDescription = null,
            tint = TextLow,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun CredentialLine(
    label: String,
    value: String,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = TextLow, fontSize = 10.sp)
            Text(value.ifBlank { "—" }, color = TextHigh, fontSize = 12.sp, maxLines = 1)
        }
        trailing?.invoke()
    }
}

@Composable
private fun TwoColumnOptions(options: List<Pair<String, () -> Unit>>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        options.chunked(2).forEach { row ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                row.forEach { (label, action) ->
                    Surface(
                        color = Surface2,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .tvFocus(RoundedCornerShape(16.dp), 1.03f)
                            .clickable(onClick = action)
                    ) {
                        Row(
                            Modifier.padding(horizontal = 13.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, Modifier.weight(1f), fontSize = 13.sp, maxLines = 2)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextLow, modifier = Modifier.size(17.dp))
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ReminderStylePreview() {
    val shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
    Surface(
        color = Surface1.copy(alpha = 0.97f),
        shape = shape,
        tonalElevation = 6.dp,
        modifier = Modifier
            .widthIn(min = 300.dp, max = 420.dp)
            .border(1.dp, Accent.copy(alpha = 0.35f), shape)
    ) {
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "✦  À regarder plus tard  ✦",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text("3 titres vous attendent", color = TextLow, fontSize = 9.sp)
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Film", "Série", "Film").forEachIndexed { i, label ->
                    Box(
                        Modifier
                            .width(54.dp)
                            .height(76.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Accent.copy(alpha = 0.45f - i * 0.06f),
                                        Surface2
                                    )
                                )
                            ),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Text(
                            label,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 8.sp,
                            modifier = Modifier.padding(5.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeTexturePreview(texture: Int, modifier: Modifier = Modifier) {
    val imageRes = when (texture) {
        8 -> fr.geeko.iptv.R.drawable.theme_metal
        9 -> fr.geeko.iptv.R.drawable.theme_wood
        10 -> fr.geeko.iptv.R.drawable.theme_industrial
        11 -> fr.geeko.iptv.R.drawable.theme_nature
        12 -> fr.geeko.iptv.R.drawable.theme_sakura
        else -> null
    }
    val shaped = modifier.clip(RoundedCornerShape(10.dp))
    if (imageRes != null) {
        Image(
            painter = painterResource(imageRes),
            contentDescription = null,
            modifier = shaped,
            contentScale = ContentScale.Crop
        )
    } else {
        Box(shaped.textureBackground(Ink, Accent, texture, isLightTheme))
    }
}

@Composable
private fun ChoiceRow(label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .widthIn(min = 180.dp, max = 300.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Surface2)
            .border(1.dp, Accent.copy(alpha = 0.16f), RoundedCornerShape(16.dp))
            .tvFocus(RoundedCornerShape(16.dp), 1.03f)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextLow)
    }
}

@Composable
private fun SelectionDialog(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        containerColor = Surface1,
        tonalElevation = 10.dp,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 360.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(options, key = { it.first }) { (code, label) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (code == selected) Accent.copy(alpha = 0.18f) else Color.Transparent)
                            .tvFocus(RoundedCornerShape(14.dp), 1.02f)
                            .clickable { onPick(code) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = code == selected, onClick = { onPick(code) })
                        Spacer(Modifier.width(8.dp))
                        Text(label, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Annuler")) } }
    )
}
