package fr.geeko.iptv.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import fr.geeko.iptv.data.ContentType
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.ui.theme.AppearanceState
import kotlinx.coroutines.launch
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.TextLow
import kotlin.math.abs

/**
 * Défilement horizontal façon Wii : les jaquettes pivotent et s'effacent
 * à mesure qu'elles s'éloignent du centre de l'écran.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CoverCarousel(
    entries: List<StreamItem>,
    subtitleOf: (StreamItem) -> String?,
    markedOf: (StreamItem) -> Boolean,
    onClick: (StreamItem) -> Unit,
    onLongClick: (StreamItem) -> Unit,
    modifier: Modifier = Modifier,
    cardWidth: Int = 230,
    blurbOf: (StreamItem) -> String? = { null },
    onRequestBlurb: (StreamItem) -> Unit = {},
    doneOf: (StreamItem) -> Boolean = { false },
    initialIndex: Int = 0
) {
    val state = rememberLazyListState(initialFirstVisibleItemIndex = initialIndex.coerceAtLeast(0))
    val snap = rememberSnapFlingBehavior(lazyListState = state)
    val info = state.layoutInfo
    val viewportStart = info.viewportStartOffset
    val viewportEnd = info.viewportEndOffset
    val viewportCenter = (viewportStart + viewportEnd) / 2f
    val half = ((viewportEnd - viewportStart) / 2f).coerceAtLeast(1f)

    BoxWithConstraints(modifier.fillMaxSize()) {
        val available = maxWidth.value.toInt()
        val posterAreaHeight = (maxHeight - 118.dp).coerceAtLeast(170.dp)
        val maxPosterWidth = (posterAreaHeight.value * (2f / 3f)).toInt().coerceAtLeast(60)
        val effectiveCardWidth = cardWidth.coerceAtMost(maxPosterWidth)

        Column(Modifier.fillMaxSize()) {
            LazyRow(
                state = state,
                flingBehavior = snap,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(
                    horizontal = ((available - effectiveCardWidth) / 2).coerceAtLeast(16).dp,
                    vertical = 34.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(count = entries.size, key = { entries[it].key }) { index ->
                    val item = entries[index]
                    val visible = info.visibleItemsInfo.firstOrNull { it.index == index }
                    val distance = visible?.let { it.offset + it.size / 2f - viewportCenter } ?: 0f
                    val normalized = (distance / half).coerceIn(-1.4f, 1.4f)
                    val away = abs(normalized)

                    Column(
                        Modifier
                            .width(effectiveCardWidth.dp)
                            .graphicsLayer {
                                rotationY = normalized * 30f
                                val scale = 1f - away * 0.18f
                                scaleX = scale
                                scaleY = scale
                                alpha = 1f - away * 0.28f
                                cameraDistance = 18f * density
                                translationX = -normalized * 16f * density
                            }
                            .tvFocus(RoundedCornerShape(18.dp), scale = 1.04f)
                            .combinedClickable(
                                // Important : on ouvre l'élément réellement focalisé.
                                // On ne recalcule plus un pseudo « centre », qui faisait partir
                                // sur la jaquette de gauche sur Shield.
                                onClick = { onClick(item) },
                                onLongClick = { onLongClick(item) }
                            ),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(2f / 3f)
                        ) {
                            Poster(
                                item.icon,
                                item.name,
                                Modifier.fillMaxSize(),
                                corner = 18,
                                scale = androidx.compose.ui.layout.ContentScale.Fit
                            )
                            if (markedOf(item)) BookmarkBadge(Modifier.align(Alignment.TopStart))
                            if (doneOf(item)) {
                                CompletedBadge(
                                    fullSeries = item.type == ContentType.SERIES,
                                    modifier = Modifier.align(Alignment.BottomEnd)
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            item.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        subtitleOf(item)?.takeIf { it.isNotBlank() }?.let {
                            Text(
                                it,
                                color = TextLow,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}
