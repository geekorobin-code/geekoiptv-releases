package fr.geeko.iptv.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.geeko.iptv.data.DownloadState
import fr.geeko.iptv.ui.i18n.tr
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.Mint
import fr.geeko.iptv.ui.theme.TextLow

/**
 * Bouton de téléchargement : l'anneau qui l'entoure montre la progression,
 * l'icône change d'état, et un appui long annule ou relance.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DownloadButton(
    vm: AppViewModel,
    downloadKey: String,
    size: Int = 40,
    modifier: Modifier = Modifier,
    onStart: () -> Unit
) {
    val context = LocalContext.current
    val item = vm.downloadOf(downloadKey)
    val state = item?.state

    // Android 13+ : la notification de progression demande une autorisation.
    // Le téléchargement démarre de toute façon, accordée ou non.
    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { onStart() }

    fun begin() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            onStart()
        }
    }

    val progress by animateFloatAsState(
        targetValue = item?.progress ?: 0f,
        animationSpec = tween(400),
        label = "download-progress"
    )

    val tint = when (state) {
        DownloadState.DONE -> Mint
        DownloadState.FAILED -> MaterialTheme.colorScheme.error
        DownloadState.RUNNING, DownloadState.QUEUED -> Accent
        else -> TextLow
    }

    Box(
        modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, tint.copy(alpha = 0.35f), CircleShape)
            .tvFocus(CircleShape, scale = 1.1f)
            .combinedClickable(
                onClick = {
                    when (state) {
                        null -> begin()
                        DownloadState.FAILED -> vm.retryDownload(downloadKey)
                        else -> Unit
                    }
                },
                onLongClick = {
                    // annule un transfert en cours, ou supprime un fichier gardé
                    if (state != null) vm.removeDownload(downloadKey)
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        when (state) {
            DownloadState.QUEUED -> CircularProgressIndicator(
                color = Accent,
                strokeWidth = 2.dp,
                modifier = Modifier.size((size - 8).dp)
            )

            DownloadState.RUNNING -> CircularProgressIndicator(
                progress = { progress },
                color = Accent,
                trackColor = Color.White.copy(alpha = 0.12f),
                strokeWidth = 2.5.dp,
                modifier = Modifier.size((size - 8).dp)
            )

            else -> Unit
        }

        Icon(
            when (state) {
                DownloadState.DONE -> Icons.Default.CloudDone
                DownloadState.FAILED -> Icons.Default.ErrorOutline
                else -> Icons.Default.CloudDownload
            },
            contentDescription = when (state) {
                DownloadState.DONE -> tr("Téléchargé")
                DownloadState.FAILED -> tr("Échec du téléchargement")
                DownloadState.RUNNING, DownloadState.QUEUED -> tr("Téléchargement en cours")
                else -> tr("Télécharger")
            },
            tint = tint,
            modifier = Modifier.size((size / 2.4f).dp)
        )
    }
}
