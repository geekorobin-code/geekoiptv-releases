package fr.geeko.iptv.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp

/** Réglages d'apparence choisis par l'utilisateur, module par module. */
/** Les couleurs sont stockées en ARGB : n'importe quelle teinte est possible. */
data class Appearance(
    val rail: Int = DEFAULT_RAIL,
    val panel: Int = DEFAULT_PANEL,
    val background: Int = DEFAULT_BACKGROUND,
    val accent: Int = DEFAULT_ACCENT,
    val layout: Int = 2,
    /** Zoom tactile des jaquettes sur téléphone/tablette. 1f = taille du mode choisi. */
    val posterScale: Float = 1f,
    val flipCards: Boolean = false,
    /** 0 uni, 1 grain, 2 lignes, 3 halo, 4 bois, 5 feu, 6 fleuri, 7 manga,
     *  8 métal, 9 bois photo, 10 industriel, 11 nature, 12 sakura. */
    val texture: Int = 0,
    val customBackground: String? = null
)

const val DEFAULT_RAIL = 0xFF14141F.toInt()
const val DEFAULT_PANEL = 0xFF1D1D2B.toInt()
const val DEFAULT_BACKGROUND = 0xFF0A0A11.toInt()
const val DEFAULT_ACCENT = 0xFFFF3D7F.toInt()

/**
 * État global de l'apparence. Les couleurs ci-dessous sont des accesseurs :
 * elles lisent cet état, donc tout l'écran se recompose au changement.
 */
object AppearanceState {
    /** Recopié depuis les réglages : évite de porter le contexte jusqu'ici. */
    var soundEnabled: Boolean = true

    var current by mutableStateOf(Appearance())
}

/** Raccourcis pratiques, en plus du cercle chromatique. */
val AccentPresets = listOf(
    Color(0xFFFF3D7F), Color(0xFFFF2D55), Color(0xFFFF7A18), Color(0xFFFFC24B),
    Color(0xFF3DDC97), Color(0xFF00E5C0), Color(0xFF4EA8FF), Color(0xFF7C5CFF),
    Color(0xFFB47BFF), Color(0xFFFF5FD2), Color(0xFF9BFF3D), Color(0xFFFFFFFF)
)

// Teintes franches : les anciennes étaient si désaturées qu'elles
// paraissaient toutes grises une fois projetées.
val SurfacePresets = listOf(
    Color(0xFF2E1B4E), Color(0xFF1B3A5C), Color(0xFF0F3D3A), Color(0xFF4A1C36),
    Color(0xFF14304A), Color(0xFF3A2352), Color(0xFF522A1C), Color(0xFF1E4030),
    Color(0xFF232338), Color(0xFF45203A), Color(0xFF17364E), Color(0xFF2C2C2C)
)

val BackgroundPresets = listOf(
    Color(0xFF0A0A11), Color(0xFF000000), Color(0xFF0D1B2E), Color(0xFF1A0E2A),
    Color(0xFF0A1F1C), Color(0xFF2A0F22), Color(0xFF12142B), Color(0xFF221408),
    Color(0xFF0E2436), Color(0xFF1E1030), Color(0xFF061A15), Color(0xFF1A1A1A)
)

// Accesseurs dynamiques : lisibles depuis n'importe quel composable.
val Accent: Color get() = Color(AppearanceState.current.accent)
val Surface1: Color get() = Color(AppearanceState.current.rail)
val Surface2: Color get() = Color(AppearanceState.current.panel)
val Ink: Color get() = Color(AppearanceState.current.background)
val Surface3: Color get() =
    if (isLightTheme) Surface2.lighten(-0.06f) else Surface2.lighten(0.09f)

val AccentSoft: Color get() = Accent.copy(alpha = 0.55f)
val Mint = Color(0xFF3DDC97)
val Gold = Color(0xFFFFC24B)

/** Un fond clair impose un texte sombre : on bascule tout automatiquement. */
val isLightTheme: Boolean get() = Ink.luminance() > 0.42f

val TextHigh: Color get() = if (isLightTheme) Color(0xFF15151C) else Color(0xFFF2F1F7)
val TextMid: Color get() = if (isLightTheme) Color(0xFF4C4C5C) else Color(0xFFB6B4C6)
val TextLow: Color get() = if (isLightTheme) Color(0xFF7A7A8A) else Color(0xFF7C7A90)

val ProfileColors = listOf(
    Color(0xFFFF3D7F), Color(0xFF3DDC97), Color(0xFF4EA8FF),
    Color(0xFFB47BFF), Color(0xFFFF9A3D), Color(0xFFFFD447)
)

private fun Color.lighten(amount: Float): Color = Color(
    red = (red + amount).coerceIn(0f, 1f),
    green = (green + amount).coerceIn(0f, 1f),
    blue = (blue + amount).coerceIn(0f, 1f),
    alpha = alpha
)

private val shapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

/** Thèmes tout prêts. */
data class ThemePreset(
    val name: String,
    val rail: Long,
    val panel: Long,
    val background: Long,
    val accent: Long,
    val texture: Int
)

val ThemePresets = listOf(
    ThemePreset("Nuit magenta", 0xFF14141F, 0xFF1D1D2B, 0xFF0A0A11, 0xFFFF3D7F, 3),
    ThemePreset("Cinéma", 0xFF121212, 0xFF1A1A1A, 0xFF060606, 0xFFFFC24B, 1),
    ThemePreset("Bleu nuit", 0xFF111C2E, 0xFF17263D, 0xFF080F1A, 0xFF4EA8FF, 3),
    ThemePreset("Sobre", 0xFF1A1A1E, 0xFF232329, 0xFF101014, 0xFFB6B4C6, 0),
    ThemePreset("Forêt", 0xFF102019, 0xFF162C22, 0xFF07120E, 0xFF3DDC97, 2),
    ThemePreset("Ardoise claire", 0xFFEDEDF2, 0xFFF7F7FA, 0xFFE4E4EC, 0xFF6B4BFF, 2),
    ThemePreset("Papier", 0xFFF2EEE6, 0xFFFAF7F1, 0xFFEAE4D8, 0xFFC2410C, 1),
    ThemePreset("Néon", 0xFF16101F, 0xFF201630, 0xFF0B0713, 0xFF00E5C0, 3),
    ThemePreset("Boisé", 0xFF2C190E, 0xFF3A2113, 0xFF2B160C, 0xFFFFB15A, 4),
    ThemePreset("Feu", 0xFF220808, 0xFF35100C, 0xFF090406, 0xFFFF6A24, 5),
    ThemePreset("Fleuri", 0xFF211421, 0xFF2A1830, 0xFF101A14, 0xFFFF83C5, 6),
    ThemePreset("Manga", 0xFF18181D, 0xFF25252B, 0xFF111115, 0xFFFF335C, 7),
    ThemePreset("Métallique", 0xFF101820, 0xFF17232D, 0xFF070B10, 0xFF46D7FF, 8),
    ThemePreset("Bois chaleureux", 0xFF24150C, 0xFF352012, 0xFF100A06, 0xFFFFA64D, 9),
    ThemePreset("Loft industriel", 0xFF151515, 0xFF222222, 0xFF090909, 0xFF4EA8FF, 10),
    ThemePreset("Nature / Jungle", 0xFF102019, 0xFF183025, 0xFF07110D, 0xFF45E38A, 11),
    ThemePreset("Fleur de cerisier", 0xFF211526, 0xFF301C36, 0xFF100B14, 0xFFFF78C8, 12)
)

fun applyPreset(preset: ThemePreset) {
    AppearanceState.current = AppearanceState.current.copy(
        rail = preset.rail.toInt(),
        panel = preset.panel.toInt(),
        background = preset.background.toInt(),
        accent = preset.accent.toInt(),
        texture = preset.texture,
        customBackground = null
    )
}

@Composable
fun GeekoTheme(content: @Composable () -> Unit) {
    val scheme = if (isLightTheme) lightColorScheme(
        primary = Accent,
        onPrimary = Color.White,
        primaryContainer = Accent.copy(alpha = 0.18f),
        onPrimaryContainer = TextHigh,
        secondary = Mint,
        background = Ink,
        onBackground = TextHigh,
        surface = Surface1,
        onSurface = TextHigh,
        surfaceVariant = Surface2,
        onSurfaceVariant = TextMid,
        outline = Color(0xFFB9B9C6),
        outlineVariant = Color(0xFFD6D6E0)
    ) else darkColorScheme(
        primary = Accent,
        onPrimary = Color(0xFF120309),
        primaryContainer = Accent.copy(alpha = 0.25f),
        onPrimaryContainer = TextHigh,
        secondary = Mint,
        onSecondary = Color(0xFF04231A),
        background = Ink,
        onBackground = TextHigh,
        surface = Surface1,
        onSurface = TextHigh,
        surfaceVariant = Surface2,
        onSurfaceVariant = TextMid,
        outline = Color(0xFF33334A),
        outlineVariant = Color(0xFF232334)
    )
    MaterialTheme(colorScheme = scheme, shapes = shapes, content = content)
}
