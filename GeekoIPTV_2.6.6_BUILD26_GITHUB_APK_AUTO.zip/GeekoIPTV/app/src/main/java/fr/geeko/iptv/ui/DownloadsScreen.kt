package fr.geeko.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.data.DownloadItem
import fr.geeko.iptv.data.DownloadState
import fr.geeko.iptv.ui.i18n.tr
import fr.geeko.iptv.ui.theme.*

private fun formatSize(bytes: Long): String = when {
    bytes <= 0 -> "—"
    bytes < 1024L * 1024 -> "${bytes / 1024} Ko"
    bytes < 1024L * 1024 * 1024 -> "${bytes / (1024 * 1024)} Mo"
    else -> "%.1f Go".format(bytes / (1024.0 * 1024 * 1024))
}

private val recordingClock = java.text.SimpleDateFormat("dd/MM · HH:mm", java.util.Locale.FRANCE)


@Composable
fun DownloadsScreen(vm: AppViewModel) {
    var confirmClear by remember { mutableStateOf(false) }
    val list = vm.downloads.sortedByDescending { it.at }
    val used = list.filter { it.state == DownloadState.DONE }.sumOf { it.total }

    Column(Modifier.fillMaxSize().appBackground().statusBarsPadding()) {

        Row(
            Modifier.fillMaxWidth().padding(start = 6.dp, end = 16.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.back() }, modifier = Modifier.tvFocus(scale = 1.05f)) {
                Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
            }
            Spacer(Modifier.width(4.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    tr("Téléchargements"),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (used > 0) {
                    Text(formatSize(used), color = TextLow, fontSize = 12.sp)
                }
            }
            if (list.isNotEmpty()) {
                TextButton(onClick = { confirmClear = true }) {
                    Text(
                        tr("Tout effacer"),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.CloudDownload,
                        contentDescription = null,
                        tint = TextLow,
                        modifier = Modifier.size(42.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        tr("Rien de téléchargé pour l'instant"),
                        color = TextLow,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        tr("Utilise le bouton de téléchargement sur une fiche film ou un épisode."),
                        color = TextLow,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 40.dp)
                    )
                }
            }
            return@Column
        }

        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.key }) { d ->
                DownloadRow(
                    item = d,
                    onPlay = { vm.playDownload(d) },
                    onDelete = { vm.removeDownload(d.key) }
                )
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr("Tout effacer")) },
            text = {
                Text(tr("Les fichiers téléchargés seront supprimés de l'appareil."))
            },
            confirmButton = {
                TextButton(onClick = { vm.clearDownloads(); confirmClear = false }) {
                    Text(tr("Effacer"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text(tr("Annuler")) }
            }
        )
    }
}

@Composable
private fun DownloadRow(item: DownloadItem, onPlay: () -> Unit, onDelete: () -> Unit) {
    val done = item.state == DownloadState.DONE

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Surface1)
            .tvFocus(RoundedCornerShape(18.dp), scale = 1.02f)
            .clickable(enabled = done, onClick = onPlay)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Poster(item.icon, item.title, Modifier.width(52.dp), corner = 12)
        Spacer(Modifier.width(14.dp))

        Column(Modifier.weight(1f)) {
            Text(
                item.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            item.subtitle?.let {
                Text(it, color = TextLow, fontSize = 12.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }

            Spacer(Modifier.height(6.dp))

            when (item.state) {
                DownloadState.SCHEDULED -> Text(
                    "Programmé · ${recordingClock.format(java.util.Date(item.scheduledStart))}",
                    color = Accent, fontSize = 11.sp
                )

                DownloadState.DONE -> Text(
                    formatSize(item.total),
                    color = Mint, fontSize = 11.sp
                )

                DownloadState.FAILED -> Text(
                    tr("Échec du téléchargement"),
                    color = MaterialTheme.colorScheme.error, fontSize = 11.sp
                )

                else -> {
                    LinearProgressIndicator(
                        progress = { item.progress },
                        color = Accent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (item.total > 0)
                            "${formatSize(item.downloaded)} / ${formatSize(item.total)}"
                        else tr("En attente…"),
                        color = TextLow, fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(Modifier.width(8.dp))

        Icon(
            when (item.state) {
                DownloadState.SCHEDULED -> Icons.Default.Schedule
                DownloadState.DONE -> Icons.Default.CheckCircle
                DownloadState.FAILED -> Icons.Default.ErrorOutline
                else -> Icons.Default.CloudDownload
            },
            contentDescription = null,
            tint = when (item.state) {
                DownloadState.SCHEDULED -> Accent
                DownloadState.DONE -> Mint
                DownloadState.FAILED -> MaterialTheme.colorScheme.error
                else -> TextLow
            },
            modifier = Modifier.size(20.dp)
        )

        if (done) {
            IconButton(onClick = onPlay, modifier = Modifier.size(38.dp)) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = tr("Lire"),
                    tint = Accent,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        IconButton(onClick = onDelete, modifier = Modifier.size(38.dp)) {
            Icon(
                Icons.Default.Delete,
                contentDescription = tr("Supprimer"),
                tint = TextLow,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
