package fr.geeko.iptv.data

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class UpdateInfo(
    val versionCode: Int,
    val versionName: String,
    val notes: String,
    val apkUrl: String,
    val sha256: String?,
    val mandatory: Boolean
)

class UpdateException(message: String) : Exception(message)

/**
 * Mise à jour hors Play Store : on lit un petit manifeste JSON hébergé
 * (GitHub Releases, GitHub Pages, n'importe quel serveur), on compare le
 * versionCode, on télécharge l'APK puis on ouvre l'installeur système.
 *
 * L'APK doit être signé avec la MÊME clé que la version déjà installée,
 * sinon Android refuse la mise à jour.
 */
class Updater(private val context: Context) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val dir: File
        get() = File(context.getExternalFilesDir(null), "updates").apply { mkdirs() }

    // ------------------------------------------------------------- lecture

    suspend fun check(manifestUrl: String, currentVersionCode: Int): UpdateInfo? =
        withContext(Dispatchers.IO) {
            val req = Request.Builder()
                .url(manifestUrl)
                .header("Cache-Control", "no-cache")
                .header("User-Agent", XtreamClient.UA)
                .build()

            val body = http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) throw UpdateException("Serveur de mise à jour injoignable (${res.code})")
                res.body?.string() ?: throw UpdateException("Manifeste vide")
            }

            val o = runCatching { JSONObject(body) }.getOrNull()
                ?: throw UpdateException("Manifeste illisible")

            val versionCode = o.optInt("versionCode", -1)
            if (versionCode <= 0) throw UpdateException("versionCode absent du manifeste")
            if (versionCode <= currentVersionCode) return@withContext null

            val apkUrl = o.optString("apkUrl").takeIf { it.isNotBlank() }
                ?: throw UpdateException("apkUrl absent du manifeste")

            UpdateInfo(
                versionCode = versionCode,
                versionName = o.optString("versionName", versionCode.toString()),
                notes = o.optString("notes", "").trim(),
                apkUrl = apkUrl,
                sha256 = o.optString("sha256").takeIf { it.length == 64 },
                mandatory = o.optBoolean("mandatory", false)
            )
        }

    // -------------------------------------------------------- téléchargement

    suspend fun download(info: UpdateInfo, onProgress: (Float) -> Unit): File =
        withContext(Dispatchers.IO) {
            dir.listFiles()?.forEach { it.delete() }
            val target = File(dir, "GeekoIPTV-${info.versionName}.apk")

            val req = Request.Builder()
                .url(info.apkUrl)
                .header("User-Agent", XtreamClient.UA)
                .build()

            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) throw UpdateException("Téléchargement refusé (${res.code})")
                val body = res.body ?: throw UpdateException("Fichier vide")
                val total = body.contentLength()
                var read = 0L

                body.byteStream().use { input ->
                    target.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            output.write(buffer, 0, n)
                            read += n
                            if (total > 0) onProgress((read.toFloat() / total).coerceIn(0f, 1f))
                        }
                    }
                }
            }

            if (target.length() < 1024) {
                target.delete()
                throw UpdateException("Fichier téléchargé invalide")
            }

            info.sha256?.let { expected ->
                val actual = sha256(target)
                if (!actual.equals(expected, ignoreCase = true)) {
                    target.delete()
                    throw UpdateException("Empreinte du fichier incorrecte, installation annulée")
                }
            }

            onProgress(1f)
            target
        }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    // -------------------------------------------------------- installation

    fun canInstall(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            context.packageManager.canRequestPackageInstalls()
        else true

    /** Ouvre les réglages « Installer des applications inconnues » pour cette app. */
    fun requestInstallPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val intent = Intent(
            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun install(file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
