package fr.geeko.iptv.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import fr.geeko.iptv.data.ContentType
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.ui.theme.*
import fr.geeko.iptv.ui.i18n.tr

private fun StreamItem.displayRating(): String? =
    rating?.trim()?.takeIf { it.isNotBlank() && it != "0" && it != "0.0" }
        ?.let { if (it.length > 3) it.take(3) else it }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaCard(
    item: StreamItem,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    marked: Boolean = false,
    blurb: String? = null,
    completed: Boolean = false,
    fullSeries: Boolean = false,
    onRequestBlurb: () -> Unit = {},
    onClick: () -> Unit,
    onLongClick: () -> Unit = {}
) {
    val live = item.type == ContentType.LIVE

    Column(
        modifier
            .tvFocus(RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(if (live) 1f else 2f / 3f)
        ) {
            Poster(
                item.icon,
                item.name,
                Modifier.fillMaxWidth(),
                ratio = if (live) 1f else 2f / 3f,
                corner = if (live) 14 else 16,
                scale = if (live) ContentScale.Fit else ContentScale.Crop
            )
            item.displayRating()?.let {
                if (!live) RatingBadge(it, Modifier.align(Alignment.TopEnd))
            }
            if (marked) BookmarkBadge(Modifier.align(Alignment.TopStart))
            if (completed) CompletedBadge(fullSeries, Modifier.align(Alignment.BottomEnd))
        }

        Spacer(Modifier.height(7.dp))
        Text(
            item.name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            lineHeight = 16.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (!subtitle.isNullOrBlank()) {
            Text(
                subtitle,
                color = TextLow,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MediaCardBack(
    item: StreamItem,
    subtitle: String?,
    blurb: String?,
    onOpen: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Surface2)
            .padding(11.dp)
    ) {
        Text(
            item.name,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 15.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )

        val meta = listOfNotNull(
            subtitle,
            item.displayRating()?.let { "★ $it" }
        ).joinToString(" · ")
        if (meta.isNotBlank()) {
            Text(meta, color = Accent, fontSize = 10.sp, maxLines = 1)
        }

        Spacer(Modifier.height(7.dp))

        Box(Modifier.weight(1f)) {
            if (blurb == null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        color = Accent,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(tr("Résumé…"), color = TextLow, fontSize = 11.sp)
                }
            } else {
                Text(
                    blurb,
                    color = TextMid,
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    modifier = Modifier.verticalScroll(rememberScrollState())
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Accent)
                .tvFocus(RoundedCornerShape(14.dp), scale = 1.04f)
                .clickable(onClick = onOpen)
                .padding(vertical = 7.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (item.type == ContentType.SERIES) Icons.Default.Info
                else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(15.dp)
            )
            Spacer(Modifier.width(5.dp))
            Text(
                if (item.type == ContentType.SERIES) tr("Épisodes") else tr("Ouvrir"),
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
