package fr.geeko.iptv

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import fr.geeko.iptv.data.Store
import fr.geeko.iptv.data.Updater
import java.util.concurrent.TimeUnit

/**
 * Va voir de temps en temps s'il existe une version plus récente, même quand
 * l'application est fermée, et prévient par une notification.
 */
class UpdateWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        const val CHANNEL = "updates"
        private const val NOTIF_ID = 7381
        private const val WORK_NAME = "geekoiptv-update-check"
        const val EXTRA_FROM_NOTIFICATION = "from_update_notification"

        /** À appeler au démarrage : le travail existant est conservé tel quel. */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<UpdateWorker>(12, TimeUnit.HOURS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .setInitialDelay(2, TimeUnit.HOURS)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }

    override suspend fun doWork(): Result {
        val store = Store(applicationContext)

        val info = runCatching {
            Updater(applicationContext).check(
                BuildConfig.UPDATE_URL,
                BuildConfig.VERSION_CODE
            )
        }.getOrNull() ?: return Result.success()

        // Une seule notification par version : sans ça, l'utilisateur serait
        // relancé deux fois par jour jusqu'à ce qu'il installe.
        if (store.notifiedUpdateVersion >= info.versionCode) return Result.success()
        store.notifiedUpdateVersion = info.versionCode

        notify(info.versionName, info.notes)
        return Result.success()
    }

    private fun notify(versionName: String, notes: String) {
        val manager = applicationContext
            .getSystemService(NotificationManager::class.java) ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL,
                    "Mises à jour",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = "Nouvelle version de GeekoIPTV disponible" }
            )
        }

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_FROM_NOTIFICATION, true)
        }
        val pending = PendingIntent.getActivity(
            applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val text = notes.replace("\n", " · ").ifBlank {
            "Appuie pour installer la nouvelle version."
        }

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("GeekoIPTV $versionName est disponible")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()

        runCatching { manager.notify(NOTIF_ID, notification) }
    }
}
