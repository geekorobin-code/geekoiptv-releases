package fr.geeko.iptv.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.focusable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.paint
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.rememberAsyncImagePainter
import java.io.File
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.ui.theme.*
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.sin
import fr.geeko.iptv.ui.i18n.tr

// ---------------------------------------------------------------- dispositions

enum class LayoutMode(val label: String, val cardWidth: Int) {
    LIST("Liste", 0),
    SMALL("Petites jaquettes", 100),
    MEDIUM("Jaquettes moyennes", 132),
    LARGE("Grandes jaquettes", 176),
    CAROUSEL("Carrousel", 190),
    MINI("Mini jaquettes", 72)
}

fun currentLayout(): LayoutMode =
    LayoutMode.entries[AppearanceState.current.layout.coerceIn(0, LayoutMode.entries.lastIndex)]

// ----------------------------------------------------------- persistance

fun loadAppearance(json: String) {
    if (json.isBlank()) return
    val o = runCatching { JSONObject(json) }.getOrNull() ?: return
    AppearanceState.current = Appearance(
        rail = o.optInt("rail", DEFAULT_RAIL),
        panel = o.optInt("panel", DEFAULT_PANEL),
        background = o.optInt("bg", DEFAULT_BACKGROUND),
        accent = o.optInt("accent", DEFAULT_ACCENT),
        layout = o.optInt("layout", 2),
        posterScale = o.optDouble("posterScale", 1.0).toFloat().coerceIn(0.55f, 1.75f),
        flipCards = false,
        texture = o.optInt("texture", 0),
        customBackground = o.optString("customBg").takeIf { it.isNotBlank() }
    )
}

fun appearanceToJson(): String {
    val a = AppearanceState.current
    return JSONObject().apply {
        put("rail", a.rail)
        put("panel", a.panel)
        put("bg", a.background)
        put("accent", a.accent)
        put("layout", a.layout)
        put("posterScale", a.posterScale)
        put("flip", a.flipCards)
        put("texture", a.texture)
        put("customBg", a.customBackground ?: "")
    }.toString()
}

// ------------------------------------------------------------- palette

enum class PaletteTarget(val title: String) {
    RAIL(tr("Colonne de navigation")),
    PANEL(tr("Colonne des groupes")),
    BACKGROUND(tr("Fond du contenu"))
}

/** Petit bouton palette à poser sur chaque module. */
@Composable
fun PaletteButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.08f))
            .tvFocus(CircleShape, scale = 1.12f)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Default.Palette,
            contentDescription = tr("Personnaliser"),
            tint = TextMid,
            modifier = Modifier.size(15.dp)
        )
    }
}

@Composable
fun PaletteDialog(target: PaletteTarget, onSave: () -> Unit, onDismiss: () -> Unit) {
    val a = AppearanceState.current
    val presets = when (target) {
        PaletteTarget.BACKGROUND -> BackgroundPresets
        else -> SurfacePresets
    }
    val currentColor = when (target) {
        PaletteTarget.RAIL -> a.rail
        PaletteTarget.PANEL -> a.panel
        PaletteTarget.BACKGROUND -> a.background
    }
    val default = when (target) {
        PaletteTarget.RAIL -> DEFAULT_RAIL
        PaletteTarget.PANEL -> DEFAULT_PANEL
        PaletteTarget.BACKGROUND -> DEFAULT_BACKGROUND
    }

    fun applyModule(color: Int) {
        AppearanceState.current = when (target) {
            PaletteTarget.RAIL -> AppearanceState.current.copy(rail = color)
            PaletteTarget.PANEL -> AppearanceState.current.copy(panel = color)
            PaletteTarget.BACKGROUND -> AppearanceState.current.copy(background = color)
        }
        onSave()
    }

    var tab by remember { mutableIntStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(target.title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (target == PaletteTarget.RAIL) {
                    TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
                        Tab(tab == 0, { tab = 0 }, text = { Text(tr("Module"), fontSize = 13.sp) })
                        Tab(tab == 1, { tab = 1 }, text = { Text(tr("Accent"), fontSize = 13.sp) })
                    }
                    Spacer(Modifier.height(14.dp))
                }

                if (target != PaletteTarget.RAIL || tab == 0) {
                    ColorPicker(
                        color = Color(currentColor),
                        presets = presets,
                        onPick = { applyModule(it.toArgb()) }
                    )
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { applyModule(default) }) {
                        Text(tr("Remettre la couleur d'origine"), fontSize = 13.sp)
                    }
                } else {
                    ColorPicker(
                        color = Accent,
                        presets = AccentPresets,
                        minValue = 0.35f,
                        onPick = {
                            AppearanceState.current =
                                AppearanceState.current.copy(accent = it.toArgb())
                            onSave()
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = {
                        AppearanceState.current =
                            AppearanceState.current.copy(accent = DEFAULT_ACCENT)
                        onSave()
                    }) { Text(tr("Remettre l'accent d'origine"), fontSize = 13.sp) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Fermer")) } }
    )
}

/** Cercle chromatique : teinte par l'angle, saturation par le rayon, luminosité au curseur. */
@Composable
fun ColorPicker(
    color: Color,
    presets: List<Color>,
    minValue: Float = 0.08f,
    onPick: (Color) -> Unit
) {
    val hsv = remember(color) {
        val out = FloatArray(3)
        android.graphics.Color.colorToHSV(color.toArgb(), out)
        out
    }
    var hue by remember(color) { mutableFloatStateOf(hsv[0]) }
    var saturation by remember(color) { mutableFloatStateOf(hsv[1]) }
    // Les fonds sont très sombres : si on repartait de leur luminosité réelle,
    // n'importe quelle teinte choisie paraîtrait noire. On remonte donc un peu.
    var value by remember(color) {
        mutableFloatStateOf(hsv[2].coerceAtLeast(if (hsv[2] < 0.18f) 0.32f else minValue))
    }

    val hueRing = remember {
        (0..360 step 20).map { Color.hsv(it.toFloat().coerceAtMost(359.9f), 1f, 1f) }
    }

    fun emit() = onPick(Color.hsv(hue, saturation, value))

    Column(horizontalAlignment = Alignment.CenterHorizontally) {

        // Le cercle se pilote au doigt : à la télécommande, on offre des
        // réglages linéaires, qui reçoivent le focus et répondent au D-pad.
        if (LocalIsTv.current) {
            Box(
                Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.hsv(hue, saturation, value))
                    .border(2.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
            )

            Spacer(Modifier.height(18.dp))

            TvSlider(tr("Teinte"), hue, 0f, 360f) { hue = it; emit() }
            TvSlider(tr("Intensité"), saturation, 0f, 1f) { saturation = it; emit() }
            TvSlider(tr("Luminosité"), value, minValue, 1f) { value = it; emit() }

            Spacer(Modifier.height(16.dp))

            Text(tr("Raccourcis"), color = TextLow, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            PresetRow(presets) { picked ->
                val out = FloatArray(3)
                android.graphics.Color.colorToHSV(picked.toArgb(), out)
                hue = out[0]; saturation = out[1]
                value = out[2].coerceAtLeast(minValue)
                emit()
            }
            return@Column
        }

        Box(
            Modifier
                .size(190.dp)
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val dx = offset.x - c.x
                        val dy = offset.y - c.y
                        val radius = minOf(size.width, size.height) / 2f
                        hue = ((atan2(dy, dx) * 180f / PI.toFloat()) + 360f) % 360f
                        saturation = (hypot(dx, dy) / radius).coerceIn(0f, 1f)
                        emit()
                    }
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val dx = change.position.x - c.x
                        val dy = change.position.y - c.y
                        val radius = minOf(size.width, size.height) / 2f
                        hue = ((atan2(dy, dx) * 180f / PI.toFloat()) + 360f) % 360f
                        saturation = (hypot(dx, dy) / radius).coerceIn(0f, 1f)
                        emit()
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val radius = size.minDimension / 2f
                drawCircle(Brush.sweepGradient(hueRing), radius = radius)
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White, Color.White.copy(alpha = 0f)),
                        center = center,
                        radius = radius
                    ),
                    radius = radius
                )
                // repère de la couleur courante
                val angle = hue * PI.toFloat() / 180f
                val px = center.x + cos(angle) * radius * saturation
                val py = center.y + sin(angle) * radius * saturation
                drawCircle(Color.White, radius = 9f, center = Offset(px, py))
                drawCircle(
                    Color.Black.copy(alpha = 0.5f), radius = 9f,
                    center = Offset(px, py), style = Stroke(width = 2f)
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.hsv(hue, saturation, value))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            )
            Spacer(Modifier.width(12.dp))
            Text(tr("Luminosité"), color = TextLow, fontSize = 12.sp)
            Slider(
                value = value,
                onValueChange = { value = it.coerceAtLeast(minValue); emit() },
                valueRange = minValue..1f,
                modifier = Modifier.weight(1f).padding(start = 10.dp)
            )
        }

        Spacer(Modifier.height(12.dp))
        Text(tr("Raccourcis"), color = TextLow, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))

        presets.chunked(6).forEach { row ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                row.forEach { preset ->
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(preset)
                            .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(10.dp))
                            .tvFocus(RoundedCornerShape(10.dp), scale = 1.12f)
                            .clickable { onPick(preset) }
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------ choix de disposition

@Composable
fun LayoutButton(onSave: () -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }

    Box(modifier) {
        Box(
            Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.08f))
                .tvFocus(CircleShape, scale = 1.12f)
                .clickable { open = true },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.GridView,
                contentDescription = tr("Disposition"),
                tint = TextMid,
                modifier = Modifier.size(15.dp)
            )
        }

        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            LayoutMode.entries.forEachIndexed { index, mode ->
                DropdownMenuItem(
                    text = {
                        Text(
                            tr(mode.label),
                            color = if (index == AppearanceState.current.layout) Accent else TextHigh
                        )
                    },
                    onClick = {
                        AppearanceState.current = AppearanceState.current.copy(layout = index)
                        onSave()
                        open = false
                    }
                )
            }
        }
    }
}

// ------------------------------------------------------------- étincelles

/**
 * Petite bouffée d'étoiles autour d'un élément qui apparaît.
 * Façon écran d'accueil de console.
 */
@Composable
fun SparkleBurst(
    visible: Boolean,
    modifier: Modifier = Modifier,
    color: Color = Gold,
    branches: Int = 7
) {
    val progress by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMillis = 780, easing = FastOutSlowInEasing),
        label = "sparkle"
    )

    Canvas(modifier) {
        if (progress <= 0.01f || progress >= 0.99f) return@Canvas
        val radius = size.minDimension * (0.32f + 0.34f * progress)
        val fade = 1f - progress
        val starSize = size.minDimension * 0.085f * (1.25f - progress * 0.7f)

        repeat(branches) { i ->
            val angle = (i * 360.0 / branches + progress * 26.0) * PI / 180.0
            val cx = center.x + (cos(angle) * radius).toFloat()
            val cy = center.y + (sin(angle) * radius).toFloat()
            drawPath(
                path = starPath(cx, cy, starSize, starSize * 0.4f),
                color = color.copy(alpha = fade)
            )
        }
    }
}

private fun starPath(cx: Float, cy: Float, outer: Float, inner: Float): Path {
    val path = Path()
    val points = 4
    for (i in 0 until points * 2) {
        val r = if (i % 2 == 0) outer else inner
        val angle = (i * PI / points) - PI / 2
        val x = cx + (cos(angle) * r).toFloat()
        val y = cy + (sin(angle) * r).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

// ------------------------------------------------------------- fond texturé

val TextureNames = listOf("Uni", "Grain", "Lignes", "Halo", "Boisé", "Feu", "Fleuri", "Manga", "Métallique", "Bois chaleureux", "Loft industriel", "Nature / Jungle", "Fleur de cerisier")

/**
 * Fond de l'application : couleur unie plus, si choisi, une texture discrète
 * dessinée à la volée — pas d'image à embarquer.
 */
@Composable
fun Modifier.appBackground(): Modifier {
    val a = AppearanceState.current
    val custom = a.customBackground?.takeIf { File(it).exists() }
    val imagePainter = when {
        custom != null -> rememberAsyncImagePainter(File(custom))
        a.texture == 8 -> painterResource(fr.geeko.iptv.R.drawable.theme_metal)
        a.texture == 9 -> painterResource(fr.geeko.iptv.R.drawable.theme_wood)
        a.texture == 10 -> painterResource(fr.geeko.iptv.R.drawable.theme_industrial)
        a.texture == 11 -> painterResource(fr.geeko.iptv.R.drawable.theme_nature)
        a.texture == 12 -> painterResource(fr.geeko.iptv.R.drawable.theme_sakura)
        else -> null
    }
    return if (imagePainter != null) {
        this
            .background(Ink)
            .paint(
                painter = imagePainter,
                sizeToIntrinsics = false,
                contentScale = ContentScale.Crop,
                alpha = 0.54f
            )
    } else {
        textureBackground(Ink, Accent, a.texture, isLightTheme)
    }
}

/** Même rendu que le fond de l'app, mais avec des couleurs imposées : sert aux aperçus. */
fun Modifier.textureBackground(
    base: Color,
    accent: Color,
    texture: Int,
    light: Boolean
): Modifier {
    val ink = if (light) Color.Black else Color.White

    return this.drawBehind {
        drawRect(base)
        when (texture) {
            1 -> { // grain : semis de points
                val step = 9.dp.toPx()
                val alpha = if (light) 0.05f else 0.035f
                var y = 0f
                var row = 0
                while (y < size.height) {
                    var x = if (row % 2 == 0) 0f else step / 2f
                    while (x < size.width) {
                        drawCircle(ink.copy(alpha = alpha), radius = 1.1f, center = Offset(x, y))
                        x += step
                    }
                    y += step
                    row++
                }
            }

            2 -> { // fines diagonales
                val step = 16.dp.toPx()
                val alpha = if (light) 0.05f else 0.03f
                var x = -size.height
                while (x < size.width) {
                    drawLine(
                        color = ink.copy(alpha = alpha),
                        start = Offset(x, 0f),
                        end = Offset(x + size.height, size.height),
                        strokeWidth = 1f
                    )
                    x += step
                }
            }

            3 -> { // halo coloré en haut à gauche + vignette
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(accent.copy(alpha = 0.16f), Color.Transparent),
                        center = Offset(size.width * 0.18f, size.height * 0.05f),
                        radius = size.maxDimension * 0.75f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Color.Transparent, base.copy(alpha = 0.55f)),
                        center = Offset(size.width * 0.5f, size.height * 0.45f),
                        radius = size.maxDimension * 0.72f
                    )
                )
            }
            4 -> { // bois : planches chaudes + veinage
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color(0xFF2B160C), Color(0xFF5A2F18), Color(0xFF241108))
                    )
                )
                val plank = 58.dp.toPx()
                var y = 0f
                var row = 0
                while (y < size.height) {
                    drawLine(Color(0xFF120905).copy(alpha = 0.72f),
                        Offset(0f, y), Offset(size.width, y), 2.2f)
                    var x = if (row % 2 == 0) size.width * 0.18f else size.width * 0.62f
                    while (x < size.width) {
                        drawLine(Color.Black.copy(alpha = 0.28f),
                            Offset(x, y), Offset(x, (y + plank).coerceAtMost(size.height)), 1.6f)
                        x += size.width * 0.48f
                    }
                    y += plank
                    row++
                }
                val grain = 22.dp.toPx()
                var gy = grain / 2f
                while (gy < size.height) {
                    drawLine(
                        Color(0xFFFFC07A).copy(alpha = 0.055f),
                        Offset(0f, gy),
                        Offset(size.width, gy + 8.dp.toPx()),
                        1.2f
                    )
                    gy += grain
                }
                drawRect(Color.Black.copy(alpha = 0.28f))
            }

            5 -> { // feu : flammes reconnaissables + braises sur fond sombre
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color(0xFF050203), Color(0xFF260603), Color(0xFF5B1205))
                    )
                )
                val flameXs = listOf(.08f, .22f, .38f, .55f, .72f, .88f)
                flameXs.forEachIndexed { i, fx ->
                    val baseY = size.height * 1.03f
                    val h = size.height * (0.32f + (i % 3) * 0.08f)
                    val w = size.width * 0.13f
                    val cx = size.width * fx
                    val flame = Path().apply {
                        moveTo(cx - w, baseY)
                        cubicTo(cx - w * .8f, baseY - h * .30f, cx - w * .25f, baseY - h * .46f, cx, baseY - h)
                        cubicTo(cx + w * .16f, baseY - h * .60f, cx + w * .95f, baseY - h * .40f, cx + w, baseY)
                        close()
                    }
                    drawPath(
                        flame,
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFFFFF2A0), Color(0xFFFF8A22), Color(0xFFE52A0B), Color.Transparent),
                            startY = baseY - h,
                            endY = baseY
                        )
                    )
                }
                // petites braises flottantes
                repeat(18) { i ->
                    val x = size.width * (((i * 37) % 97) / 97f)
                    val y = size.height * (0.20f + (((i * 53) % 61) / 100f))
                    val r = (1.5f + (i % 3)) * density
                    drawCircle(Color(0xFFFFA33A).copy(alpha = .30f + (i % 4) * .08f), r, Offset(x, y))
                }
                drawRect(Color.Black.copy(alpha = 0.18f))
            }
            6 -> { // fleuri : vraies fleurs/pétales visibles, pas seulement des points
                drawRect(
                    Brush.linearGradient(
                        listOf(Color(0xFF07130D), Color(0xFF251126), Color(0xFF0C1B17)),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height)
                    )
                )
                val flowerCenters = listOf(
                    Offset(size.width*.12f, size.height*.20f), Offset(size.width*.36f, size.height*.58f),
                    Offset(size.width*.62f, size.height*.23f), Offset(size.width*.82f, size.height*.67f),
                    Offset(size.width*.20f, size.height*.82f), Offset(size.width*.93f, size.height*.18f)
                )
                val colors = listOf(Color(0xFFFF75B5), Color(0xFFFFC3E1), Color(0xFFE5A3FF), Color(0xFFFFE08A))
                flowerCenters.forEachIndexed { idx, c ->
                    val petal = 15.dp.toPx()
                    repeat(5) { p ->
                        val a = (p / 5f) * (Math.PI * 2).toFloat()
                        val pc = Offset(c.x + kotlin.math.cos(a)*petal, c.y + kotlin.math.sin(a)*petal)
                        drawCircle(colors[idx % colors.size].copy(alpha = .24f), petal*.72f, pc)
                    }
                    drawCircle(Color(0xFFFFD64A).copy(alpha=.45f), petal*.38f, c)
                    drawLine(Color(0xFF6CCB87).copy(alpha=.22f), c, Offset(c.x-18.dp.toPx(), c.y+72.dp.toPx()), 2.dp.toPx())
                }
                // quelques pétales libres façon sakura
                repeat(14) { i ->
                    val x = size.width * (((i*29)%101)/101f)
                    val y = size.height * (((i*47)%89)/89f)
                    drawOval(Color(0xFFFF9DCE).copy(alpha=.15f), Offset(x,y), androidx.compose.ui.geometry.Size(13.dp.toPx(),7.dp.toPx()))
                }
                drawRect(Color.Black.copy(alpha = 0.20f))
            }
            7 -> { // manga / BD : cases, trames, bulles et traits de vitesse
                val paper = if (light) Color(0xFFF7F3E8) else Color(0xFF111116)
                val inkM = if (light) Color(0xFF111111) else Color(0xFFF2F2F2)
                drawRect(paper)

                // Grandes cases de BD visibles.
                val stroke = 3.dp.toPx()
                drawRect(inkM.copy(alpha=.30f), topLeft=Offset(size.width*.04f,size.height*.08f), size=androidx.compose.ui.geometry.Size(size.width*.38f,size.height*.38f), style=Stroke(stroke))
                drawRect(inkM.copy(alpha=.30f), topLeft=Offset(size.width*.46f,size.height*.08f), size=androidx.compose.ui.geometry.Size(size.width*.49f,size.height*.38f), style=Stroke(stroke))
                drawRect(inkM.copy(alpha=.30f), topLeft=Offset(size.width*.04f,size.height*.52f), size=androidx.compose.ui.geometry.Size(size.width*.55f,size.height*.39f), style=Stroke(stroke))
                drawRect(inkM.copy(alpha=.30f), topLeft=Offset(size.width*.63f,size.height*.52f), size=androidx.compose.ui.geometry.Size(size.width*.32f,size.height*.39f), style=Stroke(stroke))

                // Trame halftone dans la première case.
                val dot=11.dp.toPx(); var yy=size.height*.10f; var rr=0
                while(yy<size.height*.44f){ var xx=size.width*.06f + if(rr%2==0) 0f else dot/2; while(xx<size.width*.40f){ drawCircle(inkM.copy(alpha=.12f),1.7f,Offset(xx,yy)); xx+=dot }; yy+=dot; rr++ }

                // Bulle de dialogue très identifiable.
                val bubble = Path().apply {
                    moveTo(size.width*.52f,size.height*.16f)
                    quadraticBezierTo(size.width*.70f,size.height*.08f,size.width*.88f,size.height*.18f)
                    quadraticBezierTo(size.width*.96f,size.height*.26f,size.width*.86f,size.height*.34f)
                    quadraticBezierTo(size.width*.70f,size.height*.42f,size.width*.54f,size.height*.33f)
                    quadraticBezierTo(size.width*.46f,size.height*.25f,size.width*.52f,size.height*.16f)
                    close()
                }
                drawPath(bubble, Color.White.copy(alpha=if(light) .85f else .18f))
                drawPath(bubble, inkM.copy(alpha=.45f), style=Stroke(2.dp.toPx()))
                val tail=Path().apply{ moveTo(size.width*.60f,size.height*.34f); lineTo(size.width*.54f,size.height*.46f); lineTo(size.width*.68f,size.height*.36f); close() }
                drawPath(tail, Color.White.copy(alpha=if(light) .85f else .18f)); drawPath(tail,inkM.copy(alpha=.45f),style=Stroke(2.dp.toPx()))

                // Traits de vitesse dans la grande case basse.
                val cx=size.width*.34f; val cy=size.height*.72f
                repeat(26){ i -> val a=(i/26f)*(Math.PI*2).toFloat(); val inner=size.minDimension*.05f; val outer=size.maxDimension*.38f; drawLine(inkM.copy(alpha=.12f),Offset(cx+kotlin.math.cos(a)*inner,cy+kotlin.math.sin(a)*inner),Offset(cx+kotlin.math.cos(a)*outer,cy+kotlin.math.sin(a)*outer), if(i%4==0) 2.4f else 1.2f) }
                drawRect(Color.Black.copy(alpha = if (light) .03f else .13f))
            }
        }
    }
}

/** Miniature de l'interface : rail, colonne des groupes et deux jaquettes. */
@Composable
fun ThemePreview(
    background: Color,
    rail: Color,
    panel: Color,
    accent: Color,
    texture: Int,
    modifier: Modifier = Modifier
) {
    val light = background.luminance() > 0.42f
    val onSurface = if (light) Color.Black else Color.White

    val scenicRes = when (texture) {
        8 -> fr.geeko.iptv.R.drawable.theme_metal
        9 -> fr.geeko.iptv.R.drawable.theme_wood
        10 -> fr.geeko.iptv.R.drawable.theme_industrial
        11 -> fr.geeko.iptv.R.drawable.theme_nature
        12 -> fr.geeko.iptv.R.drawable.theme_sakura
        else -> null
    }
    val previewBase = if (scenicRes != null) {
        modifier
            .clip(RoundedCornerShape(12.dp))
            .paint(painterResource(scenicRes), contentScale = ContentScale.Crop)
            .background(Color.Black.copy(alpha = 0.14f))
    } else {
        modifier
            .clip(RoundedCornerShape(12.dp))
            .textureBackground(background, accent, texture, light)
    }

    Row(
        previewBase.padding(5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // rail
        Column(
            Modifier
                .width(16.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(5.dp))
                .background(rail)
                .padding(3.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Box(
                Modifier.fillMaxWidth().height(4.dp)
                    .clip(RoundedCornerShape(2.dp)).background(accent)
            )
            repeat(3) {
                Box(
                    Modifier.fillMaxWidth().height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(onSurface.copy(alpha = 0.22f))
                )
            }
        }

        // colonne des groupes
        Column(
            Modifier
                .width(14.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(5.dp))
                .background(panel)
                .padding(3.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            repeat(4) {
                Box(
                    Modifier.fillMaxWidth().height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(onSurface.copy(alpha = 0.18f))
                )
            }
        }

        // jaquettes
        Row(
            Modifier.weight(1f).fillMaxHeight(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            repeat(3) { i ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(if (i == 1) 0.9f else 0.78f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(panel)
                        .border(
                            1.dp,
                            accent.copy(alpha = if (i == 1) 0.9f else 0.3f),
                            RoundedCornerShape(4.dp)
                        )
                )
            }
        }
    }
}

/**
 * Réglage linéaire piloté au D-pad.
 *
 * Le curseur de Material ne convient pas ici : les flèches y déplacent le
 * focus au lieu de changer la valeur. On dessine donc la barre nous-mêmes
 * et on intercepte gauche/droite avant que la navigation ne les consomme.
 */
@Composable
private fun TvSlider(
    label: String,
    value: Float,
    from: Float,
    to: Float,
    onChange: (Float) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val step = (to - from) / 32f
    val ratio = ((value - from) / (to - from)).coerceIn(0f, 1f)

    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = if (focused) Accent else TextLow,
            fontSize = 12.sp,
            modifier = Modifier.width(90.dp)
        )

        Box(
            Modifier
                .weight(1f)
                .height(34.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(
                    if (focused) Accent.copy(alpha = 0.10f) else Color.Transparent
                )
                .border(
                    width = if (focused) 2.dp else 1.dp,
                    color = if (focused) Accent else TextLow.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(17.dp)
                )
                .onFocusChanged { focused = it.isFocused }
                .focusable()
                .onPreviewKeyEvent { event ->
                    if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                    when (event.key) {
                        Key.DirectionLeft -> {
                            onChange((value - step).coerceIn(from, to)); true
                        }

                        Key.DirectionRight -> {
                            onChange((value + step).coerceIn(from, to)); true
                        }
                        // les autres touches restent à la navigation
                        else -> false
                    }
                }
                .padding(horizontal = 5.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            // rail
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.White.copy(alpha = 0.14f))
            )
            // portion remplie
            Box(
                Modifier
                    .fillMaxWidth(ratio)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Accent)
            )
            // pastille
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                Box(
                    Modifier
                        .offset(x = (maxWidth - 14.dp) * ratio)
                        .size(14.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.White)
                )
            }
        }
    }
}

/** Rangée de couleurs prêtes à l'emploi, chacune focusable. */
@Composable
private fun PresetRow(presets: List<Color>, onPick: (Color) -> Unit) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        presets.take(6).forEach { c ->
            Box(
                Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(c)
                    .tvFocus(RoundedCornerShape(12.dp), scale = 1.1f)
                    .clickable { onPick(c) }
            )
        }
    }
}
