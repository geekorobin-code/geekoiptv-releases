package fr.geeko.iptv.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.Surface1
import fr.geeko.iptv.ui.theme.TextLow
import kotlinx.coroutines.delay
import fr.geeko.iptv.ui.i18n.tr

private const val SPEED_MIN = 0.25f
private const val SPEED_MAX = 4.0f
private const val SPEED_STEP = 0.25f
private val BOOST_CHOICES = listOf(1.5f, 2f, 2.5f, 3f, 4f)

/** "fre", "fra", "fr", "French" -> "fr" */
private fun langKey(raw: String?): String {
    val s = raw?.lowercase()?.trim().orEmpty()
    if (s.isEmpty()) return ""
    return when {
        s.startsWith("fr") -> "fr"
        s.startsWith("en") || s.startsWith("ang") -> "en"
        s.startsWith("es") || s.startsWith("spa") -> "es"
        s.startsWith("de") || s.startsWith("ger") || s.startsWith("deu") -> "de"
        s.startsWith("it") -> "it"
        s.startsWith("pt") || s.startsWith("por") -> "pt"
        s.startsWith("ar") -> "ar"
        s.startsWith("nl") || s.startsWith("dut") -> "nl"
        s.startsWith("ru") || s.startsWith("rus") -> "ru"
        s.startsWith("el") || s.startsWith("gre") || s.startsWith("ell") -> "el"
        s.startsWith("zh") || s.startsWith("chi") || s.startsWith("cmn") -> "zh"
        s.startsWith("ko") || s.startsWith("kor") -> "ko"
        s.startsWith("ja") || s.startsWith("jpn") -> "ja"
        s.startsWith("tr") || s.startsWith("tur") -> "tr"
        else -> s.take(2)
    }
}

/**
 * Beaucoup de serveurs Xtream laissent le champ "language" vide et mettent
 * l'info dans le libellé de la piste (tr("Anglais"), "VF", "English"…).
 * On teste donc les deux.
 */
private val LANG_HINTS = mapOf(
    "fr" to listOf("fran", "french", "vff", "vfq", "vf", "fre", "fra"),
    "en" to listOf("angl", "engl", "eng", "vo "),
    "es" to listOf("espa", "spanish", "spa"),
    "de" to listOf("allem", "german", "deu", "ger"),
    "it" to listOf("ital"),
    "pt" to listOf("portug", "por"),
    "ar" to listOf("arab"),
    "nl" to listOf("neerl", "dutch"),
    "ru" to listOf("russ", "rus", "русск"),
    "el" to listOf("grec", "greek", "ell", "ελλ"),
    "zh" to listOf("chin", "mandarin", "cantonais", "中文", "普通话"),
    "ko" to listOf("core", "korea", "한국"),
    "ja" to listOf("japon", "japan", "日本"),
    "tr" to listOf("turc", "turk")
)

/** Devine la langue d'une piste à partir du code ISO puis du libellé. */
private fun trackLangKey(language: String?, label: String?): String {
    val byCode = langKey(language)
    if (byCode.isNotBlank() && byCode != "un") return byCode
    val text = label?.lowercase()?.trim().orEmpty()
    if (text.isEmpty()) return ""
    LANG_HINTS.forEach { (key, hints) ->
        if (hints.any { text.contains(it) }) return key
    }
    return ""
}

fun langLabel(code: String): String = when (langKey(code)) {
    "fr" -> "FR"; "en" -> "EN"; "es" -> "ES"; "de" -> "DE"
    "it" -> "IT"; "pt" -> "PT"; "ar" -> "AR"; "nl" -> "NL"
    "ru" -> "RU"; "el" -> "GR"; "zh" -> "ZH"; "ko" -> "KO"
    "ja" -> "JA"; "tr" -> "TR"
    else -> code.take(2).uppercase().ifBlank { "??" }
}

/** Libellé lisible d'une piste : on privilégie le nom donné par le serveur. */
private fun trackLabel(f: androidx.media3.common.Format, index: Int): String {
    val lang = trackLangKey(f.language, f.label)
    return listOfNotNull(
        f.label?.takeIf { it.isNotBlank() },
        if (f.label.isNullOrBlank() && lang.isNotBlank()) langLabel(lang) else null,
        f.codecs?.substringBefore('.')
    ).joinToString(" · ").ifBlank { "Piste ${index + 1}" }
}

/** Libellé court pour les pastilles de la barre : « FR », « VOST », « AAC »… */
private fun shortTrackLabel(f: androidx.media3.common.Format, index: Int): String {
    val lang = trackLangKey(f.language, f.label)
    if (lang.isNotBlank()) return langLabel(lang)
    val label = f.label?.trim()
    if (!label.isNullOrBlank()) return label.take(5).uppercase()
    return "#${index + 1}"
}

private fun fmtSpeed(v: Float): String =
    if (v == v.toInt().toFloat()) v.toInt().toString()
    else "%.2f".format(v).trimEnd('0').trimEnd('.')

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: AppViewModel, request: PlayRequest) {
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val isTv = LocalIsTv.current
    val settings = vm.settings

    // ------------------------------------------------------------- lecteur
    val player = remember {
        // Beaucoup de flux MPEG-TS mélangent AAC, AC-3 ou DTS. On autorise le repli
        // vers un autre décodeur et on laisse l'extracteur chercher plus loin.
        val renderers = DefaultRenderersFactory(context)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)

        val extractors = DefaultExtractorsFactory()
            .setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS or
                    DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
            )
            .setTsExtractorTimestampSearchBytes(1500 * 188)

        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("GeekoIPTV/1.0 (Android)")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(30_000)

        ExoPlayer.Builder(context)
            .setRenderersFactory(renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http, extractors))
            .build().apply {
                setMediaItem(MediaItem.fromUri(request.url))
                if (request.startMs > 0) seekTo(request.startMs)
                playWhenReady = true
                prepare()
            }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(request.startMs) }
    var duration by remember { mutableLongStateOf(0L) }
    var tvSeekFocused by remember { mutableStateOf(false) }
    var tvSeekPosition by remember { mutableLongStateOf(request.startMs) }
    var tvSeekLastStepAt by remember { mutableLongStateOf(0L) }
    var tracks by remember { mutableStateOf<Tracks>(Tracks.EMPTY) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    var playerView by remember { mutableStateOf<PlayerView?>(null) }

    // .ts <-> .m3u8 : certains serveurs ne servent l'audio correctement que dans
    // un seul des deux formats.
    var currentUrl by remember { mutableStateOf(request.url) }
    var formatSwitched by remember { mutableStateOf(false) }
    var needsFormatRetry by remember { mutableStateOf(false) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) duration = player.duration.coerceAtLeast(0L)
            }
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playbackError = error.errorCodeName
                needsFormatRetry = true
            }
        }
        player.addListener(listener)
        onDispose {
            // vignette du moment où on s'arrête, pour la rangée « en cours »
            val frame = if (request.isLive) null else runCatching {
                playerView?.let { view ->
                    (0 until view.childCount)
                        .map { view.getChildAt(it) }
                        .filterIsInstance<android.view.TextureView>()
                        .firstOrNull()
                        ?.bitmap
                }
            }.getOrNull()

            vm.savePlaybackPosition(
                request.history,
                player.currentPosition,
                player.duration,
                frame
            )
            frame?.recycle()
            playerView = null
            player.removeListener(listener)
            player.release()
        }
    }

    // --------------------------------------------- fenêtre flottante
    val activity = context as? Activity
    val pipAvailable = !isTv && supportsPip(context)

    // La diffusion ne concerne que les films et les épisodes : un Chromecast
    // ne sait pas lire le MPEG-TS des chaînes en direct.
    val canCast = !isTv && !request.isLive && remember { castAvailable(context) }

    DisposableEffect(Unit) {
        PipState.playerOpen = true
        PipState.onPlayPause = {
            if (player.isPlaying) player.pause() else player.play()
        }
        PipState.onSeek = { delta ->
            player.seekTo((player.currentPosition + delta).coerceAtLeast(0))
        }
        onDispose {
            PipState.reset()
            PipState.inPip = false
            activity?.let { clearPipAutoEnter(it) }
        }
    }

    LaunchedEffect(isPlaying) {
        PipState.playing = isPlaying
        if (activity != null && pipAvailable) refreshPipParams(activity)
    }

    // rapport de l'image, pour que la fenêtre ait la bonne forme
    DisposableEffect(player) {
        val sizeListener = object : Player.Listener {
            override fun onVideoSizeChanged(size: androidx.media3.common.VideoSize) {
                if (size.width > 0 && size.height > 0) {
                    PipState.aspect = size.width.toFloat() / size.height.toFloat()
                    if (activity != null && pipAvailable) refreshPipParams(activity)
                }
            }
        }
        player.addListener(sizeListener)
        onDispose { player.removeListener(sizeListener) }
    }

    // Sur téléphone/tablette on force le paysage. Sur TV, inutile.
    DisposableEffect(isTv) {
        val activity = context as? Activity
        val previous = activity?.requestedOrientation
        if (!isTv) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        onDispose {
            if (!isTv) {
                activity?.requestedOrientation =
                    previous ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            position = player.currentPosition
            if (duration <= 0) duration = player.duration.coerceAtLeast(0L)
            delay(400)
        }
    }

    LaunchedEffect(request.history) {
        while (request.history != null) {
            delay(15_000)
            vm.savePlaybackPosition(request.history, player.currentPosition, player.duration)
        }
    }

    // ------------------------------------------------------------- vitesse
    var baseSpeed by remember { mutableFloatStateOf(1f) }
    var boosting by remember { mutableStateOf(false) }
    var boostSpeed by remember { mutableFloatStateOf(settings.boostSpeed) }

    LaunchedEffect(baseSpeed, boosting, boostSpeed) {
        player.setPlaybackSpeed(if (boosting) boostSpeed else baseSpeed)
    }

    // -------------------------------------------------- audio & sous-titres
    var subsOn by remember { mutableStateOf(settings.subtitlesOn) }
    var activeAudioKey by remember { mutableStateOf("") }
    var activeAudioName by remember { mutableStateOf("—") }
    var showAudioMenu by remember { mutableStateOf(false) }
    // Deux emplacements de voix : on y met les deux premières pistes du flux,
    // et un appui long permet d'en changer quand il y en a davantage.
    var slotA by remember(tracks) { mutableIntStateOf(0) }
    var slotB by remember(tracks) { mutableIntStateOf(1) }
    var assigning by remember { mutableStateOf<Int?>(null) }
    var showSubMenu by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }

    // Placé après « toast » : le message de confirmation s'appuie dessus.

    if (canCast) {
        CastSessionWatcher(
            onStarted = {
                val sent = castCurrent(
                    context = context,
                    url = currentUrl,
                    title = request.title,
                    subtitle = request.subtitle,
                    poster = request.history?.icon,
                    positionMs = player.currentPosition
                )
                if (sent) {
                    player.pause()
                    toast = tr("Lecture envoyée sur le téléviseur")
                }
            },
            onEnded = { toast = tr("Diffusion terminée") }
        )
    }

    val audioTracks = remember(tracks) {
        tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
            .flatMap { g -> (0 until g.length).map { i -> g to i } }
    }
    val textTracks = remember(tracks) {
        tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
            .flatMap { g -> (0 until g.length).map { i -> g to i } }
    }

    // La piste réellement active est lue depuis le lecteur, pas supposée.
    LaunchedEffect(tracks) {
        val selected = audioTracks.firstOrNull { (g, i) -> g.isTrackSelected(i) }
        if (selected == null) {
            activeAudioKey = ""
            activeAudioName = "—"
        } else {
            val f = selected.first.getTrackFormat(selected.second)
            activeAudioKey = trackLangKey(f.language, f.label)
            activeAudioName = when {
                activeAudioKey.isNotBlank() -> langLabel(activeAudioKey)
                !f.label.isNullOrBlank() -> f.label!!.take(8)
                else -> "Piste ${selected.second + 1}"
            }
        }
    }

    LaunchedEffect(toast) {
        if (toast != null) { delay(1600); toast = null }
    }

    fun selectAudioTrack(group: Tracks.Group, index: Int) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, index))
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
            .build()
    }

    fun applyAudioLang(code: String) {
        val wanted = langKey(code)
        for ((g, i) in audioTracks) {
            if (!g.isTrackSupported(i)) continue
            val f = g.getTrackFormat(i)
            if (trackLangKey(f.language, f.label) == wanted) {
                selectAudioTrack(g, i)
                toast = "Audio ${langLabel(code)}"
                return
            }
        }

        // Aucune correspondance : on passe simplement à la piste suivante,
        // ce qui reste utile quand le serveur n'étiquette rien.
        val usable = audioTracks.filter { (g, i) -> g.isTrackSupported(i) }
        if (usable.size > 1) {
            val currentIndex = usable.indexOfFirst { (g, i) -> g.isTrackSelected(i) }
            val (g, i) = usable[(currentIndex + 1).coerceAtLeast(0) % usable.size]
            selectAudioTrack(g, i)
            val f = g.getTrackFormat(i)
            toast = "Audio " + (f.label ?: f.language?.let { langLabel(it) } ?: "piste ${i + 1}")
            return
        }

        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguage(code)
            .build()
        toast = tr("Une seule piste audio sur ce flux")
    }

    fun applySubtitles(enabled: Boolean, code: String? = null, announce: Boolean = false) {
        var builder = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !enabled)
        if (enabled && code != null) builder = builder.setPreferredTextLanguage(code)
        player.trackSelectionParameters = builder.build()
        subsOn = enabled
        if (announce) toast = if (enabled) tr("Sous-titres activés") else tr("Sous-titres désactivés")
    }

    LaunchedEffect(tracks) {
        if (tracks != Tracks.EMPTY) applySubtitles(subsOn, settings.subtitleLang)
    }

    /** Passe à la piste audio suivante du flux. */
    fun cycleAudio() {
        val usable = audioTracks.filter { (g, i) -> g.isTrackSupported(i) }
        if (usable.size < 2) {
            toast = tr("Une seule piste audio sur ce flux")
            return
        }
        val current = usable.indexOfFirst { (g, i) -> g.isTrackSelected(i) }
        val (g, i) = usable[(current + 1).coerceAtLeast(0) % usable.size]
        selectAudioTrack(g, i)
        val f = g.getTrackFormat(i)
        toast = tr("Audio") + " " + shortTrackLabel(f, i)
    }

    // ------------------------------------------------------------ contrôles
    var controlsVisible by remember(request.mysteryMode) { mutableStateOf(!request.mysteryMode) }
    var lastTouch by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var panelOpen by remember { mutableStateOf(false) }

    LaunchedEffect(controlsVisible, lastTouch, boosting, panelOpen) {
        if (controlsVisible && !boosting && !panelOpen) {
            delay(5000)
            if (System.currentTimeMillis() - lastTouch >= 4800) controlsVisible = false
        }
    }

    fun touch() { lastTouch = System.currentTimeMillis(); controlsVisible = true }

    /** Rejoue le même flux dans l'autre conteneur (.ts <-> .m3u8). */
    fun switchStreamFormat(auto: Boolean) {
        val next = when {
            currentUrl.endsWith(".m3u8", true) -> currentUrl.dropLast(5) + "ts"
            currentUrl.endsWith(".ts", true) -> currentUrl.dropLast(2) + "m3u8"
            else -> return
        }
        currentUrl = next
        formatSwitched = true
        val resume = player.currentPosition
        player.setMediaItem(MediaItem.fromUri(next))
        if (!request.isLive && resume > 0) player.seekTo(resume)
        player.prepare()
        player.playWhenReady = true
        toast = if (auto) tr("Pas de son détecté, changement de format…")
        else if (next.endsWith("m3u8")) "Format HLS" else "Format TS"
    }

    LaunchedEffect(needsFormatRetry) {
        if (needsFormatRetry && !formatSwitched) {
            needsFormatRetry = false
            playbackError = null
            switchStreamFormat(auto = true)
        }
    }

    // Aucune piste audio : on tente l'autre conteneur, une seule fois.
    LaunchedEffect(tracks) {
        if (tracks == Tracks.EMPTY || formatSwitched) return@LaunchedEffect
        val hasVideo = tracks.groups.any { it.type == C.TRACK_TYPE_VIDEO }
        val hasAudio = tracks.groups.any { it.type == C.TRACK_TYPE_AUDIO }
        if (hasVideo && !hasAudio) {
            delay(600)
            switchStreamFormat(auto = true)
        }
    }

    /** Exécute une action, quelle que soit la touche qui l'a déclenchée. */
    /**
     * @param showControls faux pour un raccourci : on veut le message seul,
     * pas la barre de lecture complète par-dessus l'image.
     */
    fun runAction(action: PlayerAction, showControls: Boolean = true) {
        when (action) {
            PlayerAction.PLAY_PAUSE -> if (player.isPlaying) player.pause() else player.play()
            PlayerAction.SEEK_FORWARD -> player.seekTo(player.currentPosition + 10_000)
            PlayerAction.SEEK_BACK ->
                player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
            PlayerAction.BOOST_LOCK -> {
                baseSpeed = if (baseSpeed == 1f) boostSpeed else 1f
                toast = if (baseSpeed == 1f) tr("Vitesse normale")
                else "Vitesse ${fmtSpeed(baseSpeed)}× verrouillée"
            }
            PlayerAction.AUDIO_TOGGLE -> cycleAudio()
            PlayerAction.SUBS_TOGGLE ->
                applySubtitles(!subsOn, settings.subtitleLang, announce = true)
            PlayerAction.SPEED_UP -> {
                baseSpeed = (baseSpeed + SPEED_STEP).coerceAtMost(SPEED_MAX)
                toast = "${fmtSpeed(baseSpeed)}×"
            }
            PlayerAction.SPEED_DOWN -> {
                baseSpeed = (baseSpeed - SPEED_STEP).coerceAtLeast(SPEED_MIN)
                toast = "${fmtSpeed(baseSpeed)}×"
            }
            PlayerAction.OPTIONS -> panelOpen = true
            PlayerAction.ASPECT -> {
                resizeMode =
                    if (resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT)
                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else AspectRatioFrameLayout.RESIZE_MODE_FIT
                toast = if (resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT)
                    tr("Image ajustée") else tr("Image remplie")
            }
            PlayerAction.BOOST_HOLD -> Unit
            PlayerAction.EXIT -> vm.back()
        }
        if (showControls) touch()
    }

    // ------------------------------------ bouton dédié de la télécommande
    // (bouton Netflix de la Shield remappé sur « lancer GeekoIPTV »)
    var lastPulse by remember { mutableIntStateOf(ShortcutBus.pulse) }
    LaunchedEffect(ShortcutBus.pulse) {
        if (ShortcutBus.pulse == lastPulse) return@LaunchedEffect
        lastPulse = ShortcutBus.pulse
        PlayerAction.from(settings.shortcutAction)?.let { runAction(it, showControls = false) }
    }


    // -------------------------------------------------------- télécommande
    val rootFocus = remember { FocusRequester() }
    var lastRewind by remember { mutableLongStateOf(0L) }

    LaunchedEffect(isTv, panelOpen) {
        if (isTv && !panelOpen) runCatching { rootFocus.requestFocus() }
    }

    fun handleKey(event: KeyEvent): Boolean {
        // Panneau ouvert : on laisse la navigation au focus, sauf le retour.
        if (panelOpen) {
            if (event.type == KeyEventType.KeyUp &&
                (event.key == Key.Back || event.key == Key.Escape)
            ) {
                panelOpen = false
                return true
            }
            return false
        }

        val down = event.type == KeyEventType.KeyDown
        val up = event.type == KeyEventType.KeyUp
        val repeat = event.nativeKeyEvent.repeatCount

        // Touche remappée par l'utilisateur : elle a la priorité.
        vm.keyAction(event.nativeKeyEvent.keyCode)?.let { custom ->
            if (custom == PlayerAction.BOOST_HOLD) {
                if (down && !boosting) {
                    boosting = true
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    touch()
                } else if (up) {
                    boosting = false
                }
            } else if (up) {
                runAction(custom)
            }
            return true
        }

        return when (event.key) {

            // maintien = accélération, appui bref = +10 s
            Key.DirectionRight, Key.MediaFastForward -> {
                if (controlsVisible && event.key == Key.DirectionRight && repeat == 0 && !boosting) {
                    // Barre visible : l'appui bref sert à déplacer le focus.
                    false
                } else {
                    if (down) {
                        if (repeat > 0 && !boosting) {
                            boosting = true
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            touch()
                        }
                    } else if (up) {
                        if (boosting) boosting = false
                        else if (!controlsVisible || event.key == Key.MediaFastForward) {
                            player.seekTo(player.currentPosition + 10_000); touch()
                        }
                    }
                    true
                }
            }

            // maintien = recul rapide, appui bref = -10 s
            Key.DirectionLeft, Key.MediaRewind -> {
                if (controlsVisible && event.key == Key.DirectionLeft && repeat == 0) {
                    false
                } else {
                    if (down && repeat > 0) {
                        val now = System.currentTimeMillis()
                        if (now - lastRewind > 220) {
                            lastRewind = now
                            player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                            touch()
                        }
                    } else if (up && !controlsVisible && System.currentTimeMillis() - lastRewind > 400) {
                        player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                        touch()
                    }
                    true
                }
            }

            Key.DirectionCenter, Key.Enter, Key.MediaPlayPause, Key.Spacebar -> {
                if (controlsVisible && (event.key == Key.DirectionCenter || event.key == Key.Enter)) {
                    false
                } else {
                    if (up) {
                        if (player.isPlaying) player.pause() else player.play()
                        touch()
                    }
                    true
                }
            }

            Key.MediaPlay -> { if (up) { player.play(); touch() }; true }
            Key.MediaPause -> { if (up) { player.pause(); touch() }; true }

            // une seule touche pour changer de langue
            Key.DirectionUp, Key.ChannelUp -> {
                if (controlsVisible && event.key == Key.DirectionUp) false
                else {
                    if (up) { cycleAudio(); touch() }
                    true
                }
            }

            // une seule touche pour les sous-titres
            Key.DirectionDown, Key.ChannelDown, Key.Captions -> {
                if (controlsVisible && event.key == Key.DirectionDown) false
                else {
                    if (up) { applySubtitles(!subsOn, settings.subtitleLang, announce = true); touch() }
                    true
                }
            }

            Key.Menu, Key.Info, Key.Settings -> {
                if (up) { panelOpen = true; touch() }
                true
            }

            Key.MediaStop -> { if (up) vm.back(); true }

            else -> false
        }
    }

    // ----------------------------------------------------------- affichage
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .then(
                if (isTv) Modifier
                    .focusRequester(rootFocus)
                    .focusable()
                    .onPreviewKeyEvent { handleKey(it) }
                else Modifier
            )
    ) {

        AndroidView(
            factory = { ctx ->
                val view = android.view.LayoutInflater.from(ctx)
                    .inflate(fr.geeko.iptv.R.layout.player_view, null) as PlayerView
                view.setPlayer(player)
                view.setKeepContentOnPlayerReset(true)
                view.isFocusable = false
                view.isFocusableInTouchMode = false
                playerView = view
                view
            },
            update = { it.resizeMode = resizeMode },
            modifier = Modifier.fillMaxSize()
        )

        if (PipState.inPip) return@Box

        if (!isTv) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { if (controlsVisible) controlsVisible = false else touch() },
                            onDoubleTap = { offset ->
                                val forward = offset.x > size.width / 2
                                player.seekTo(
                                    (player.currentPosition + if (forward) 10_000 else -10_000)
                                        .coerceAtLeast(0)
                                )
                                touch()
                            }
                        )
                    }
            )
        }

        if (buffering) {
            CircularProgressIndicator(color = Accent, modifier = Modifier.align(Alignment.Center))
        }

        AnimatedVisibility(
            visible = boosting,
            enter = fadeIn(), exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp)
        ) {
            Surface(color = Accent, shape = RoundedCornerShape(24.dp)) {
                Row(
                    Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.FastForward, contentDescription = null,
                        tint = Color.Black, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("${fmtSpeed(boostSpeed)}×", color = Color.Black,
                        fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
        }

        AnimatedVisibility(
            visible = toast != null && !boosting,
            enter = fadeIn(), exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 32.dp)
        ) {
            Surface(color = Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(24.dp)) {
                Text(
                    toast.orEmpty(),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                )
            }
        }

        // bouton tactile maintenu : téléphone et tablette uniquement,
        // il disparaît avec les contrôles
        if (!isTv) {
            AnimatedVisibility(
                visible = controlsVisible || boosting,
                enter = fadeIn(), exit = fadeOut(),
                modifier = Modifier.align(Alignment.CenterEnd)
            ) {
            BoostButton(
                speed = boostSpeed,
                boosting = boosting,
                onPressStart = {
                    boosting = true
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                },
                onPressEnd = { boosting = false },
                onCycleSpeed = {
                    val idx = BOOST_CHOICES.indexOfFirst { it == boostSpeed }
                    boostSpeed = BOOST_CHOICES[(idx + 1).coerceAtLeast(0) % BOOST_CHOICES.size]
                    vm.updateSettings(settings.copy(boostSpeed = boostSpeed))
                },
                modifier = Modifier.padding(end = 28.dp)
            )
            }
        }

        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(), exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f))) {

                Row(
                    Modifier.fillMaxWidth().padding(if (isTv) 36.dp else 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isTv) {
                        IconButton(onClick = { vm.back() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"),
                                tint = Color.White)
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            request.title, color = Color.White,
                            fontSize = if (isTv) 22.sp else 15.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 1
                        )
                        request.subtitle?.let {
                            Text(it, color = Color.White.copy(alpha = 0.75f),
                                fontSize = if (isTv) 15.sp else 12.sp, maxLines = 1)
                        }
                    }
                    if (canCast) {
                        CastButton()
                        Spacer(Modifier.width(4.dp))
                    }
                    if (pipAvailable) {
                        IconButton(onClick = { activity?.let { enterPip(it) } }) {
                            Icon(
                                Icons.Default.PictureInPictureAlt,
                                contentDescription = tr("Fenêtre flottante"),
                                tint = Color.White
                            )
                        }
                    }
                    if (!isTv) {
                        IconButton(onClick = {
                            resizeMode =
                                if (resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT)
                                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                else AspectRatioFrameLayout.RESIZE_MODE_FIT
                            touch()
                        }) {
                            Icon(Icons.Default.AspectRatio, contentDescription = tr("Format"),
                                tint = Color.White)
                        }
                    }
                }

                if (!isTv) {
                    Row(
                        Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(28.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0)); touch()
                        }) {
                            Icon(Icons.Default.Replay10, contentDescription = "-10 s",
                                tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                        IconButton(onClick = {
                            if (player.isPlaying) player.pause() else player.play(); touch()
                        }) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = tr("Lecture"), tint = Color.White,
                                modifier = Modifier.size(56.dp)
                            )
                        }
                        IconButton(onClick = {
                            player.seekTo(player.currentPosition + 10_000); touch()
                        }) {
                            Icon(Icons.Default.Forward10, contentDescription = "+10 s",
                                tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                    }
                }

                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = if (isTv) 44.dp else 16.dp)
                        .padding(bottom = if (isTv) 36.dp else 10.dp)
                ) {
                    if (!request.isLive && duration > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(formatTime(position), color = Color.White,
                                fontSize = if (isTv) 15.sp else 12.sp)
                            if (isTv) {
                                Column(
                                    Modifier
                                        .weight(1f)
                                        .padding(horizontal = 14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    if (tvSeekFocused) {
                                        Surface(
                                            color = Color.Black.copy(alpha = 0.72f),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                formatTime(tvSeekPosition.coerceIn(0L, duration)),
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                            )
                                        }
                                        Spacer(Modifier.height(4.dp))
                                    }

                                    Box(
                                        Modifier
                                            .fillMaxWidth()
                                            .height(if (tvSeekFocused) 18.dp else 12.dp)
                                            .clip(RoundedCornerShape(9.dp))
                                            .background(Color.White.copy(alpha = 0.14f))
                                            .border(
                                                if (tvSeekFocused) 2.dp else 0.dp,
                                                if (tvSeekFocused) Accent else Color.Transparent,
                                                RoundedCornerShape(9.dp)
                                            )
                                            .onFocusChanged {
                                                tvSeekFocused = it.isFocused
                                                if (it.isFocused) {
                                                    tvSeekPosition = position.coerceIn(0L, duration)
                                                    touch()
                                                }
                                            }
                                            .focusable()
                                            .onPreviewKeyEvent { event ->
                                                val left = event.key == Key.DirectionLeft
                                                val right = event.key == Key.DirectionRight
                                                val center = event.key == Key.DirectionCenter || event.key == Key.Enter
                                                if (!(left || right || center)) return@onPreviewKeyEvent false

                                                if (center && event.type == KeyEventType.KeyUp) {
                                                    player.seekTo(tvSeekPosition.coerceIn(0L, duration))
                                                    position = tvSeekPosition.coerceIn(0L, duration)
                                                    touch()
                                                    return@onPreviewKeyEvent true
                                                }

                                                if ((left || right) && event.type == KeyEventType.KeyDown) {
                                                    val nowMs = android.os.SystemClock.uptimeMillis()
                                                    val repeat = event.nativeKeyEvent.repeatCount
                                                    // Appui court = 10 s. Maintenu = pas de plus en plus grands,
                                                    // jusqu'à 2 min par répétition pour traverser rapidement un film.
                                                    val step = when {
                                                        repeat >= 18 -> 120_000L
                                                        repeat >= 10 -> 60_000L
                                                        repeat >= 5 -> 30_000L
                                                        repeat >= 2 -> 15_000L
                                                        else -> 10_000L
                                                    }
                                                    if (repeat == 0 || nowMs - tvSeekLastStepAt >= 70L) {
                                                        tvSeekLastStepAt = nowMs
                                                        val delta = if (right) step else -step
                                                        tvSeekPosition = (tvSeekPosition + delta).coerceIn(0L, duration)
                                                        touch()
                                                    }
                                                    return@onPreviewKeyEvent true
                                                }

                                                if ((left || right) && event.type == KeyEventType.KeyUp) {
                                                    return@onPreviewKeyEvent true
                                                }
                                                false
                                            }
                                    ) {
                                        val frac = (tvSeekPosition.toFloat() / duration).coerceIn(0f, 1f)
                                        Box(
                                            Modifier
                                                .fillMaxHeight()
                                                .fillMaxWidth(frac)
                                                .background(Accent)
                                        )
                                        Box(
                                            Modifier
                                                .align(Alignment.CenterStart)
                                                .offset(x = ((frac * 520f) - 6f).coerceAtLeast(0f).dp)
                                                .size(if (tvSeekFocused) 12.dp else 8.dp)
                                                .clip(androidx.compose.foundation.shape.CircleShape)
                                                .background(Color.White)
                                        )
                                    }
                                }
                            } else {
                                Slider(
                                    value = position.coerceIn(0, duration).toFloat(),
                                    onValueChange = { position = it.toLong(); touch() },
                                    onValueChangeFinished = { player.seekTo(position) },
                                    valueRange = 0f..duration.toFloat(),
                                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                                )
                            }
                            Text(formatTime(duration), color = Color.White,
                                fontSize = if (isTv) 15.sp else 12.sp)
                        }
                    } else if (request.isLive) {
                        Text(tr("● EN DIRECT"), color = Accent,
                            fontSize = if (isTv) 15.sp else 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(Modifier.height(10.dp))

                    if (isTv) {
                        TvStatusRow(
                            speed = baseSpeed,
                            boostSpeed = boostSpeed,
                            audio = activeAudioName,
                            subsOn = subsOn,
                            playing = isPlaying,
                            onPlayPause = {
                                if (player.isPlaying) player.pause() else player.play()
                                touch()
                            },
                            onAudio = { cycleAudio(); touch() },
                            onSubs = { applySubtitles(!subsOn, settings.subtitleLang, announce = true); touch() },
                            onOptions = { panelOpen = true; touch() }
                        )
                    } else {
                        TouchControlRow(
                            audioButtons = listOf(slotA, slotB)
                                .mapIndexedNotNull { slot, trackIndex ->
                                    val entry = audioTracks.getOrNull(trackIndex)
                                        ?: return@mapIndexedNotNull null
                                    val (g, i) = entry
                                    AudioButton(
                                        label = shortTrackLabel(g.getTrackFormat(i), i),
                                        selected = g.isTrackSelected(i),
                                        onSelect = { selectAudioTrack(g, i); touch() },
                                        onReassign = { assigning = slot; touch() }
                                    )
                                },
                            baseSpeed = baseSpeed,
                            onSpeedDown = {
                                baseSpeed = (baseSpeed - SPEED_STEP).coerceAtLeast(SPEED_MIN); touch()
                            },
                            onSpeedUp = {
                                baseSpeed = (baseSpeed + SPEED_STEP).coerceAtMost(SPEED_MAX); touch()
                            },
                            onSpeedReset = { baseSpeed = 1f; touch() },
                            onAudioMenu = { showAudioMenu = true; touch() },
                            subsOn = subsOn,
                            onSubsToggle = { applySubtitles(!subsOn, settings.subtitleLang); touch() },
                            onSubMenu = { showSubMenu = true; touch() }
                        )
                    }
                }
            }
        }

        if (isTv) {
            TvOptionsPanel(
                open = panelOpen,
                baseSpeed = baseSpeed,
                boostSpeed = boostSpeed,
                subsOn = subsOn,
                resizeMode = resizeMode,
                audioTracks = audioTracks,
                textTracks = textTracks,
                onSpeed = { baseSpeed = it.coerceIn(SPEED_MIN, SPEED_MAX) },
                onBoost = {
                    boostSpeed = it
                    vm.updateSettings(settings.copy(boostSpeed = it))
                },
                onPickAudio = { g, i ->
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                        .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                        .build()
                    val f = g.getTrackFormat(i)
                    activeAudioKey = trackLangKey(f.language, f.label)
                },
                onPickText = { g, i ->
                    if (g == null) applySubtitles(false)
                    else {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .build()
                        subsOn = true
                    }
                },
                onResize = { resizeMode = it },
                isLive = request.isLive,
                hlsActive = currentUrl.endsWith("m3u8", true),
                onSwitchFormat = { switchStreamFormat(auto = false) },
                onClose = { panelOpen = false },
                modifier = Modifier.align(Alignment.CenterEnd)
            )
        }

        playbackError?.let {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)
            ) {
                Text("Lecture impossible ($it)", Modifier.padding(12.dp), fontSize = 13.sp)
            }
        }
    }

    assigning?.let { slot ->
        TrackDialog(
            title = tr("Choisir la voix"),
            entries = audioTracks.mapIndexed { index, (g, i) ->
                Triple<String, Boolean, () -> Unit>(
                    trackLabel(g.getTrackFormat(i), i),
                    index == (if (slot == 0) slotA else slotB)
                ) {
                    if (slot == 0) slotA = index else slotB = index
                    selectAudioTrack(g, i)
                    val f = g.getTrackFormat(i)
                    activeAudioKey = trackLangKey(f.language, f.label)
                }
            },
            onDismiss = { assigning = null }
        )
    }

    if (showAudioMenu) {
        TrackDialog(
            title = tr("Piste audio"),
            entries = audioTracks.map { (g, i) ->
                val f = g.getTrackFormat(i)
                val label = trackLabel(f, i)
                Triple<String, Boolean, () -> Unit>(label, g.isTrackSelected(i)) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                        .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                        .build()
                    activeAudioKey = trackLangKey(f.language, f.label)
                }
            },
            onDismiss = { showAudioMenu = false }
        )
    }

    if (showSubMenu) {
        TrackDialog(
            title = tr("Sous-titres"),
            entries = listOf(
                Triple<String, Boolean, () -> Unit>(tr("Désactivés"), !subsOn) { applySubtitles(false) }
            ) + textTracks.map { (g, i) ->
                val f = g.getTrackFormat(i)
                val label = trackLabel(f, i)
                Triple<String, Boolean, () -> Unit>(label, subsOn && g.isTrackSelected(i)) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .build()
                    subsOn = true
                }
            },
            onDismiss = { showSubMenu = false }
        )
    }
}

// ------------------------------------------------------------------- TV

@Composable
private fun TvStatusRow(
    speed: Float,
    boostSpeed: Float,
    audio: String,
    subsOn: Boolean,
    playing: Boolean,
    onPlayPause: () -> Unit,
    onAudio: () -> Unit,
    onSubs: () -> Unit,
    onOptions: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatusChip(if (playing) tr("Pause") else tr("Lecture"), onClick = onPlayPause)
        StatusChip("${fmtSpeed(speed)}×", highlighted = speed != 1f, onClick = onOptions)
        StatusChip("Audio $audio", onClick = onAudio)
        StatusChip(
            if (subsOn) tr("ST activés") else tr("ST désactivés"),
            highlighted = subsOn,
            onClick = onSubs
        )
        StatusChip("Options", onClick = onOptions)

        Spacer(Modifier.weight(1f))

        Text(
            "Maintiens → : ${fmtSpeed(boostSpeed)}×   ·   Maintiens ← : rembobiner",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 12.sp
        )
    }
}

@Composable
private fun StatusChip(
    text: String,
    highlighted: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val shape = RoundedCornerShape(12.dp)
    Surface(
        color = if (highlighted) Accent else Color.White.copy(alpha = 0.16f),
        shape = shape,
        modifier = if (onClick != null) {
            Modifier
                .tvFocus(shape, 1.06f)
                .clickable(onClick = onClick)
        } else Modifier
    ) {
        Text(
            text,
            color = if (highlighted) Color.Black else Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun TvOptionsPanel(
    open: Boolean,
    baseSpeed: Float,
    boostSpeed: Float,
    subsOn: Boolean,
    resizeMode: Int,
    audioTracks: List<Pair<Tracks.Group, Int>>,
    textTracks: List<Pair<Tracks.Group, Int>>,
    onSpeed: (Float) -> Unit,
    onBoost: (Float) -> Unit,
    onPickAudio: (Tracks.Group, Int) -> Unit,
    onPickText: (Tracks.Group?, Int) -> Unit,
    onResize: (Int) -> Unit,
    isLive: Boolean,
    hlsActive: Boolean,
    onSwitchFormat: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(open) { if (open) runCatching { first.requestFocus() } }

    AnimatedVisibility(
        visible = open,
        enter = slideInHorizontally { it } + fadeIn(),
        exit = slideOutHorizontally { it } + fadeOut(),
        modifier = modifier
    ) {
        Column(
            Modifier
                .fillMaxHeight()
                .width(420.dp)
                .background(Surface1.copy(alpha = 0.97f))
                .verticalScroll(rememberScrollState())
                .padding(28.dp)
        ) {
            Text(tr("Options"), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(20.dp))

            PanelLabel(tr("Vitesse de lecture"))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PanelButton("−", Modifier.focusRequester(first)) { onSpeed(baseSpeed - SPEED_STEP) }
                PanelButton("${fmtSpeed(baseSpeed)}×", selected = baseSpeed != 1f) { onSpeed(1f) }
                PanelButton("+") { onSpeed(baseSpeed + SPEED_STEP) }
            }

            Spacer(Modifier.height(22.dp))
            PanelLabel(tr("Vitesse quand on maintient la flèche droite"))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BOOST_CHOICES.forEach { b ->
                    PanelButton("${fmtSpeed(b)}×", selected = b == boostSpeed) { onBoost(b) }
                }
            }

            Spacer(Modifier.height(22.dp))
            PanelLabel(tr("Piste audio"))
            if (audioTracks.isEmpty()) {
                Text(tr("Aucune piste détectée"), color = TextLow, fontSize = 14.sp)
            } else {
                audioTracks.forEach { (g, i) ->
                    val f = g.getTrackFormat(i)
                    val label = trackLabel(f, i)
                    PanelRow(label, g.isTrackSelected(i)) { onPickAudio(g, i) }
                }
            }

            Spacer(Modifier.height(22.dp))
            PanelLabel(tr("Sous-titres"))
            PanelRow(tr("Désactivés"), !subsOn) { onPickText(null, 0) }
            textTracks.forEach { (g, i) ->
                val f = g.getTrackFormat(i)
                val label = trackLabel(f, i)
                PanelRow(label, subsOn && g.isTrackSelected(i)) { onPickText(g, i) }
            }

            Spacer(Modifier.height(22.dp))
            PanelLabel(tr("Format de l'image"))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PanelButton(
                    tr("Ajusté"),
                    selected = resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT
                ) { onResize(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
                PanelButton(
                    tr("Rempli"),
                    selected = resizeMode == AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                ) { onResize(AspectRatioFrameLayout.RESIZE_MODE_ZOOM) }
            }

            if (isLive) {
                Spacer(Modifier.height(22.dp))
                PanelLabel(tr("Format du flux"))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PanelButton("TS", selected = !hlsActive) { if (hlsActive) onSwitchFormat() }
                    PanelButton("HLS", selected = hlsActive) { if (!hlsActive) onSwitchFormat() }
                }
                Text(
                    tr("À essayer si une chaîne n'a pas de son."),
                    color = TextLow, fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Spacer(Modifier.height(28.dp))
            PanelButton(tr("Fermer")) { onClose() }
            Spacer(Modifier.height(8.dp))
            Text(tr("Le bouton Retour ferme aussi ce panneau"), color = TextLow, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PanelLabel(text: String) {
    Text(
        text.uppercase(),
        color = Accent,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        modifier = Modifier.padding(bottom = 10.dp)
    )
}

@Composable
private fun PanelButton(
    text: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) Accent else Color.White.copy(alpha = 0.14f),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .tvFocus(RoundedCornerShape(14.dp), scale = 1.06f)
            .clickable(onClick = onClick)
    ) {
        Text(
            text,
            color = if (selected) Color.Black else Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
        )
    }
}

@Composable
private fun PanelRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) Accent.copy(alpha = 0.22f) else Color.Transparent,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .tvFocus(RoundedCornerShape(12.dp), scale = 1.02f)
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (selected) Icons.Default.RadioButtonChecked
                else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (selected) Accent else TextLow,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text(text, color = Color.White, fontSize = 15.sp)
        }
    }
}

// --------------------------------------------------------------- tactile

/** Un emplacement de voix dans la barre du lecteur. */
private data class AudioButton(
    val label: String,
    val selected: Boolean,
    val onSelect: () -> Unit,
    val onReassign: () -> Unit
)

@Composable
private fun TouchControlRow(
    audioButtons: List<AudioButton>,
    baseSpeed: Float,
    onSpeedDown: () -> Unit,
    onSpeedUp: () -> Unit,
    onSpeedReset: () -> Unit,
    onAudioMenu: () -> Unit,
    subsOn: Boolean,
    onSubsToggle: () -> Unit,
    onSubMenu: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SmallPill("−", onClick = onSpeedDown)
        SmallPill("${fmtSpeed(baseSpeed)}×", highlighted = baseSpeed != 1f, wide = true,
            onClick = onSpeedReset)
        SmallPill("+", onClick = onSpeedUp)

        Spacer(Modifier.weight(1f))

        // Deux emplacements de voix : tap pour basculer,
        // appui long pour y mettre une autre langue.
        audioButtons.forEach { button ->
            SmallPill(
                button.label,
                highlighted = button.selected,
                wide = true,
                onClick = button.onSelect,
                onLongClick = button.onReassign
            )
        }
        if (audioButtons.isEmpty()) {
            SmallPill(tr("Audio"), wide = true, onClick = onAudioMenu)
        }
        IconButton(onClick = onAudioMenu) {
            Icon(Icons.Default.Headphones, contentDescription = tr("Pistes audio"), tint = Color.White)
        }

        SmallPill(if (subsOn) tr("ST ON") else tr("ST OFF"), highlighted = subsOn, wide = true,
            onClick = onSubsToggle)
        IconButton(onClick = onSubMenu) {
            Icon(Icons.Default.Subtitles, contentDescription = tr("Sous-titres"), tint = Color.White)
        }
    }
}

@Composable
private fun BoostButton(
    speed: Float,
    boosting: Boolean,
    onPressStart: () -> Unit,
    onPressEnd: () -> Unit,
    onCycleSpeed: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(44.dp))
                .background(if (boosting) Accent else Color.Black.copy(alpha = 0.55f))
                .border(
                    width = 2.dp,
                    color = if (boosting) Accent else Accent.copy(alpha = 0.75f),
                    shape = RoundedCornerShape(44.dp)
                )
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            onPressStart()
                            tryAwaitRelease()
                            onPressEnd()
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.FastForward,
                    contentDescription = tr("Maintenir pour accélérer"),
                    tint = if (boosting) Color.Black else Color.White,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    "${fmtSpeed(speed)}×",
                    color = if (boosting) Color.Black else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(Modifier.height(7.dp))
        Surface(
            color = Color.Black.copy(alpha = 0.55f),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(
                tr("maintenir"),
                color = Color.White,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            tr("changer"),
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 11.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onCycleSpeed)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun SmallPill(
    text: String,
    highlighted: Boolean = false,
    wide: Boolean = false,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    Surface(
        color = if (highlighted) Accent else Color.White.copy(alpha = 0.15f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.combinedClickable(
            onClick = onClick,
            onLongClick = onLongClick ?: {}
        )
    ) {
        Text(
            text,
            color = if (highlighted) Color.Black else Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = if (wide) 12.dp else 10.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun TrackDialog(
    title: String,
    entries: List<Triple<String, Boolean, () -> Unit>>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                if (entries.isEmpty()) Text(tr("Aucune piste disponible sur ce flux."), fontSize = 14.sp)
                entries.forEach { (label, selected, action) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { action(); onDismiss() }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected, onClick = { action(); onDismiss() })
                        Spacer(Modifier.width(8.dp))
                        Text(label, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Fermer")) } }
    )
}
