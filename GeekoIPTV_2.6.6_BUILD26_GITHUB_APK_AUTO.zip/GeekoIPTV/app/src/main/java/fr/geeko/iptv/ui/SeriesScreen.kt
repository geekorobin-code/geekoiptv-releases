package fr.geeko.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.focusProperties
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.ui.theme.*
import fr.geeko.iptv.ui.i18n.tr

@Composable
fun SeriesScreen(vm: AppViewModel, series: StreamItem) {
    val info = vm.seriesInfo
    val isTv = LocalIsTv.current
    var actionHint by remember { mutableStateOf<String?>(null) }
    var season by remember(info) { mutableIntStateOf(info?.seasons?.firstOrNull() ?: 1) }
    val playFocus = remember { FocusRequester() }

    Box(Modifier.fillMaxSize().appBackground()) {

        if (vm.seriesLoading || info == null) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Accent) }
        } else {
            val next = vm.nextEpisodeFor(series.id, info)
            // Un téléviseur fait environ 540 dp de haut : à 300 dp, le bandeau et
            // les boutons remplissaient tout l'écran et les épisodes tombaient
            // hors champ, sans rien pour indiquer qu'il fallait descendre.
            val heroHeight = if (isTv) 190.dp else 220.dp

            // sur téléviseur, on donne la main au bouton de lecture dès l'ouverture
            LaunchedEffect(info, isTv) {
                if (isTv && next != null) {
                    kotlinx.coroutines.delay(120)
                    runCatching { playFocus.requestFocus() }
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(bottom = 32.dp),
                modifier = Modifier.focusGroup()
            ) {

                // ---------------------------------------------- couverture
                item {
                    Box(Modifier.fillMaxWidth().height(heroHeight)) {
                        val hero = info.backdrop ?: info.cover ?: series.icon
                        if (!hero.isNullOrBlank()) {
                            AsyncImage(
                                model = hero,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(Modifier.fillMaxSize().background(Surface2))
                        }
                        // dégradé pour que le texte reste lisible
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        0f to Ink.copy(alpha = 0.55f),
                                        0.45f to Ink.copy(alpha = 0.25f),
                                        1f to Ink
                                    )
                                )
                        )
                    }
                }

                // ------------------------------------------------- entête
                item {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                    ) {
                        Poster(
                            info.cover ?: series.icon,
                            series.name,
                            Modifier.width(if (isTv) 132.dp else 108.dp)
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.padding(top = 64.dp)) {
                            Text(
                                series.name,
                                fontSize = if (isTv) 24.sp else 20.sp,
                                fontWeight = FontWeight.Bold,
                                lineHeight = 27.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(6.dp))
                            val (done, total) = vm.seriesProgress(series.id)
                            if (total > 0 && done >= total) {
                                Row(
                                    Modifier
                                        .padding(bottom = 6.dp)
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(Gold)
                                        .padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = Color(0xFF3A2A00),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(Modifier.width(5.dp))
                                    Text(
                                        tr("Série terminée"),
                                        color = Color(0xFF3A2A00),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else if (done > 0) {
                                Text(
                                    "$done / $total épisodes vus",
                                    color = Mint, fontSize = 12.sp,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                            }
                            Text(
                                listOfNotNull(
                                    info.releaseDate?.take(4),
                                    info.genre,
                                    "${info.seasons.size} saison(s)",
                                    "${info.episodes.size} épisodes"
                                ).joinToString(" · "),
                                color = TextMid,
                                fontSize = 13.sp,
                                maxLines = 2
                            )
                            Spacer(Modifier.height(8.dp))
                            Box(Modifier.height(18.dp), contentAlignment = Alignment.CenterStart) {
                                actionHint?.let {
                                    Text(it, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                next?.let { ep ->
                                    Button(
                                        onClick = { vm.playEpisode(series, ep) },
                                        shape = RoundedCornerShape(24.dp),
                                        modifier = Modifier
                                            .focusRequester(playFocus)
                                            .onFocusChanged { if (it.isFocused) actionHint = "Lire le prochain épisode" }
                                            .tvFocus(RoundedCornerShape(24.dp), 1.04f)
                                    ) {
                                        Icon(
                                            Icons.Default.PlayArrow, contentDescription = null,
                                            modifier = Modifier.size(19.dp)
                                        )
                                        Spacer(Modifier.width(7.dp))
                                        Text("S${ep.season} E${ep.number}", fontSize = 14.sp)
                                    }
                                }
                                Spacer(Modifier.width(10.dp))
                                val marked = vm.inWatchlist(series.key)
                                OutlinedButton(
                                    onClick = { vm.toggleWatchlist(series) },
                                    shape = RoundedCornerShape(24.dp),
                                    modifier = Modifier
                                        .onFocusChanged { if (it.isFocused) actionHint = "À regarder plus tard" }
                                        .tvFocus(RoundedCornerShape(24.dp), 1.04f)
                                ) {
                                    Icon(
                                        if (marked) Icons.Default.Bookmark
                                        else Icons.Default.BookmarkBorder,
                                        contentDescription = null,
                                        tint = if (marked) Accent else TextMid,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                info.plot?.takeIf { it.isNotBlank() }?.let { plot ->
                    item {
                        Text(
                            plot,
                            color = TextMid,
                            fontSize = 13.sp,
                            lineHeight = 19.sp,
                            maxLines = 4,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .padding(horizontal = 20.dp)
                        )
                    }
                }

                listOfNotNull(
                    info.cast?.takeIf { it.isNotBlank() }?.let { "Avec $it" },
                    info.director?.takeIf { it.isNotBlank() }?.let { "Réalisé par $it" }
                ).forEach { line ->
                    item {
                        Text(
                            line,
                            color = TextLow,
                            fontSize = 12.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .padding(horizontal = 20.dp, vertical = 2.dp)
                        )
                    }
                }

                // ------------------------------------------------ saisons
                item {
                    Row(
                        Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        info.seasons.forEach { s ->
                            FilterChip(
                                selected = s == season,
                                onClick = { season = s },
                                shape = RoundedCornerShape(20.dp),
                                label = { Text("Saison $s") },
                                modifier = Modifier.tvFocus(RoundedCornerShape(20.dp), 1.05f)
                            )
                        }
                    }
                }

                // ----------------------------------------------- épisodes
                items(info.episodes.filter { it.season == season }, key = { it.id }) { ep ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 5.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Surface1)
                            .tvFocus(RoundedCornerShape(16.dp), scale = 1.02f)
                            .clickable { vm.playEpisode(series, ep) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box {
                            Poster(
                                ep.cover ?: info.backdrop ?: series.icon,
                                ep.title,
                                Modifier.width(if (isTv) 132.dp else 104.dp),
                                ratio = 16f / 9f,
                                corner = 12
                            )
                            if (vm.isEpisodeWatched(series.id, ep.id)) {
                                Box(
                                    Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(5.dp)
                                        .size(20.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Mint),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = tr("Vu"),
                                        tint = Color(0xFF04231A),
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "E${ep.number} · ${ep.title}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                lineHeight = 18.sp
                            )
                            if (ep.durationSecs > 0) {
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    "${ep.durationSecs / 60} min",
                                    color = TextLow, fontSize = 12.sp
                                )
                            }
                            ep.plot?.takeIf { it.isNotBlank() }?.let {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    it, color = TextLow, fontSize = 11.sp,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                        Spacer(Modifier.width(8.dp))

                        run {
                            DownloadButton(vm, "SERIES:${ep.id}", size = 38) {
                                vm.downloadEpisode(series, ep)
                            }
                            Spacer(Modifier.width(6.dp))
                        }

                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Accent.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.PlayArrow, contentDescription = null,
                                tint = Accent, modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }
        }

        // bouton retour flottant, par-dessus la couverture
        Box(
            Modifier
                .statusBarsPadding()
                .padding(10.dp)
                .size(42.dp)
                .clip(RoundedCornerShape(21.dp))
                .background(Color.Black.copy(alpha = 0.45f))
                // Sur téléviseur, le focus montait dessus et ne redescendait
                // plus : on l'écarte du parcours, la touche Retour suffit.
                .then(if (isTv) Modifier.focusProperties { canFocus = false } else Modifier)
                .tvFocus(RoundedCornerShape(21.dp), scale = 1.06f)
                .clickable { vm.back() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"), tint = Color.White)
        }
    }
}
