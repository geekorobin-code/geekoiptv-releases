package fr.geeko.iptv

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import fr.geeko.iptv.data.DownloadCenter
import fr.geeko.iptv.data.DownloadItem
import fr.geeko.iptv.data.DownloadState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Télécharge les épisodes et films un par un, en avant-plan pour qu'Android
 * ne coupe pas le transfert quand l'utilisateur quitte l'application.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var worker: Job? = null

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val CHANNEL = "downloads"
        private const val NOTIF_ID = 4242

        fun start(context: Context) {
            val intent = Intent(context, DownloadService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        DownloadCenter.load(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification(getString(R.string.app_name), 0, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
        if (worker?.isActive != true) worker = scope.launch { drain() }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------- traitement

    private suspend fun drain() {
        while (scope.isActive) {
            val next = DownloadCenter.nextPending() ?: break
            runCatching { download(next) }
                .onFailure {
                    DownloadCenter.update(this, next.key) {
                        it.copy(state = DownloadState.FAILED)
                    }
                }
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun download(item: DownloadItem) {
        val target = DownloadCenter.fileFor(this, item)
        val existing = if (target.exists()) target.length() else 0L

        DownloadCenter.update(this, item.key) {
            it.copy(state = DownloadState.RUNNING, downloaded = existing)
        }

        val request = Request.Builder()
            .url(item.url)
            .header("User-Agent", "GeekoIPTV/1.0 (Android)")
            .apply { if (existing > 0) header("Range", "bytes=$existing-") }
            .build()

        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw RuntimeException("HTTP ${response.code}")
            val body = response.body ?: throw RuntimeException("Corps vide")

            val resuming = response.code == 206
            val length = body.contentLength()
            val total = if (length > 0) (if (resuming) existing + length else length) else 0L

            DownloadCenter.update(this, item.key) { it.copy(total = total) }

            var written = if (resuming) existing else 0L
            if (!resuming && target.exists()) target.delete()

            body.byteStream().use { input ->
                java.io.FileOutputStream(target, resuming).use { output ->
                    val buffer = ByteArray(256 * 1024)
                    var lastNotify = 0L
                    while (scope.isActive) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        written += read

                        val now = System.currentTimeMillis()
                        if (now - lastNotify > 700) {
                            lastNotify = now
                            val done = written
                            DownloadCenter.update(this, item.key) { it.copy(downloaded = done) }
                            val percent =
                                if (total > 0) ((done * 100) / total).toInt() else 0
                            notify(item.title, percent)
                        }
                    }
                }
            }

            DownloadCenter.update(this, item.key) {
                it.copy(downloaded = written, state = DownloadState.DONE)
            }
        }
    }

    // ---------------------------------------------------------- notification

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL,
            "Téléchargements",
            NotificationManager.IMPORTANCE_LOW
        ).apply { setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(title: String, percent: Int, showProgress: Boolean) =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle(title)
            .setContentText(if (showProgress) "$percent %" else "Préparation…")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .apply { if (showProgress) setProgress(100, percent, percent <= 0) }
            .build()

    private fun notify(title: String, percent: Int) {
        runCatching {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildNotification(title, percent, true))
        }
    }
}
