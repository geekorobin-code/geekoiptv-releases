package fr.geeko.iptv.ui

import android.app.Activity
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.util.Rational
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Fenêtre flottante : la lecture continue par-dessus les autres applications.
 * Repose sur le mode Picture-in-Picture d'Android, disponible à partir d'Android 8.
 */
object PipState {
    /** L'app est actuellement réduite en fenêtre flottante. */
    var inPip by mutableStateOf(false)

    /** Un lecteur est ouvert : on peut donc proposer la fenêtre flottante. */
    var playerOpen by mutableStateOf(false)

    var playing by mutableStateOf(false)
    var aspect by mutableFloatStateOf(16f / 9f)

    var onPlayPause: (() -> Unit)? = null
    var onSeek: ((Long) -> Unit)? = null

    fun reset() {
        playerOpen = false
        playing = false
        onPlayPause = null
        onSeek = null
    }
}

const val PIP_ACTION = "fr.geeko.iptv.PIP_ACTION"
const val PIP_CONTROL = "control"
const val PIP_PLAY_PAUSE = 1
const val PIP_BACK = 2
const val PIP_FORWARD = 3

/**
 * Sur téléviseur, la fenêtre flottante n'a pas sa place : elle se retrouve
 * par-dessus une autre application, sans moyen simple d'y revenir à la
 * télécommande. On la refuse donc explicitement.
 */
fun supportsPip(context: Context): Boolean =
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
        !fr.geeko.iptv.ui.detectTv(context) &&
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

/** Reçoit les appuis sur les boutons de la fenêtre flottante. */
class PipReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        when (intent?.getIntExtra(PIP_CONTROL, 0)) {
            PIP_PLAY_PAUSE -> PipState.onPlayPause?.invoke()
            PIP_BACK -> PipState.onSeek?.invoke(-10_000L)
            PIP_FORWARD -> PipState.onSeek?.invoke(10_000L)
        }
    }
}

private fun action(
    context: Context,
    control: Int,
    iconRes: Int,
    title: String
): RemoteAction {
    val intent = Intent(PIP_ACTION)
        .setPackage(context.packageName)
        .putExtra(PIP_CONTROL, control)
    val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    val pending = PendingIntent.getBroadcast(context, control, intent, flags)
    return RemoteAction(Icon.createWithResource(context, iconRes), title, title, pending)
}

fun pipParams(context: Context, autoEnter: Boolean = false): PictureInPictureParams? {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null

    // Android refuse les rapports trop extrêmes.
    val ratio = PipState.aspect.coerceIn(0.45f, 2.35f)
    val rational = Rational((ratio * 1000).toInt(), 1000)

    val builder = PictureInPictureParams.Builder()
        .setAspectRatio(rational)
        .setActions(
            listOf(
                action(context, PIP_BACK, android.R.drawable.ic_media_rew, "-10 s"),
                action(
                    context,
                    PIP_PLAY_PAUSE,
                    if (PipState.playing) android.R.drawable.ic_media_pause
                    else android.R.drawable.ic_media_play,
                    if (PipState.playing) "Pause" else "Lecture"
                ),
                action(context, PIP_FORWARD, android.R.drawable.ic_media_ff, "+10 s")
            )
        )

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        // L'entrée automatique ne doit valoir que pendant une lecture :
        // sinon Android réduit l'application entière en fenêtre, menus compris.
        builder.setAutoEnterEnabled(autoEnter).setSeamlessResizeEnabled(true)
    }
    return builder.build()
}

/** Bascule tout de suite en fenêtre flottante. */
fun enterPip(activity: Activity) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val params = pipParams(activity, autoEnter = PipState.playing) ?: return
    runCatching { activity.enterPictureInPictureMode(params) }
}

/**
 * Met à jour les boutons de la fenêtre et, surtout, n'autorise l'entrée
 * automatique que si une vidéo est réellement en cours.
 */
fun refreshPipParams(activity: Activity) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val autoEnter = PipState.playerOpen && PipState.playing
    val params = pipParams(activity, autoEnter) ?: return
    runCatching { activity.setPictureInPictureParams(params) }
}

/** À appeler en quittant le lecteur : sinon l'app entière basculerait en fenêtre. */
fun clearPipAutoEnter(activity: Activity) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
    val params = PictureInPictureParams.Builder()
        .setAutoEnterEnabled(false)
        .build()
    runCatching { activity.setPictureInPictureParams(params) }
}
