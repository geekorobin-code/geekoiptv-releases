package fr.geeko.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import kotlinx.coroutines.launch
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import fr.geeko.iptv.data.StreamItem
import fr.geeko.iptv.ui.i18n.tr
import fr.geeko.iptv.ui.theme.*

@Composable
fun MosaicTab(vm: AppViewModel) {
    var picking by remember { mutableStateOf<Int?>(null) }
    val layout = vm.mosaicLayout
    val slots = vm.mosaicSlots.take(layout.slots)

    Column(Modifier.fillMaxSize()) {

        // --- barre d'outils
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "${slots.count { it != null }}/${layout.slots}",
                color = TextLow,
                fontSize = 12.sp
            )
            Spacer(Modifier.width(4.dp))
            MosaicLayout.entries.forEach { option ->
                FilterChip(
                    selected = layout == option,
                    onClick = { vm.applyMosaicLayout(option) },
                    shape = RoundedCornerShape(18.dp),
                    label = { Text(tr(option.label), fontSize = 12.sp) },
                    modifier = Modifier.tvFocus(RoundedCornerShape(18.dp), 1.05f)
                )
            }
            Spacer(Modifier.weight(1f))

            IconButton(
                onClick = { vm.go(Screen.Mosaic) },
                modifier = Modifier.tvFocus(scale = 1.08f)
            ) {
                Icon(
                    Icons.Default.Fullscreen,
                    contentDescription = tr("Plein écran"),
                    tint = Accent
                )
            }

            vm.mosaicSlots.getOrNull(vm.mosaicAudio)?.let {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = Accent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        it.name,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 220.dp)
                    )
                }
            }
        }

        Box(Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 4.dp)) {
            when (layout) {
                MosaicLayout.SIDE -> Row(
                    Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    repeat(2) { i ->
                        Box(Modifier.weight(1f).fillMaxHeight()) {
                            Tile(vm, i, slots.getOrNull(i)) { picking = i }
                        }
                    }
                }

                MosaicLayout.GRID -> Column(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    repeat(2) { row ->
                        Row(
                            Modifier.weight(1f).fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            repeat(2) { col ->
                                val i = row * 2 + col
                                Box(Modifier.weight(1f).fillMaxHeight()) {
                                    Tile(vm, i, slots.getOrNull(i)) { picking = i }
                                }
                            }
                        }
                    }
                }

                MosaicLayout.HERO -> Row(
                    Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(Modifier.weight(2f).fillMaxHeight()) {
                        Tile(vm, 0, slots.getOrNull(0)) { picking = 0 }
                    }
                    Column(
                        Modifier.weight(1f).fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        repeat(3) { k ->
                            val i = k + 1
                            Box(Modifier.weight(1f).fillMaxWidth()) {
                                Tile(vm, i, slots.getOrNull(i)) { picking = i }
                            }
                        }
                    }
                }
            }
        }

        Text(
            tr("Touche une vignette pour y mettre le son, appui long pour la plein écran."),
            color = TextLow,
            fontSize = 11.sp,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }

    picking?.let { index ->
        ChannelPicker(
            vm = vm,
            onPick = { vm.setMosaicSlot(index, it); picking = null },
            onClear = { vm.setMosaicSlot(index, null); picking = null },
            onDismiss = { picking = null }
        )
    }
}

@OptIn(UnstableApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun Tile(
    vm: AppViewModel,
    index: Int,
    channel: StreamItem?,
    onPick: () -> Unit
) {
    val context = LocalContext.current
    val isTv = LocalIsTv.current
    val audible = vm.mosaicAudio == index
    val shape = RoundedCornerShape(14.dp)
    var tileMenuOpen by remember(channel?.key) { mutableStateOf(false) }
    var pressStarted by remember(channel?.key) { mutableStateOf(false) }
    var longPressConsumed by remember(channel?.key) { mutableStateOf(false) }
    var ignoreNextClick by remember(channel?.key) { mutableStateOf(false) }
    var blockMenuCenterUntilRelease by remember(channel?.key) { mutableStateOf(false) }
    var longPressJob by remember(channel?.key) { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    val tileScope = rememberCoroutineScope()

    if (channel == null) {
        Column(
            Modifier
                .fillMaxSize()
                .clip(shape)
                .background(Surface1)
                .border(1.dp, TextLow.copy(alpha = 0.3f), shape)
                .tvFocus(shape, scale = 1.02f)
                .clickable(onClick = onPick),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Default.Add,
                contentDescription = null,
                tint = TextLow,
                modifier = Modifier.size(26.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(tr("Ajouter une chaîne"), color = TextLow, fontSize = 12.sp)
        }
        return
    }

    val url = remember(channel.id) { vm.client?.liveUrl(channel.id) }

    val player = remember(channel.id) {
        url?.let {
            ExoPlayer.Builder(context)
                .setRenderersFactory(
                    DefaultRenderersFactory(context).setEnableDecoderFallback(true)
                )
                .build().apply {
                    setMediaItem(MediaItem.fromUri(it))
                    volume = 0f
                    playWhenReady = true
                    prepare()
                }
        }
    }

    DisposableEffect(player) {
        onDispose { player?.release() }
    }

    LaunchedEffect(audible) {
        player?.volume = if (audible) 1f else 0f
    }

    Box(
        Modifier
            .fillMaxSize()
            .clip(shape)
            .background(Color.Black)
            .border(
                width = if (audible) 2.5.dp else 1.dp,
                color = if (audible) Accent else TextLow.copy(alpha = 0.25f),
                shape = shape
            )
            .tvFocus(shape, scale = 1.02f)
            .onPreviewKeyEvent { event ->
                val center = event.key == Key.DirectionCenter || event.key == Key.Enter
                if (!center) return@onPreviewKeyEvent false
                when (event.type) {
                    KeyEventType.KeyDown -> {
                        if (!pressStarted) {
                            pressStarted = true
                            longPressConsumed = false
                            longPressJob?.cancel()
                            longPressJob = tileScope.launch {
                                kotlinx.coroutines.delay(450L)
                                if (pressStarted) {
                                    longPressConsumed = true
                                    ignoreNextClick = true
                                    blockMenuCenterUntilRelease = true
                                    tileMenuOpen = true
                                }
                            }
                        }
                        longPressConsumed
                    }
                    KeyEventType.KeyUp -> {
                        longPressJob?.cancel()
                        longPressJob = null
                        pressStarted = false
                        val consumed = longPressConsumed
                        longPressConsumed = false
                        consumed
                    }
                    else -> false
                }
            }
            .combinedClickable(
                onClick = {
                    if (ignoreNextClick) ignoreNextClick = false
                    else vm.mosaicAudio = index
                },
                onLongClick = { if (!isTv) tileMenuOpen = true }
            )
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    setPlayer(player)
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    isFocusable = false
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // bandeau du bas
        Row(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.55f))
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(18.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (audible) Accent else Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "${index + 1}",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                channel.name,
                color = Color.White,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Icon(
                if (audible) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                contentDescription = null,
                tint = if (audible) Accent else Color.White.copy(alpha = 0.5f),
                modifier = Modifier.size(15.dp)
            )
            IconButton(onClick = { vm.playLive(channel) }, modifier = Modifier.size(28.dp)) {
                Icon(
                    Icons.Default.Fullscreen,
                    contentDescription = tr("Plein écran"),
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
            IconButton(onClick = onPick, modifier = Modifier.size(28.dp)) {
                Icon(
                    Icons.Default.Close,
                    contentDescription = tr("Changer"),
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }

    if (tileMenuOpen) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { tileMenuOpen = false }) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = Surface1.copy(alpha = 0.98f),
                tonalElevation = 10.dp,
                shadowElevation = 18.dp,
                modifier = Modifier
                    .widthIn(min = 420.dp, max = 560.dp)
                    .border(1.dp, Accent.copy(alpha = 0.28f), RoundedCornerShape(28.dp))
                    .onPreviewKeyEvent { event ->
                        val center =
                            event.key == Key.DirectionCenter || event.key == Key.Enter
                        if (!center || !blockMenuCenterUntilRelease) {
                            false
                        } else {
                            // Le menu vient d'être ouvert avec OK maintenu.
                            // On avale tous les KeyDown répétés ET le KeyUp correspondant.
                            // Après ce KeyUp, seule une NOUVELLE pression sur OK peut valider.
                            if (event.type == KeyEventType.KeyUp) {
                                blockMenuCenterUntilRelease = false
                            }
                            true
                        }
                    }
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text(channel.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    Text("Mosaïque ${index + 1}", color = TextLow, fontSize = 11.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { tileMenuOpen = false; onPick() },
                            modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(18.dp), 1.04f),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(Modifier.width(7.dp))
                            Text("Changer de chaîne")
                        }
                        OutlinedButton(
                            onClick = { tileMenuOpen = false; vm.setMosaicSlot(index, null) },
                            modifier = Modifier.weight(1f).tvFocus(RoundedCornerShape(18.dp), 1.04f),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null)
                            Spacer(Modifier.width(7.dp))
                            Text("Fermer la chaîne")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = { tileMenuOpen = false },
                        modifier = Modifier.align(Alignment.End).tvFocus(RoundedCornerShape(14.dp), 1.04f)
                    ) { Text("Annuler") }
                }
            }
        }
    }
}

@Composable
private fun ChannelPicker(
    vm: AppViewModel,
    onPick: (StreamItem) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val channels = remember(query, vm.liveChannels) {
        val base = vm.liveChannels
        if (query.length < 2) base.take(80)
        else base.filter { it.name.contains(query, ignoreCase = true) }.take(120)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("Ajouter une chaîne")) },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(tr("Rechercher")) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(Modifier.heightIn(max = 340.dp)) {
                    items(channels, key = { it.key }) { c ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .tvFocus(RoundedCornerShape(12.dp), scale = 1.02f)
                                .clickable { onPick(c) }
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Poster(c.icon, c.name, Modifier.width(34.dp), ratio = 1f, corner = 8)
                            Spacer(Modifier.width(12.dp))
                            if (c.number > 0) {
                                Text("${c.number}", color = TextLow, fontSize = 11.sp)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(
                                c.name,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("Fermer")) } },
        dismissButton = {
            TextButton(onClick = onClear) { Text(tr("Vider l'emplacement")) }
        }
    )
}

// --------------------------------------------------- mosaïque plein écran

/** Répartit n vignettes en lignes, selon l'orientation. */
private fun arrangement(count: Int, landscape: Boolean): List<Int> = when {
    count <= 1 -> listOf(1)
    count == 2 -> if (landscape) listOf(2) else listOf(1, 1)
    count == 3 -> if (landscape) listOf(3) else listOf(1, 1, 1)
    else -> listOf(2, 2)
}

@Composable
fun MosaicScreen(vm: AppViewModel) {
    val view = androidx.compose.ui.platform.LocalView.current
    var picking by remember { mutableStateOf<Int?>(null) }
    var chromeVisible by remember { mutableStateOf(true) }

    // plein écran immersif : barres système masquées
    DisposableEffect(Unit) {
        val window = (view.context as? android.app.Activity)?.window
        val controller = window?.let {
            androidx.core.view.WindowCompat.getInsetsController(it, view)
        }
        controller?.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        controller?.systemBarsBehavior =
            androidx.core.view.WindowInsetsControllerCompat
                .BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            controller?.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    LaunchedEffect(chromeVisible) {
        if (chromeVisible) {
            kotlinx.coroutines.delay(4000)
            chromeVisible = false
        }
    }

    val landscape = androidx.compose.ui.platform.LocalConfiguration.current.orientation ==
        android.content.res.Configuration.ORIENTATION_LANDSCAPE

    val filled = vm.mosaicSlots.withIndex().filter { it.value != null }
    val rows = arrangement(filled.size.coerceAtLeast(1), landscape)

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        if (filled.isEmpty()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .clickable { picking = 0 },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = null,
                    tint = TextLow,
                    modifier = Modifier.size(38.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text(tr("Ajouter une chaîne"), color = TextLow, fontSize = 14.sp)
            }
        } else {
            Column(
                Modifier
                    .fillMaxSize()
                    .clickable { chromeVisible = true },
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                var consumed = 0
                rows.forEach { perRow ->
                    Row(
                        Modifier.weight(1f).fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        repeat(perRow) {
                            val entry = filled.getOrNull(consumed)
                            consumed++
                            Box(Modifier.weight(1f).fillMaxHeight()) {
                                if (entry != null) {
                                    Tile(vm, entry.index, entry.value) { picking = entry.index }
                                } else {
                                    Box(
                                        Modifier
                                            .fillMaxSize()
                                            .background(Surface1)
                                            .clickable {
                                                picking = vm.mosaicSlots.indexOfFirst { it == null }
                                                    .coerceAtLeast(0)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Add,
                                            contentDescription = null,
                                            tint = TextLow,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // barre flottante, masquée au bout de quelques secondes
        androidx.compose.animation.AnimatedVisibility(
            visible = chromeVisible,
            enter = androidx.compose.animation.fadeIn(),
            exit = androidx.compose.animation.fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.back() }, modifier = Modifier.tvFocus(scale = 1.08f)) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = tr("Quitter le plein écran"),
                        tint = Color.White
                    )
                }
                Text(
                    tr("Mosaïque"),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.weight(1f))
                IconButton(
                    onClick = {
                        picking = vm.mosaicSlots.indexOfFirst { it == null }.takeIf { it >= 0 } ?: 0
                    },
                    modifier = Modifier.tvFocus(scale = 1.08f)
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = tr("Ajouter une chaîne"),
                        tint = Color.White
                    )
                }
            }
        }
    }

    picking?.let { index ->
        ChannelPicker(
            vm = vm,
            onPick = { vm.setMosaicSlot(index, it); picking = null },
            onClear = { vm.setMosaicSlot(index, null); picking = null },
            onDismiss = { picking = null }
        )
    }
}
