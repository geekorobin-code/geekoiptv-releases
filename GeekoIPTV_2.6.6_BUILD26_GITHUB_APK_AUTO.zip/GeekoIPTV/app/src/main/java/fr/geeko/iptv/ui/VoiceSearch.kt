package fr.geeko.iptv.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import fr.geeko.iptv.ui.i18n.I18n
import java.util.Locale

/** L'appareil sait-il faire de la reconnaissance vocale ? */
fun voiceSearchAvailable(context: Context): Boolean {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
    return context.packageManager.queryIntentActivities(intent, 0).isNotEmpty()
}

/**
 * Ouvre la dictée du système et renvoie le texte reconnu.
 * On ne demande aucune permission : c'est l'application vocale d'Android
 * qui accède au micro, pas nous.
 */
@Composable
fun rememberVoiceSearch(onResult: (String) -> Unit): () -> Unit {
    val context = LocalContext.current
    val prompt = fr.geeko.iptv.ui.i18n.tr("Que veux-tu regarder ?")

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            ?.trim()
        if (!spoken.isNullOrBlank()) onResult(spoken)
    }

    val locale = remember(I18n.lang) { Locale(I18n.lang.code) }

    return {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, prompt)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            launcher.launch(intent)
        } catch (_: ActivityNotFoundException) {
            // aucune app de dictée : on ne fait rien, le bouton est déjà masqué
        }
    }
}
