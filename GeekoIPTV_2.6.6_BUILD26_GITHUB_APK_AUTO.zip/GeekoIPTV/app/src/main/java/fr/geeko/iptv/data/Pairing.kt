package fr.geeko.iptv.data

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.yield
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Recopie les identifiants d'un appareil à l'autre sur le réseau local.
 *
 * Une caméra étant absente des box Android TV, on ne passe pas par un QR code :
 * le téléviseur se signale sur le Wi-Fi, le téléphone le trouve tout seul,
 * et un code à quatre chiffres affiché à l'écran autorise l'envoi.
 */
object Pairing {
    const val DISCOVERY_PORT = 53212
    const val TRANSFER_PORT = 53211
    private const val HELLO = "GEEKOIPTV_DISCOVER"

    data class Device(val name: String, val address: String)

    // ------------------------------------------------------ côté téléviseur

    /**
     * Se signale aux téléphones qui cherchent, puis attend l'envoi.
     * Bloquant : à lancer dans une coroutine d'entrée-sortie.
     */
    /**
     * Se signale aux téléphones qui cherchent, puis attend l'envoi.
     *
     * Les appels réseau sont bloquants : sans fermeture explicite des sockets
     * à l'annulation, la boucle survivrait à la sortie de l'écran et le port
     * resterait pris — ce qui faisait planter au retour.
     */
    suspend fun receive(
        context: Context,
        code: String,
        deviceName: String,
        onError: (String) -> Unit = {},
        onReceived: (host: String, user: String, pass: String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val wifi = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val lock = wifi?.createMulticastLock("geekoiptv-pairing")?.apply {
            setReferenceCounted(false)
            runCatching { acquire() }
        }

        var beacon: DatagramSocket? = null
        var server: ServerSocket? = null

        try {
            beacon = DatagramSocket(null).apply {
                reuseAddress = true
                broadcast = true
                bind(InetSocketAddress(DISCOVERY_PORT))
                soTimeout = 500
            }
            server = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(TRANSFER_PORT))
                soTimeout = 500
            }
        } catch (e: Exception) {
            runCatching { beacon?.close() }
            runCatching { server?.close() }
            runCatching { lock?.release() }
            onError(e.message ?: "bind")
            return@withContext
        }

        // ferme les sockets dès l'annulation : les appels bloquants sortent alors
        val closer = currentCoroutineContext()[Job]?.invokeOnCompletion {
            runCatching { beacon.close() }
            runCatching { server.close() }
            runCatching { lock?.release() }
        }

        try {
            while (currentCoroutineContext().isActive) {
                runCatching {
                    val buffer = ByteArray(256)
                    val packet = DatagramPacket(buffer, buffer.size)
                    beacon.receive(packet)
                    if (String(packet.data, 0, packet.length).trim() == HELLO) {
                        val reply = JSONObject().apply { put("name", deviceName) }
                            .toString().toByteArray()
                        beacon.send(DatagramPacket(reply, reply.size, packet.address, packet.port))
                    }
                }

                runCatching {
                    server.accept().use { socket ->
                        socket.soTimeout = 3000
                        val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                        val writer = PrintWriter(socket.getOutputStream(), true)
                        val line = reader.readLine() ?: return@use

                        if (line.trim() == HELLO) {
                            writer.println(JSONObject().apply { put("name", deviceName) })
                            return@use
                        }

                        val json = JSONObject(line)
                        if (json.optString("code") != code) {
                            writer.println("""{"ok":false,"error":"code"}""")
                            return@use
                        }
                        writer.println("""{"ok":true}""")
                        onReceived(
                            json.optString("host"),
                            json.optString("user"),
                            json.optString("pass")
                        )
                    }
                }

                yield()
            }
        } finally {
            closer?.dispose()
            runCatching { beacon.close() }
            runCatching { server.close() }
            runCatching { lock?.release() }
        }
    }

    /** Adresse du téléviseur, à afficher pour la saisie manuelle. */
    fun localIp(context: Context): String? {
        val wifi = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as? WifiManager
        @Suppress("DEPRECATION")
        val ip = wifi?.connectionInfo?.ipAddress ?: 0
        if (ip != 0) {
            return "${ip and 0xff}.${ip shr 8 and 0xff}.${ip shr 16 and 0xff}.${ip shr 24 and 0xff}"
        }
        // Wi-Fi indisponible (Ethernet par exemple) : on parcourt les interfaces
        return runCatching {
            java.net.NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it is java.net.Inet4Address }
                ?.hostAddress
        }.getOrNull()
    }

    // ------------------------------------------------------- côté téléphone

    /**
     * Cherche les téléviseurs en attente : d'abord par diffusion, puis en
     * balayant le sous-réseau si la box bloque les paquets de diffusion.
     */
    suspend fun discover(context: Context, timeoutMs: Long = 2500): List<Device> =
        withContext(Dispatchers.IO) {
            val byBroadcast = runCatching { broadcastDiscover(timeoutMs) }.getOrDefault(emptyList())
            if (byBroadcast.isNotEmpty()) return@withContext byBroadcast
            // filet de sécurité : la recherche ne doit jamais rester bloquée
            withTimeoutOrNull(20_000) {
                runCatching { scanSubnet(context) }.getOrDefault(emptyList())
            } ?: emptyList()
        }

    private suspend fun broadcastDiscover(timeoutMs: Long): List<Device> =
        withContext(Dispatchers.IO) {
            val found = LinkedHashMap<String, Device>()
            val socket = DatagramSocket().apply {
                broadcast = true
                soTimeout = 300
            }
            try {
                val payload = HELLO.toByteArray()
                listOf("255.255.255.255", "192.168.255.255", "10.255.255.255").forEach { target ->
                    runCatching {
                        socket.send(
                            DatagramPacket(
                                payload, payload.size,
                                InetAddress.getByName(target), DISCOVERY_PORT
                            )
                        )
                    }
                }

                // Échéance explicite : un withTimeout ne pourrait pas interrompre
                // une boucle d'appels bloquants qui ne rend jamais la main.
                val deadline = System.currentTimeMillis() + timeoutMs
                while (System.currentTimeMillis() < deadline &&
                    currentCoroutineContext().isActive
                ) {
                    runCatching {
                        val buffer = ByteArray(512)
                        val packet = DatagramPacket(buffer, buffer.size)
                        socket.receive(packet)
                        val json = JSONObject(String(packet.data, 0, packet.length))
                        val address = packet.address.hostAddress
                        if (address != null) {
                            found[address] = Device(
                                name = json.optString("name").ifBlank { address },
                                address = address
                            )
                        }
                    }
                    yield()
                }
            } finally {
                runCatching { socket.close() }
            }
            found.values.toList()
        }

    /** Essaie chaque adresse du réseau local, par paquets pour rester rapide. */
    private suspend fun scanSubnet(context: Context): List<Device> =
        withContext(Dispatchers.IO) {
            val prefix = localPrefix(context) ?: return@withContext emptyList()
            val found = mutableListOf<Device>()

            // Par tranches de 32 : lancer 254 connexions d'un coup sature
            // le répartiteur et rallonge tout.
            (1..254).chunked(32).forEach { slice ->
                if (!currentCoroutineContext().isActive) return@forEach
                val batch = coroutineScope {
                    slice.map { last ->
                        async {
                            val ip = "$prefix.$last"
                            runCatching {
                                Socket().use { socket ->
                                    socket.connect(InetSocketAddress(ip, TRANSFER_PORT), 300)
                                    socket.soTimeout = 800
                                    PrintWriter(socket.getOutputStream(), true).println(HELLO)
                                    val answer = BufferedReader(
                                        InputStreamReader(socket.getInputStream())
                                    ).readLine()
                                    val name = JSONObject(answer ?: "{}").optString("name")
                                    Device(name.ifBlank { ip }, ip)
                                }
                            }.getOrNull()
                        }
                    }.awaitAll()
                }
                found += batch.filterNotNull()
                yield()
            }
            found
        }

    private fun localPrefix(context: Context): String? {
        val wifi = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return null
        @Suppress("DEPRECATION")
        val ip = wifi.connectionInfo?.ipAddress ?: return null
        if (ip == 0) return null
        return "${ip and 0xff}.${ip shr 8 and 0xff}.${ip shr 16 and 0xff}"
    }

    /** Envoie les identifiants au téléviseur choisi. @return null si tout va bien. */
    suspend fun send(
        device: Device,
        code: String,
        host: String,
        user: String,
        pass: String
    ): String? = withContext(Dispatchers.IO) {
        runCatching {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(device.address, TRANSFER_PORT), 4000)
                val writer = PrintWriter(socket.getOutputStream(), true)
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                writer.println(
                    JSONObject().apply {
                        put("code", code)
                        put("host", host)
                        put("user", user)
                        put("pass", pass)
                    }.toString()
                )
                val answer = JSONObject(reader.readLine() ?: "{}")
                if (answer.optBoolean("ok")) null else "code"
            }
        }.getOrElse { it.message ?: "network" }
    }

    fun deviceName(): String =
        listOfNotNull(Build.MANUFACTURER, Build.MODEL)
            .joinToString(" ")
            .trim()
            .ifBlank { "Android TV" }

    fun newCode(): String = (1000..9999).random().toString()
}
