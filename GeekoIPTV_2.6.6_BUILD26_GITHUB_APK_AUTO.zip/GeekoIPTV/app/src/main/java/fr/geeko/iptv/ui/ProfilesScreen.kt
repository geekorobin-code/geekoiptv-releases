package fr.geeko.iptv.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import java.io.File
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.data.Profile
import fr.geeko.iptv.ui.theme.ProfileColors
import fr.geeko.iptv.ui.theme.Surface1
import fr.geeko.iptv.ui.theme.TextLow
import fr.geeko.iptv.ui.i18n.tr

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesScreen(vm: AppViewModel) {
    val context = LocalContext.current
    var appeared by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (vm.soundEnabled) Chime.play()
        appeared = true
    }

    var editing by remember { mutableStateOf<Profile?>(null) }
    var creating by remember { mutableStateOf(false) }
    var pinFor by remember { mutableStateOf<Profile?>(null) }
    var confirmLogout by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().appBackground()) {
        TopAppBar(
            title = { Text(tr("Qui regarde ?"), fontSize = 22.sp, fontWeight = FontWeight.Bold) },
            actions = {
                IconButton(
                    onClick = { creating = true },
                    modifier = Modifier.tvFocus(scale = 1.06f)
                ) {
                    Icon(
                        Icons.Default.PersonAdd,
                        contentDescription = tr("Ajouter un membre")
                    )
                }
                IconButton(
                    onClick = { confirmLogout = true },
                    modifier = Modifier.tvFocus(scale = 1.06f)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = tr("Déconnexion"))
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        ErrorBar(vm.error) { vm.error = null }

        vm.account?.let { acc ->
            Surface(
                color = Surface1,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Verified,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(acc.username, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Abonnement ${acc.status.lowercase()} · expire le ${acc.expiry}",
                        color = TextLow, fontSize = 13.sp)
                    Text("Connexions : ${acc.activeConnections}/${acc.maxConnections}",
                        color = TextLow, fontSize = 13.sp)
                }
            }
        }
        if (vm.account == null && vm.loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        }

        SectionHeader(tr("Membres"))

        LazyVerticalGrid(
            columns = GridCells.Adaptive(if (LocalIsTv.current) 170.dp else 110.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(vm.profiles, key = { _, p -> p.id }) { index, p ->
                ProfileTile(
                    name = p.name,
                    color = ProfileColors[p.colorIndex % ProfileColors.size],
                    avatarPath = p.avatarPath,
                    locked = p.locked,
                    appeared = appeared,
                    order = index,
                    onClick = {
                        if (vm.soundEnabled) Chime.play(0.35f)
                        if (p.locked) pinFor = p else vm.enterProfile(p)
                    },
                    onLongClick = { editing = p }
                )
            }
            if (vm.profiles.isEmpty()) {
                item {
                    AddTile(appeared, 0) { creating = true }
                }
            }
        }
    }

    if (creating) {
        ProfileDialog(
            title = tr("Nouveau membre"),
            initialName = "",
            initialColor = vm.profiles.size % ProfileColors.size,
            initialAvatar = null,
            askPin = true,
            onDismiss = { creating = false },
            onConfirm = { name, color, pin, avatar ->
                vm.createProfile(name, color, pin, avatar)
                creating = false
            }
        )
    }

    editing?.let { p ->
        ProfileDialog(
            title = "Modifier ${p.name}",
            initialName = p.name,
            initialColor = p.colorIndex,
            initialAvatar = p.avatarPath,
            askPin = false,
            onDelete = { vm.deleteProfile(p.id); editing = null },
            onDismiss = { editing = null },
            onConfirm = { name, color, _, avatar ->
                vm.renameProfile(p, name, color, avatar)
                editing = null
            }
        )
    }

    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            title = { Text(tr("Changer d'abonnement ?")) },
            text = {
                Text(tr("Tes identifiants restent enregistrés : tu n'auras pas à les retaper."))
            },
            confirmButton = {
                TextButton(onClick = { confirmLogout = false; vm.logout() }) {
                    Text(tr("Continuer"))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmLogout = false }) { Text(tr("Annuler")) }
            }
        )
    }

    pinFor?.let { p ->
        PinDialog(
            name = p.name,
            onDismiss = { pinFor = null },
            onSubmit = { pin ->
                if (vm.checkPin(p, pin)) { pinFor = null; vm.enterProfile(p); true } else false
            }
        )
    }
}

@Composable
private fun popScale(appeared: Boolean, order: Int): Float {
    var ready by remember { mutableStateOf(false) }
    LaunchedEffect(appeared) {
        if (appeared) {
            kotlinx.coroutines.delay(90L * order)
            ready = true
        }
    }
    val scale by animateFloatAsState(
        targetValue = if (ready) 1f else 0.35f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow),
        label = "profile-pop"
    )
    return scale
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun ProfileTile(
    name: String,
    color: Color,
    avatarPath: String?,
    locked: Boolean,
    appeared: Boolean,
    order: Int,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val scale = popScale(appeared, order)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.graphicsLayer {
            scaleX = scale
            scaleY = scale
            alpha = scale.coerceIn(0f, 1f)
        }
    ) {
        Box(contentAlignment = Alignment.Center) {
            SparkleBurst(
                visible = scale > 0.5f,
                modifier = Modifier.size(if (LocalIsTv.current) 200.dp else 150.dp)
            )
        Box(
            Modifier
                .size(if (LocalIsTv.current) 132.dp else 96.dp)
                .tvFocus(RoundedCornerShape(24.dp), scale = 1.1f)
                .clip(RoundedCornerShape(24.dp))
                .background(color.copy(alpha = 0.85f))
                .combinedClickable(onClick = onClick, onLongClick = onLongClick),
            contentAlignment = Alignment.Center
        ) {
            if (!avatarPath.isNullOrBlank() && File(avatarPath).exists()) {
                AsyncImage(
                    model = File(avatarPath),
                    contentDescription = name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(
                    name.trim().take(2).uppercase(),
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            if (locked) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(7.dp)
                        .size(22.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(Color.Black.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
        }
        Spacer(Modifier.height(8.dp))
        Text(name, fontSize = 14.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun AddTile(appeared: Boolean, order: Int, onClick: () -> Unit) {
    val scale = popScale(appeared, order)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.graphicsLayer {
            scaleX = scale; scaleY = scale; alpha = scale.coerceIn(0f, 1f)
        }
    ) {
        Box(
            Modifier
                .size(if (LocalIsTv.current) 132.dp else 96.dp)
                .tvFocus(RoundedCornerShape(20.dp), scale = 1.1f)
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Add, contentDescription = tr("Ajouter un membre"),
                tint = TextLow, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(tr("Ajouter"), fontSize = 14.sp, color = TextLow)
    }
}

@Composable
private fun ProfileDialog(
    title: String,
    initialName: String,
    initialColor: Int,
    initialAvatar: String?,
    askPin: Boolean,
    onDelete: (() -> Unit)? = null,
    onDismiss: () -> Unit,
    onConfirm: (String, Int, String?, String?) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initialName) }
    var color by remember { mutableIntStateOf(initialColor) }
    var pin by remember { mutableStateOf("") }
    var usePin by remember { mutableStateOf(false) }
    var avatar by remember { mutableStateOf(initialAvatar) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) avatar = copyAvatar(context, uri)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(ProfileColors[color % ProfileColors.size].copy(alpha = 0.85f))
                            .clickable { picker.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        val f = avatar?.let { File(it) }
                        if (f != null && f.exists()) {
                            AsyncImage(
                                model = f,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                Icons.Default.AddAPhoto,
                                contentDescription = tr("Choisir une photo"),
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        TextButton(onClick = { picker.launch("image/*") }) {
                            Text(if (avatar == null) tr("Choisir une photo") else tr("Changer"))
                        }
                        if (avatar != null) {
                            TextButton(onClick = { avatar = null }) { Text(tr("Retirer")) }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(tr("Prénom")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Text(tr("Couleur"), fontSize = 13.sp, color = TextLow)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ProfileColors.forEachIndexed { i, c ->
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    width = if (i == color) 3.dp else 0.dp,
                                    color = Color.White,
                                    shape = CircleShape
                                )
                                .clickable { color = i }
                        )
                    }
                }
                if (askPin) {
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = usePin, onCheckedChange = { usePin = it })
                        Text(tr("Protéger par un code"), fontSize = 14.sp)
                    }
                    if (usePin) {
                        OutlinedTextField(
                            value = pin,
                            onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it },
                            label = { Text(tr("Code à 4 chiffres")) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onConfirm(name, color, if (usePin && pin.length == 4) pin else null, avatar)
                },
                enabled = name.isNotBlank() && (!usePin || pin.length == 4)
            ) { Text(tr("Enregistrer")) }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text(tr("Supprimer"), color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text(tr("Annuler")) }
            }
        }
    )
}

@Composable
private fun PinDialog(name: String, onDismiss: () -> Unit, onSubmit: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Code de $name") },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = {
                        if (it.length <= 4 && it.all(Char::isDigit)) { pin = it; wrong = false }
                    },
                    label = { Text(tr("4 chiffres")) },
                    singleLine = true,
                    isError = wrong,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
                if (wrong) {
                    Text(tr("Code incorrect"), color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (!onSubmit(pin)) { wrong = true; pin = "" } },
                enabled = pin.length == 4
            ) { Text(tr("Entrer")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("Annuler")) } }
    )
}

/** Copie l'image choisie dans le stockage privé de l'app et renvoie son chemin. */
private fun copyAvatar(context: android.content.Context, uri: Uri): String? = runCatching {
    val dir = File(context.filesDir, "avatars").apply { mkdirs() }
    val target = File(dir, "avatar_${System.currentTimeMillis()}.jpg")
    context.contentResolver.openInputStream(uri)?.use { input ->
        target.outputStream().use { output -> input.copyTo(output) }
    }
    target.absolutePath.takeIf { target.length() > 0 }
}.getOrNull()
