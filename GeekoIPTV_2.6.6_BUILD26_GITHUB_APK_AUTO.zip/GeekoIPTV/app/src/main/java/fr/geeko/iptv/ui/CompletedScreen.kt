package fr.geeko.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.data.Completion
import fr.geeko.iptv.data.ContentType
import fr.geeko.iptv.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import fr.geeko.iptv.ui.i18n.tr

private val monthFormat = SimpleDateFormat("MMMM yyyy", Locale.FRANCE)
private val dayFormat = SimpleDateFormat("d MMMM 'à' HH:mm", Locale.FRANCE)

@Composable
fun CompletedScreen(vm: AppViewModel) {
    var onlyFull by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    val all = vm.completions
    val list = remember(all, onlyFull) {
        if (onlyFull) all.filter { it.fullSeries || it.type == ContentType.VOD } else all
    }
    val grouped = remember(list) {
        list.groupBy { monthFormat.format(Date(it.at)) }
    }

    val fullSeries = all.count { it.fullSeries }
    val movies = all.count { it.type == ContentType.VOD }
    val episodes = all.count { it.type == ContentType.SERIES && !it.fullSeries }

    Column(Modifier.fillMaxSize().appBackground().statusBarsPadding()) {

        Row(
            Modifier.fillMaxWidth().padding(start = 6.dp, end = 16.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.back() }, modifier = Modifier.tvFocus(scale = 1.05f)) {
                Icon(Icons.Default.ArrowBack, contentDescription = tr("Retour"))
            }
            Spacer(Modifier.width(4.dp))
            Text(tr("Terminés"), Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            if (all.isNotEmpty()) {
                TextButton(onClick = { confirmClear = true }) {
                    Text(tr("Effacer"), fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Trophy(fullSeries.toString(), tr("séries bouclées"))
            Trophy(movies.toString(), tr("films vus"))
            Trophy(episodes.toString(), tr("épisodes"))
        }

        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = !onlyFull,
                onClick = { onlyFull = false },
                shape = RoundedCornerShape(18.dp),
                label = { Text(tr("Tout"), fontSize = 13.sp) },
                modifier = Modifier.tvFocus(RoundedCornerShape(18.dp), 1.05f)
            )
            FilterChip(
                selected = onlyFull,
                onClick = { onlyFull = true },
                shape = RoundedCornerShape(18.dp),
                label = { Text(tr("Œuvres complètes"), fontSize = 13.sp) },
                modifier = Modifier.tvFocus(RoundedCornerShape(18.dp), 1.05f)
            )
        }

        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = TextLow,
                        modifier = Modifier.size(42.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(tr("Rien de terminé pour l'instant"), color = TextLow, fontSize = 14.sp)
                }
            }
            return@Column
        }

        LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 28.dp)) {
            grouped.forEach { (month, entries) ->
                item(key = "h-$month") {
                    Text(
                        month.replaceFirstChar { it.uppercase() },
                        color = Accent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                    )
                }
                items(entries, key = { it.key }) { c -> CompletionRow(c) { vm.removeCompletion(c.key) } }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr("Effacer l'historique ?")) },
            text = {
                Text(
                    "Tous les titres terminés et les trophées de ce profil seront oubliés. " +
                        "Les autres profils ne sont pas touchés."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.clearCompletions(); confirmClear = false }) {
                    Text(tr("Effacer"), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text(tr("Annuler")) }
            }
        )
    }
}

@Composable
private fun RowScope.Trophy(value: String, label: String) {
    Column(
        Modifier
            .weight(1f)
            .clip(RoundedCornerShape(18.dp))
            .background(Surface1)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent)
        Text(label, color = TextLow, fontSize = 11.sp)
    }
}

@Composable
private fun CompletionRow(c: Completion, onRemove: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .tvFocus(RoundedCornerShape(16.dp), scale = 1.02f)
            .clickable(onClick = onRemove)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Poster(c.icon, c.title, Modifier.width(46.dp), corner = 10)
            if (c.fullSeries) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(3.dp)
                        .size(18.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(Gold),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = androidx.compose.ui.graphics.Color(0xFF3A2A00),
                        modifier = Modifier.size(11.dp)
                    )
                }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                c.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                listOfNotNull(
                    if (c.fullSeries) tr("Série terminée") else c.subtitle,
                    dayFormat.format(Date(c.at))
                ).joinToString(" · "),
                color = TextLow,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(
            Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Mint,
            modifier = Modifier.size(19.dp)
        )
    }
}
