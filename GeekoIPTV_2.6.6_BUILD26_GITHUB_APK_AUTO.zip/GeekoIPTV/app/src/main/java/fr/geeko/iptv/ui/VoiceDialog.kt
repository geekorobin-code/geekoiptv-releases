package fr.geeko.iptv.ui

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.ui.i18n.I18n
import fr.geeko.iptv.ui.i18n.tr
import fr.geeko.iptv.ui.theme.Accent
import fr.geeko.iptv.ui.theme.TextLow
import fr.geeko.iptv.ui.theme.Surface1
import java.util.Locale

/**
 * Dictée intégrée à l'application.
 *
 * Sur téléviseur, l'activité de dictée du système n'est pas toujours présente
 * et ne récupère pas le micro de la télécommande : on pilote donc directement
 * le moteur de reconnaissance, ce qui demande l'autorisation du micro.
 */
@Composable
fun VoiceDialog(onDismiss: () -> Unit, onResult: (String) -> Unit) {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(
            androidx.core.content.ContextCompat.checkSelfPermission(
                context, Manifest.permission.RECORD_AUDIO
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    var heard by remember { mutableStateOf("") }
    var level by remember { mutableFloatStateOf(0f) }
    var error by remember { mutableStateOf<String?>(null) }

    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        granted = ok
        if (!ok) error = tr("Autorisation micro refusée")
    }

    LaunchedEffect(Unit) {
        if (!granted) permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    DisposableEffect(granted) {
        if (!granted) return@DisposableEffect onDispose { }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            error = tr("Reconnaissance vocale indisponible sur cet appareil")
            return@DisposableEffect onDispose { }
        }

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onRmsChanged(rms: Float) {
                // -2 à 10 environ : on ramène ça entre 0 et 1
                level = ((rms + 2f) / 12f).coerceIn(0f, 1f)
            }

            override fun onPartialResults(partial: Bundle) {
                partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.let { heard = it }
            }

            override fun onResults(results: Bundle) {
                val spoken = results
                    .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.trim()
                if (!spoken.isNullOrBlank()) onResult(spoken)
                onDismiss()
            }

            override fun onError(code: Int) {
                error = when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> tr("Je n'ai rien entendu")
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> tr("Connexion impossible")
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        tr("Autorisation micro refusée")
                    else -> tr("Reconnaissance vocale indisponible sur cet appareil")
                }
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(type: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale(I18n.lang.code).toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        runCatching { recognizer.startListening(intent) }

        onDispose {
            runCatching { recognizer.stopListening() }
            runCatching { recognizer.destroy() }
        }
    }

    val pulse by animateFloatAsState(
        targetValue = 1f + level * 0.45f,
        animationSpec = tween(120),
        label = "voice-pulse"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(30.dp),
        containerColor = Surface1.copy(alpha = 0.98f),
        tonalElevation = 12.dp,
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(tr("Fermer")) }
        },
        text = {
            Column(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .size(96.dp)
                        .scale(pulse)
                        .clip(CircleShape)
                        .background(Accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = null,
                        tint = Accent,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(Modifier.height(18.dp))

                Text(
                    error ?: heard.ifBlank { tr("Parle maintenant…") },
                    color = if (error != null) MaterialTheme.colorScheme.error else Color.Unspecified,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )

                if (error == null && heard.isBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        tr("Que veux-tu regarder ?"),
                        color = TextLow,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    )
}
