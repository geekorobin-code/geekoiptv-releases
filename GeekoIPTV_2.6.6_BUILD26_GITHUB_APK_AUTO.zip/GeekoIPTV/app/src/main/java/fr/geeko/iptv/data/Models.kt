package fr.geeko.iptv.data

enum class ContentType(val label: String, val catAction: String, val listAction: String) {
    LIVE("TV", "get_live_categories", "get_live_streams"),
    VOD("Films", "get_vod_categories", "get_vod_streams"),
    SERIES("Séries", "get_series_categories", "get_series")
}

data class Category(
    val id: String,
    val name: String,
    val type: ContentType
)

data class StreamItem(
    val id: String,
    val name: String,
    val icon: String?,
    val type: ContentType,
    val containerExt: String? = null,
    val categoryId: String? = null,
    val added: Long = 0L,
    val plot: String? = null,
    val rating: String? = null,
    /** Numéro de la chaîne tel que fourni par le serveur (champ "num"). */
    val number: Int = 0
) {
    val key: String get() = "${type.name}:$id"
}

data class Episode(
    val id: String,
    val title: String,
    val ext: String,
    val season: Int,
    val number: Int,
    val cover: String?,
    val plot: String?,
    val durationSecs: Int = 0
)

data class SeriesInfo(
    val cover: String?,
    val plot: String?,
    val episodes: List<Episode>,
    val backdrop: String? = null,
    val genre: String? = null,
    val releaseDate: String? = null,
    val rating: String? = null,
    val cast: String? = null,
    val director: String? = null
) {
    val seasons: List<Int> get() = episodes.map { it.season }.distinct().sorted()
}

/** Un titre terminé, pour l'historique et les trophées. */
data class Completion(
    val key: String,
    val type: ContentType,
    val title: String,
    val subtitle: String? = null,
    val icon: String? = null,
    val seriesId: String? = null,
    val at: Long = System.currentTimeMillis(),
    /** true quand c'est la série entière qui est bouclée, pas juste un épisode. */
    val fullSeries: Boolean = false
)

data class EpgEntry(
    val title: String,
    val description: String?,
    val startMs: Long,
    val endMs: Long
) {
    val durationMinutes: Int get() = ((endMs - startMs) / 60000L).toInt().coerceAtLeast(1)
    fun isNow(now: Long) = now in startMs until endMs
    fun progress(now: Long): Float =
        if (endMs <= startMs) 0f
        else ((now - startMs).toFloat() / (endMs - startMs)).coerceIn(0f, 1f)
}

data class MovieInfo(
    val cover: String? = null,
    val backdrop: String? = null,
    val plot: String? = null,
    val genre: String? = null,
    val releaseDate: String? = null,
    val rating: String? = null,
    val cast: String? = null,
    val director: String? = null,
    val durationLabel: String? = null,
    val containerExt: String? = null
)

data class Account(
    val username: String,
    val status: String,
    val expiry: String,
    val activeConnections: String,
    val maxConnections: String,
    val serverName: String
)

/** Tout ce qu'il faut pour relancer une lecture depuis l'historique. */
data class HistoryEntry(
    val key: String,
    val type: ContentType,
    val streamId: String,
    val title: String,
    val subtitle: String? = null,
    val icon: String? = null,
    val containerExt: String? = null,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val updatedAt: Long = System.currentTimeMillis(),
    val seriesId: String? = null,
    val season: Int = 0,
    val episode: Int = 0,
    /** Image capturée à l'endroit où on s'est arrêté. */
    val thumb: String? = null
) {
    val progress: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val finished: Boolean
        get() = durationMs > 0 && positionMs > durationMs * 0.95f
}
