package fr.geeko.iptv.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import fr.geeko.iptv.ui.theme.TextLow
import fr.geeko.iptv.ui.i18n.tr

@Composable
fun LoginScreen(vm: AppViewModel) {
    var host by remember { mutableStateOf(vm.store.host) }
    var user by remember { mutableStateOf(vm.store.username) }
    var pass by remember { mutableStateOf(vm.store.password) }
    var showPass by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("GeekoIPTV", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(
            tr("Connecte ton abonnement Xtream Codes"),
            color = TextLow, fontSize = 14.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 28.dp)
        )

        // Placé en tête : sur téléviseur, descendre jusqu'en bas obligerait à
        // traverser les trois champs, et chacun ouvre le clavier au passage.
        OutlinedButton(
            onClick = { vm.go(Screen.PairReceive) },
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .tvFocus(RoundedCornerShape(22.dp), 1.02f)
        ) {
            Icon(
                Icons.Default.Cast,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(tr("Recevoir depuis un téléphone"), fontSize = 14.sp)
        }


        Spacer(Modifier.height(20.dp))

        Text(
            tr("ou saisis-les à la main"),
            color = TextLow,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        OutlinedTextField(
            value = host,
            onValueChange = { host = it },
            label = { Text(tr("Adresse du serveur")) },
            placeholder = { Text("http://monserveur.tv:8080") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next
            ),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = user,
            onValueChange = { user = it },
            label = { Text(tr("Identifiant")) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = pass,
            onValueChange = { pass = it },
            label = { Text(tr("Mot de passe")) },
            singleLine = true,
            visualTransformation = if (showPass) VisualTransformation.None
            else PasswordVisualTransformation(),
            trailingIcon = if (LocalIsTv.current) null else ({
                IconButton(onClick = { showPass = !showPass }) {
                    Icon(
                        if (showPass) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = tr("Afficher le mot de passe")
                    )
                }
            }),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password, imeAction = ImeAction.Done
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        // Rangée à part : sur téléviseur, une icône logée dans le champ
        // ne reçoit pas le focus de la télécommande.
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .tvFocus(RoundedCornerShape(14.dp), scale = 1.02f)
                .clickable { showPass = !showPass }
                .padding(vertical = 6.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = showPass, onCheckedChange = { showPass = it })
            Spacer(Modifier.width(8.dp))
            Text(tr("Afficher le mot de passe"), fontSize = 14.sp)
        }

        Spacer(Modifier.height(18.dp))

        Button(
            onClick = { vm.connect(host, user, pass) },
            enabled = !vm.loading,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            if (vm.loading) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(20.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
            } else {
                Text(tr("Se connecter"), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        vm.error?.let {
            Spacer(Modifier.height(16.dp))
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = MaterialTheme.shapes.medium
            ) {
                Text(
                    it,
                    Modifier.fillMaxWidth().padding(14.dp),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            tr("Rien n'est envoyé ailleurs : tes identifiants restent sur l'appareil."),
            color = TextLow, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
