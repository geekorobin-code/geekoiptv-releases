# GeekoIPTV

Lecteur IPTV Xtream Codes pour Android — profils façon Netflix, reprise de lecture,
groupes masquables et un lecteur pensé pour la télécommande au pouce.

## Un seul APK : téléphone, tablette et Android TV

Le manifeste déclare `LEANBACK_LAUNCHER`, une bannière de lanceur et `touchscreen
required="false"`, donc l'app apparaît bien dans le lanceur Android TV **et** sur mobile.
Au démarrage, `detectTv()` regarde `FEATURE_LEANBACK` / `UiModeManager` et bascule
l'interface :

| | Mobile / tablette | Android TV |
|---|---|---|
| Navigation | barre du bas | rail vertical à gauche, avec Réglages et la carte du profil en bas |
| Sélection | tactile | focus D-pad : grossissement en ressort + liseré orange |
| Vignettes | 120 dp | 168 dp, marges d'overscan |
| Lecteur | boutons tactiles + bouton BOOST maintenu | tout à la télécommande |
| Orientation | forcée en paysage | laissée telle quelle |

### Télécommande, dans le lecteur

| Touche | Action |
|---|---|
| **Droite maintenue** | accélère à la vitesse de boost, relâchée → retour immédiat à la normale |
| Droite (appui bref) | +10 s |
| **Gauche maintenue** | recul rapide en continu |
| Gauche (appui bref) | −10 s |
| OK / Play-Pause | lecture / pause |
| **Haut** | bascule la piste audio entre ta langue et la secondaire |
| **Bas** | sous-titres activés / désactivés |
| Menu, Info | panneau d'options complet |
| Retour | quitte (position sauvegardée) ou ferme le panneau |

Le panneau d'options se navigue au D-pad : vitesse par pas de 0,25, valeur du boost,
liste des pistes audio, liste des sous-titres, format de l'image.

Une barre d'état en bas rappelle en permanence la vitesse, la langue active, l'état des
sous-titres et les raccourcis.

### Bouton dédié de la télécommande (bouton Netflix de la Shield)

Ce bouton est câblé côté système : une app normale ne le reçoit pas, et Button Mapper le
consomme avant tout le monde. Contournement : régler Button Mapper sur **« lancer
GeekoIPTV »**.

- app en arrière-plan → le bouton l'ouvre, c'est le raccourci de lancement
- app déjà à l'écran → Android n'en relance pas une deuxième (`launchMode="singleTop"`),
  il appelle `onNewIntent`, que `ShortcutBus` transforme en action

L'action est réglable par profil dans **Réglages > Bouton dédié** : changer de langue,
sous-titres on/off, vitesse rapide verrouillée (bascule 1× ↔ vitesse de boost), ou rien.

### Remapper les touches

**Réglages > Remapper les touches de la télécommande** : chaque action du lecteur peut être
attribuée à la touche de ton choix. Tu sélectionnes l'action, tu appuies sur « Attribuer »,
puis tu presses la touche voulue — elle est capturée et enregistrée.

Actions disponibles : lecture/pause, avancer ou reculer de 10 s, accélérer tant que la
touche est maintenue, vitesse rapide verrouillée, changer de langue, sous-titres on/off,
vitesse ±0,25, panneau d'options, format d'image, quitter.

Une touche non attribuée garde son comportement par défaut. Retour, Accueil, Marche/Arrêt
et le volume sont protégés et refusés à l'attribution. Le mappage est propre à chaque
profil ; « Tout effacer » en haut à droite rétablit les touches d'origine.

**Réglages > Tester les touches de la télécommande** affiche le keycode de chaque touche
pressée, et confirme si le bouton dédié est bien détecté. Utile aussi pour les touches
exotiques des autres télécommandes.

### Bandeaux sur TV

Les bandeaux ne sont pas focusables sur TV pour ne jamais voler le focus au D-pad :
le rappel « à regarder plus tard » est purement informatif (la liste reste accessible en
haut de l'accueil), et le bandeau de mise à jour ouvre directement le dialogue, lui
navigable à la télécommande.

## Ouvrir le projet

1. Android Studio → **File > Open** → dossier `GeekoIPTV`
2. Le wrapper Gradle n'inclut pas `gradle-wrapper.jar` (binaire) : Android Studio propose
   de le régénérer au premier sync, sinon `File > Sync Project with Gradle Files`.
3. `Build > Build APK(s)` ou ▶ pour installer directement.

La barre du bas passe automatiquement en rail latéral dès 720 dp de large, donc les
tablettes en paysage et les émulateurs profitent de la même disposition que la TV.

Compile SDK 35 · min SDK 24 · Kotlin 2.0.21 · AGP 8.7.3 · Media3 1.4.1

## Parcours

| Écran | Ce qu'on y fait |
|---|---|
| Connexion | adresse du serveur, identifiant, mot de passe. Tout reste en local. |
| Membres | l'abonnement s'affiche (statut, expiration, connexions). Un membre = un profil avec son historique, ses masquages et ses réglages. Code PIN 4 chiffres optionnel. Appui long sur un membre pour le renommer ou le supprimer. |
| Accueil | salutation selon l'heure, compteurs du catalogue, pastilles d'abonnement et de connexions, puis les rangées : « Reprendre la lecture », « À regarder plus tard », séries et films récemment ajoutés, chacune avec un lien « Tout voir ». |
| Recherche | loupe en haut à droite (champ complet dès que l'écran est large) : cherche dans les films, les séries et les chaînes en même temps, résultats groupés par type. |
| TV / Films / Séries | liste des groupes. **Appui long sur un groupe = le masquer.** L'icône œil barré en haut à droite ouvre la liste des groupes masqués pour les réafficher. |
| Série | saisons, épisodes, bouton de reprise sur le bon épisode, marque-page dans la barre du haut. |

## À regarder plus tard

**Appui long sur n'importe quelle jaquette** (accueil ou grille d'un groupe) l'ajoute à la
liste, un deuxième appui long la retire. Une pastille orange apparaît sur les jaquettes
retenues, et la liste remonte en haut de l'accueil.

De temps en temps, un bandeau Material 3 Expressive descend du haut de l'écran avec la
jaquette d'un titre mis de côté : entrée en ressort avec léger dépassement, fine ligne qui
se rétracte pour indiquer le temps restant, disparition automatique au bout de 7 secondes.

- tap sur le bandeau ou sur le rond orange → lecture (ou fiche série)
- icône marque-page barré → retire le titre de la liste
- glissé vers le haut → chasse le bandeau
- retour → chasse le bandeau avant de quitter l'écran

Premier rappel environ 25 s après l'entrée dans un profil, puis un toutes les 2 à 4 minutes,
en tournant sur la liste sans jamais répéter deux fois de suite. Jamais pendant la lecture.

## Lecteur

- **Bouton rond BOOST** (bord droit, toujours visible) : maintiens-le, la lecture passe à la
  vitesse choisie ; relâche, retour immédiat à la vitesse normale. « changer » cycle
  entre 1,5× / 2× / 2,5× / 3× / 4×.
- **Vitesse fixe** : − et + par pas de 0,25 (de 0,25× à 4×). Appui sur la valeur = retour à 1×.
- **Deux boutons de langue** : ta langue principale et la secondaire, un tap pour basculer
  la piste audio en direct. L'icône casque ouvre la liste complète des pistes.
- **ST ON / ST OFF** : sous-titres à la volée. L'icône sous-titres ouvre le choix de piste.
- Double-tap à gauche / à droite : −10 s / +10 s. Bouton format pour zoomer l'image.
- Position sauvegardée toutes les 15 s et à la sortie ; une seule entrée par série dans
  l'historique (l'épisode en cours remplace le précédent).

Les langues, la vitesse du boost et les sous-titres par défaut se règlent par profil
dans **Réglages** (icône engrenage).

## Notes techniques

- `player_api.php` en OkHttp + `org.json` (tolérant aux serveurs qui renvoient des nombres
  en chaînes de caractères).
- Trafic HTTP en clair autorisé via `network_security_config.xml` (la majorité des portails
  Xtream sont en http).
- L'accueil charge tout le catalogue VOD et séries pour trier par date d'ajout. Sur un
  portail avec des dizaines de milliers d'entrées, ça peut prendre quelques secondes au
  premier affichage — c'est mis en cache pour la session.
- Aucun contenu n'est fourni : l'app se connecte au serveur dont tu saisis les identifiants.


## Mise à jour in-app (hors Play Store)

L'app lit un manifeste JSON, compare le `versionCode`, télécharge l'APK et ouvre
l'installeur système. Aucun store impliqué.

L'URL du manifeste est dans `app/build.gradle.kts` :

```kotlin
buildConfigField("String", "UPDATE_URL", "\"https://.../update.json\"")
```

### Publier une nouvelle version

1. Dans `app/build.gradle.kts`, incrémente `versionCode` (2, 3, 4…) et mets à jour
   `versionName`.
2. `Build > Generate Signed Bundle / APK` → **APK** → release, avec **le même keystore
   que la version précédente**. Sans ça, Android refuse la mise à jour et l'utilisateur
   doit désinstaller.
3. Publie l'APK (GitHub Releases par exemple) et note son empreinte :
   `sha256sum GeekoIPTV-1.1.apk`
4. Mets à jour `update.json` sur le serveur :

```json
{
  "versionCode": 2,
  "versionName": "1.1",
  "notes": "• Ce qui change\n• Ligne suivante",
  "apkUrl": "https://github.com/.../GeekoIPTV-1.1.apk",
  "sha256": "empreinte en minuscules, ou chaîne vide pour désactiver la vérification",
  "mandatory": false
}
```

Dès le prochain lancement, tout le monde reçoit le bandeau.

### Comportement

- Vérification silencieuse 3 s après le lancement, au maximum une fois toutes les 6 h.
- Bandeau vert Expressive en haut : appui → notes de version, Installer / Ignorer / Plus tard.
- « Ignorer » mémorise le `versionCode` et n'en reparle plus, sauf si `mandatory` est à `true`
  (dans ce cas le bandeau n'est ni glissable ni ignorable).
- Vérification manuelle dans **Réglages > Rechercher une mise à jour**.
- L'empreinte SHA-256 est vérifiée après téléchargement ; si elle ne correspond pas, le
  fichier est supprimé et rien n'est installé.
- Au premier essai Android demande d'autoriser GeekoIPTV à installer des applications
  (permission `REQUEST_INSTALL_PACKAGES`) — l'app ouvre directement le bon écran de réglages.
- L'APK est téléchargé dans le dossier privé de l'app et partagé à l'installeur via un
  `FileProvider`, aucune permission de stockage nécessaire.

`update.json` à la racine du dépôt sert d'exemple.
