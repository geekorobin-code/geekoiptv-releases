# Compiler l'APK GeekoIPTV avec GitHub Actions

Le projet contient maintenant `.github/workflows/build-apk.yml`.

## Première mise en place

1. Crée (ou utilise) un dépôt GitHub contenant **tout le dossier GeekoIPTV**.
2. Vérifie que `.github/workflows/build-apk.yml` est bien présent dans le dépôt.
3. Ouvre l'onglet **Actions** du dépôt.
4. Choisis **Build GeekoIPTV APK**.
5. Appuie sur **Run workflow** puis **Run workflow**.

Le workflow se lance aussi automatiquement à chaque push sur `main` ou `master` lorsqu'un fichier du projet change.

## Télécharger l'APK depuis le téléphone

Quand le build est terminé :

1. GitHub > dépôt > **Actions**.
2. Ouvre le build avec la coche verte.
3. Descends jusqu'à **Artifacts**.
4. Télécharge **GeekoIPTV-2.6.6-BUILD26-APK**.
5. GitHub télécharge un ZIP contenant `GeekoIPTV_2.6.6_BUILD26.apk`.
6. Décompresse-le sur Android et ouvre l'APK pour l'installer.

L'APK produit est un **debug APK signé automatiquement par Android**, donc installable immédiatement pour les tests.

## Pour les prochaines versions

Quand `versionName` / `versionCode` changent dans `app/build.gradle.kts`, adapte simplement les deux occurrences du nom `GeekoIPTV_2.6.6_BUILD26.apk` dans le workflow si tu veux que le fichier téléchargé porte le nouveau numéro. La compilation elle-même fonctionnera même si le nom n'est pas changé.
