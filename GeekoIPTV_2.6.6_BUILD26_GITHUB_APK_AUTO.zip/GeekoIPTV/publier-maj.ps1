# Prépare une mise à jour GeekoIPTV.
#
# Utilisation depuis la racine du projet :
#   .\publier-maj.ps1 -Version 1.2 -Code 3 -Notes "Mosaique, telechargements"
#
# Le script calcule l'empreinte de l'APK et réécrit update.json.
# Il ne reste plus qu'à téléverser les deux fichiers sur GitHub.

param(
    [Parameter(Mandatory = $true)][string]$Version,
    [Parameter(Mandatory = $true)][int]$Code,
    [string]$Notes = "",
    [string]$Apk = "app\build\outputs\apk\release\app-release.apk",
    [string]$Depot = "geekorobin-code/geekoiptv-releases"
)

if (-not (Test-Path $Apk)) {
    Write-Host "APK introuvable : $Apk" -ForegroundColor Red
    Write-Host "Genere-le avec Build > Generate Signed App Bundle / APK." -ForegroundColor Yellow
    exit 1
}

$nom = "GeekoIPTV-$Version.apk"
$empreinte = (Get-FileHash $Apk -Algorithm SHA256).Hash.ToLower()
$taille = [math]::Round((Get-Item $Apk).Length / 1MB, 1)

# copie renommee, prete a televerser
Copy-Item $Apk $nom -Force

$manifeste = [ordered]@{
    versionCode = $Code
    versionName = $Version
    notes       = $Notes
    apkUrl      = "https://github.com/$Depot/raw/main/$nom"
    sha256      = $empreinte
    mandatory   = $false
}

$manifeste | ConvertTo-Json -Depth 3 | Set-Content "update.json" -Encoding UTF8

Write-Host ""
Write-Host "Pret pour la version $Version (code $Code, $taille Mo)" -ForegroundColor Green
Write-Host ""
Write-Host "1. Televerse $nom sur https://github.com/$Depot (Add file > Upload files)"
Write-Host "2. Ouvre update.json sur GitHub, crayon, colle le contenu ci-dessous, Commit"
Write-Host ""
Get-Content "update.json"
Write-Host ""
Write-Host "Empreinte : $empreinte" -ForegroundColor DarkGray
